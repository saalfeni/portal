<?php
require 'db_connect.php';
session_start();

$stmt = $pdo->query("SELECT username, email, password FROM admins LIMIT 1");
$admin = $stmt->fetch();

echo "<h3>Datos de Acceso Administrador</h3>";
echo "<b>Usuario:</b> " . $admin['username'] . "<br>";
echo "<b>Email:</b> " . $admin['email'] . "<br>";
echo "<b>Hash de Contraseña:</b> " . $admin['password'] . "<br>";
echo "<hr>";
echo "Si no recuerdas la contraseña, puedes copiar este Hash para resetearla a 'admin123' en tu base de datos:<br>";
echo "<code style='background:#eee; padding:5px;'>$2y$10$8On9hh5/6XbEainAm8Xlre3cE8FtIH/1fBRnSzshYmRs5Epm0gQnS</code>";
?>