<?php
// paciente_dashboard.php - ARCHIVO MAESTRO CORREGIDO
header('Content-Type: text/html; charset=utf-8');
require 'db_connect.php';

// --- 1. SEGURIDAD ---
if (!isset($_SESSION['paciente_id'])) {
    header('Location: index.php');
    exit;
}

$id = $_SESSION['paciente_id'];

// --- 2. LÓGICA DE LOGOUT ---
if (isset($_GET['logout'])) {
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: index.php");
    exit;
}

// --- 3. CARGA DE DATOS DEL PACIENTE ---
$stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
    header("Location: index.php?logout=1");
    exit;
}

// --- 4. IDENTIDAD Y AVATAR ---
if (!function_exists('get_gravatar')) {
    function get_gravatar($email, $s = 150) {
        $hash = md5(strtolower(trim($email)));
        return "https://www.gravatar.com/avatar/$hash?s=$s&d=identicon";
    }
}

$avatar_url = (!empty($p['foto_perfil']) && file_exists("assets/img/uploads/avatares/".$p['foto_perfil'])) 
    ? "assets/img/uploads/avatares/".$p['foto_perfil'] 
    : get_gravatar($p['email']);

// --- 5. NOTIFICACIONES ---
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notificaciones WHERE paciente_id = ? AND leido = 0");
$stmt->execute([$id]);
$total_sin_leer = $stmt->fetchColumn();

// LÓGICA DE NOTIFICACIÓN ACTUALIZADA: Verifica si hay notificaciones de tipo test O si el nuevo campo TDAH está activo
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notificaciones WHERE paciente_id = ? AND tipo = 'test' AND leido = 0");
$stmt->execute([$id]);
$notif_base = $stmt->fetchColumn() > 0;

// Aquí incluimos la detección de la nueva columna que creamos en SQL
$notif_test = ($notif_base || (isset($p['test_tdah_activo']) && $p['test_tdah_activo'] == 1));
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Portal de Salud Emocional | CMS-GP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --bg: #121212; --card: #1e1e1e; --turquesa: #40E0D0;
            --text-p: #e0e0e0; --text-s: #b0b0b0;
        }

        body {
            background-color: var(--bg); color: var(--text-p);
            font-family: 'Segoe UI', sans-serif; margin: 0;
            padding-top: 85px; padding-bottom: 80px; overflow-x: hidden;
        }

        /* Header */
        .main-header {
            position: fixed; top: 0; width: 100%; background: var(--card);
            display: flex; align-items: center; justify-content: space-between;
            padding: 10px 15px; z-index: 2000; border-bottom: 1px solid #333; box-sizing: border-box;
        }
        .header-center { display: flex; flex-direction: column; align-items: center; flex-grow: 1; }
        .app-title { font-size: 0.65rem; text-transform: uppercase; color: var(--turquesa); font-weight: 700; letter-spacing: 1px; }
        .avatar-orb { display: flex; flex-direction: column; align-items: center; cursor: pointer; margin-top: 5px; }
        .avatar-orb img { width: 42px; height: 42px; border-radius: 50%; border: 2px solid var(--turquesa); object-fit: cover; }
        .edit-label { font-size: 0.6rem; color: var(--text-s); margin-top: 2px; }
        .header-left, .header-right { width: 40px; position: relative; }

        /* Módulos */
        .content-module { animation: fadeIn 0.3s ease; padding: 15px; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        /* Footer */
        .main-footer { text-align: center; padding: 40px 20px; color: var(--text-s); font-size: 0.8rem; }
        .main-footer img { width: 70px; opacity: 0.3; margin-bottom: 10px; }

        /* Nav Inferior */
        .bottom-nav {
            position: fixed; bottom: 0; width: 100%; height: 65px;
            background: var(--card); display: flex; justify-content: space-around;
            align-items: center; border-top: 1px solid #333; z-index: 1000;
        }
        .nav-item {
            color: var(--text-s); text-decoration: none; display: flex;
            flex-direction: column; align-items: center; font-size: 0.7rem;
            position: relative; flex: 1;
        }
        .nav-item i { font-size: 1.3rem; margin-bottom: 3px; }
        .nav-item.active { color: var(--turquesa); }
        .badge-red { position: absolute; top: 0; right: 25%; width: 10px; height: 10px; background: #ff4444; border-radius: 50%; border: 2px solid var(--card); }
        .notif-dot { position: absolute; top: -5px; right: -5px; background: #ff4444; width: 8px; height: 8px; border-radius: 50%; border: 2px solid var(--card); }
    </style>
</head>
<body>

    <header class="main-header">
        <div class="header-left">
            <i class="fas fa-bell" style="font-size: 1.2rem; color: var(--text-s);" onclick="openNotif()"></i>
            <?php if($total_sin_leer > 0): ?><span class="notif-dot"></span><?php endif; ?>
        </div>
        
        <div class="header-center">
            <span class="app-title">Portal de Salud Emocional</span>
            <div class="avatar-orb" onclick="openProfile()">
                <img src="<?php echo $avatar_url; ?>" alt="Avatar">
                <span class="edit-label">Editar Perfil</span>
            </div>
        </div>

        <div class="header-right" style="text-align: right;">
            <a href="?logout=1" style="color: var(--text-s);"><i class="fas fa-sign-out-alt" style="font-size: 1.2rem;"></i></a>
        </div>
    </header>

    <main id="app-container">
        <section id="view-home" class="content-module"><?php include 'modules/home.php'; ?></section>
        <section id="view-calendario" class="content-module" style="display:none;"><?php include 'modules/calendario.php'; ?></section>
        <section id="view-actividades" class="content-module" style="display:none;"><?php include 'modules/actividades.php'; ?></section>
        <section id="view-tests" class="content-module" style="display:none;"><?php include 'modules/tests.php'; ?></section>
    </main>

    <?php include 'modules/perfil_modal.php'; ?>
    <?php include 'modules/notificaciones_modal.php'; ?>

    <footer class="main-footer">
        <img src="assets/img/logo.png" alt="Logo">
        <p>Copyright © <?php echo date('Y'); ?> | Alberto Félix</p>
    </footer>

    <nav class="bottom-nav">
        <a href="javascript:void(0)" onclick="navigate('home')" class="nav-item active" id="btn-home">
            <i class="fas fa-home"></i><span>Inicio</span>
        </a>
        <a href="javascript:void(0)" onclick="navigate('calendario')" class="nav-item" id="btn-calendario">
            <i class="fas fa-calendar-alt"></i><span>Citas</span>
        </a>
        <a href="javascript:void(0)" onclick="navigate('actividades')" class="nav-item" id="btn-actividades">
            <i class="fas fa-tasks"></i><span>Tareas</span>
        </a>
        <a href="javascript:void(0)" onclick="navigate('tests')" class="nav-item" id="btn-tests">
            <?php if($notif_test): ?><span class="badge-red"></span><?php endif; ?>
            <i class="fas fa-clipboard-list"></i><span>Tests</span>
        </a>
    </nav>

    <script>
    function navigate(view) {
        document.querySelectorAll('.content-module').forEach(el => el.style.display = 'none');
        document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
        
        document.getElementById('view-' + view).style.display = 'block';
        document.getElementById('btn-' + view).classList.add('active');
        window.scrollTo(0, 0);
    }

    function openProfile() {
        const modal = document.getElementById('modal-perfil');
        if(modal) modal.style.display = 'flex';
    }

    function openNotif() {
        const modal = document.getElementById('modal-notificaciones');
        if(modal) modal.style.display = 'flex';
    }
    </script>

    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-messaging.js"></script>
    
    </body>
</html>