importScripts('https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.10.1/firebase-messaging.js');

// 1. INSTALACIÓN INMEDIATA
self.addEventListener('install', (event) => {
    self.skipWaiting(); 
});

self.addEventListener('activate', (event) => {
    event.waitUntil(clients.claim()); 
});

// 2. CONFIGURACIÓN (Tus datos reales de la captura)
firebase.initializeApp({
    apiKey: "AIzaSyAwxVAOyYS6FC7CZoA17Q7nztgA2bae8ZQ",
    authDomain: "cms-gp-app.firebaseapp.com",
    projectId: "cms-gp-app",
    storageBucket: "cms-gp-app.firebasestorage.app",
    messagingSenderId: "730792080510",
    appId: "1:730792080510:web:774e4b55975a29c5ed142f"
});

const messaging = firebase.messaging();

// 3. MANEJO DE SEGUNDO PLANO (Background)
messaging.onBackgroundMessage((payload) => {
  console.log('Notificación Background:', payload);

  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: 'https://unresponsible-abigail-cataclysmically.ngrok-free.dev/af/portal/assets/img/icon-192.png',
    badge: 'https://unresponsible-abigail-cataclysmically.ngrok-free.dev/af/portal/assets/img/icon-192.png',
    data: {
        url: 'https://unresponsible-abigail-cataclysmically.ngrok-free.dev/af/portal/'
    }
  };

  return self.registration.showNotification(notificationTitle, notificationOptions);
});

// 4. CLIC EN NOTIFICACIÓN
self.addEventListener('notificationclick', function(event) {
    event.notification.close();
    event.waitUntil(
        clients.matchAll({type: 'window', includeUncontrolled: true}).then(function(clientList) {
            if (clientList.length > 0) {
                let client = clientList[0];
                return client.focus().then(() => client.navigate(client.url));
            }
            return clients.openWindow('https://unresponsible-abigail-cataclysmically.ngrok-free.dev/af/portal/');
        })
    );
});

// Escuchar mensaje de forzado SKIP_WAITING
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
}); 