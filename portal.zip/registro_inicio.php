<?php
// registro_inicio.php - Página de bienvenida y formulario de token/login
session_start();
require 'db_connect.php'; 

$error_token = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token_input = strtoupper(trim($_POST['token'] ?? ''));

    try {
        $stmt = $pdo->prepare("SELECT usado FROM tokens_registro WHERE token = ?");
        $stmt->execute([$token_input]);
        $token_data = $stmt->fetch();

        if ($token_data) {
            if ($token_data['usado'] == 0) {
                // Token válido y no usado, se permite el acceso al formulario
                $_SESSION['registro_token'] = $token_input;
                header('Location: registro_paciente.php');
                exit;
            } else {
                $error_token = "Este código ya ha sido utilizado para un registro anterior.";
            }
        } else {
            $error_token = "Código de registro no válido. Verifique la clave proporcionada.";
        }
    } catch (\PDOException $e) {
        $error_token = "Error de sistema al verificar el código.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido al Registro Clínico</title>
    <link rel="stylesheet" href="admin_styles.css?v=1.3">
    <style>
        /* Estilos del container y footer heredados de admin_styles.css */
        body { background-color: var(--dark); color: var(--text-grey); font-family: sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .container { max-width: 500px; padding: 40px; text-align: center; }
        h1 { color: var(--primary); font-size: 2em; margin-bottom: 10px; }
        .subtitulo { color: var(--text-main); margin-bottom: 30px; font-size: 1.1em; }
        
        .token-box { margin-top: 20px; padding: 20px; background: var(--section-bg); border-radius: 8px; }
        .token-box p { margin-bottom: 15px; color: var(--text-grey); }
        
        input[type="text"] { width: 100%; padding: 12px; border: 1px solid #444; border-radius: 6px; background: var(--card-bg); color: var(--text-main); box-sizing: border-box; text-align: center; font-size: 1.2em; text-transform: uppercase; }
        .start-btn { 
            background: var(--primary); color: var(--text-main); padding: 15px 25px; border: none;
            border-radius: 8px; font-size: 1.1em; cursor: pointer; display: block; width: 100%;
            margin-top: 20px; font-weight: bold; transition: background 0.2s;
        }
        .start-btn:hover { background: var(--accent-light); }
        .error { color: #e74c3c; margin-top: 10px; font-weight: bold; }
        
        /* Aseguramos la posición del logo y footer */
        .logo-container { position: absolute; top: 20px; left: 20px; display: block; z-index: 10; }
        .logo-container .logo { width: 50px; height: auto; }
        .main-footer { position: fixed; bottom: 0; width: 100%; }
    </style>
</head>
<body>
    <a href="registro_inicio.php" class="logo-container">
        <img src="assets/img/logo.png" alt="CMS-GP Logo" class="logo">
    </a>
    
    <div class="container">
        <h1>¡Bienvenido al Portal de Registro!</h1>
        <p class="subtitulo">Para iniciar su historial clínico, ingrese el código de registro único proporcionado por el terapeuta.</p>

        <div class="token-box">
            <?php if ($error_token): ?><div class="error"><?php echo $error_token; ?></div><?php endif; ?>

            <form method="POST">
                <label for="token" style="color: var(--text-main); display: block; margin-bottom: 10px;">Código de Registro (Ej: MMDDAAXXX)</label>
                <input type="text" id="token" name="token" maxlength="9" placeholder="Ingrese el Código" required autofocus>
                <button type="submit" class="start-btn">Iniciar Registro</button>
            </form>
        </div>
    </div>

    <footer class="main-footer">
        <p>&copy; <?php echo date('Y'); ?> CMS-GP | Desarrollado por Alberto Félix. <a href="mailto:hello@albertofelix.click">hello@albertofelix.click</a></p>
        <img src="assets/img/logo.png" alt="CMS-GP Logo" class="footer-logo">
    </footer>
</body>
</html>