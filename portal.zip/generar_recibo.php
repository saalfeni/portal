<?php
// generar_recibo.php - Comprobante de Pago Profesional
header('Content-Type: text/html; charset=utf-8');
session_start();
require 'db_connect.php';

// 1. Seguridad: Verificar que haya un ID y sesión activa
$pagoId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$pagoId || (!isset($_SESSION['admin_logged_in']) && !isset($_SESSION['paciente_id']))) {
    die("Acceso denegado.");
}

try {
    // 2. Obtener datos cruzados: Pago + Paciente
    $stmt = $pdo->prepare("
        SELECT sp.*, p.nombre_completo, p.email, p.id as p_id 
        FROM sesiones_pagos sp 
        JOIN pacientes p ON sp.paciente_id = p.id 
        WHERE sp.id = ?
    ");
    $stmt->execute([$pagoId]);
    $dato = $stmt->fetch();

    if (!$dato) die("Comprobante no encontrado.");

} catch (Exception $e) {
    die("Error de sistema: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recibo_<?php echo $dato['id']; ?>_CMS-GP</title>
    <style>
        body { font-family: 'Arial', sans-serif; color: #333; line-height: 1.6; background: #525659; margin: 0; padding: 20px; }
        .document-page { 
            background: white; width: 210mm; min-height: 297mm; 
            margin: auto; padding: 20mm; box-sizing: border-box; 
            box-shadow: 0 0 15px rgba(0,0,0,0.5); position: relative;
        }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #40E0D0; padding-bottom: 20px; margin-bottom: 40px; }
        .logo { height: 70px; }
        .info-clinica { text-align: right; }
        .info-clinica h1 { margin: 0; color: #40E0D0; font-size: 1.8rem; }
        
        .section-title { background: #f4f7f6; padding: 8px 15px; font-weight: bold; margin-bottom: 15px; border-left: 4px solid #40E0D0; }
        .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; }
        
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { text-align: left; padding: 12px; background: #f8fafc; border-bottom: 2px solid #eee; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        
        .total-area { text-align: right; margin-top: 30px; }
        .total-amount { font-size: 1.5rem; font-weight: bold; color: #2c3e50; }
        
        .footer { position: absolute; bottom: 20mm; left: 20mm; right: 20mm; text-align: center; font-size: 0.8rem; color: #94a3b8; border-top: 1px solid #eee; padding-top: 20px; }
        
        .btn-print { 
            background: #40E0D0; color: white; padding: 12px 25px; border: none; 
            border-radius: 5px; font-weight: bold; cursor: pointer; margin-bottom: 20px;
        }

        @media print {
            body { background: white; padding: 0; }
            .document-page { box-shadow: none; margin: 0; width: 100%; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>

    <div class="no-print" style="text-align: center;">
        <button class="btn-print" onclick="window.print()">🖨️ Imprimir / Guardar como PDF</button>
    </div>

    <div class="document-page">
        <div class="header">
            <img src="assets/img/logo.png" class="logo" alt="CMS-GP Logo">
            <div class="info-clinica">
                <h1>RECIBO DE PAGO</h1>
                <p><strong>Folio:</strong> #<?php echo str_pad($dato['id'], 6, "0", STR_PAD_LEFT); ?><br>
                <strong>Fecha Emisión:</strong> <?php echo date('d/m/Y'); ?></p>
            </div>
        </div>

        <div class="details-grid">
            <div>
                <div class="section-title">PACIENTE</div>
                <strong>Nombre:</strong> <?php echo htmlspecialchars($dato['nombre_completo']); ?><br>
                <strong>ID Paciente:</strong> #<?php echo $dato['p_id']; ?><br>
                <strong>Email:</strong> <?php echo htmlspecialchars($dato['email']); ?>
            </div>
            <div>
                <div class="section-title">DATOS DE LA CLÍNICA</div>
                <strong>Especialista:</strong> Alberto Félix<br>
                <strong>Servicio:</strong> Atención Psicológica Clínica<br>
                <strong>Contacto:</strong> hello@albertofelix.click
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>CONCEPTO / DESCRIPCIÓN</th>
                    <th style="text-align: right;">TOTAL</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <strong>Sesión Psicoterapéutica</strong><br>
                        <small>Fecha del servicio: <?php echo date('d/m/Y', strtotime($dato['fecha_sesion'])); ?></small>
                    </td>
                    <td style="text-align: right;">$<?php echo number_format($dato['monto'], 2); ?></td>
                </tr>
            </tbody>
        </table>

        <div class="total-area">
            <p>Estado del pago: <strong style="color: #10b981;">PAGADO</strong></p>
            <div class="total-amount">Total: $<?php echo number_format($dato['monto'], 2); ?> MXN</div>
        </div>

        <div class="footer">
            <p>Este documento es un comprobante de pago generado por el sistema CMS-GP.</p>
            <p>La salud emocional es el primer paso hacia el bienestar integral.</p>
        </div>
    </div>

</body>
</html>