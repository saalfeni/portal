<?php
// subir_foto.php - Gestión de imagen de perfil
header('Content-Type: text/html; charset=utf-8');
session_start();
require 'db_connect.php';

if (!isset($_SESSION['paciente_id'])) {
    header('Location: login_paciente.php');
    exit;
}

$id = $_SESSION['paciente_id'];
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['foto'])) {
    $archivo = $_FILES['foto'];
    $nombre_archivo = $archivo['name'];
    $tipo = $archivo['type'];
    $ruta_temporal = $archivo['tmp_name'];
    $size = $archivo['size'];
    
    // Validaciones básicas
    $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
    $ext = strtolower(pathinfo($nombre_archivo, PATHINFO_EXTENSION));
    
    if (!in_array($ext, $extensiones_permitidas)) {
        $mensaje = "<div class='error-msg'>Formato no permitido. Use JPG, PNG o GIF.</div>";
    } elseif ($size > 2 * 1024 * 1024) { // Limite 2MB
        $mensaje = "<div class='error-msg'>El archivo es demasiado grande (máximo 2MB).</div>";
    } else {
        // Nombre único para evitar conflictos
        $nuevo_nombre = "perfil_" . $id . "_" . time() . "." . $ext;
        $destino = "assets/img/" . $nuevo_nombre;

        if (move_uploaded_file($ruta_temporal, $destino)) {
            // Actualizar base de datos
            $stmt = $pdo->prepare("UPDATE pacientes SET foto_perfil = ? WHERE id = ?");
            if ($stmt->execute([$nuevo_nombre, $id])) {
                header("Location: paciente_dashboard.php?status=foto_ok");
                exit;
            }
        } else {
            $mensaje = "<div class='error-msg'>Error al mover el archivo al servidor.</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cambiar Foto | Salud Emocional</title>
    <link rel="stylesheet" href="admin_styles.css?v=2.1">
    <style>
        :root { 
            --turquesa: #40E0D0; 
            --bg-dark: #1e2126; 
            --card-dark: #2c313a;
        }
        body { background-color: var(--bg-dark); color: #abb2bf; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .upload-card { background: var(--card-dark); padding: 30px; border-radius: 12px; width: 400px; text-align: center; border: 1px solid rgba(255,255,255,0.1); }
        .preview-container { width: 150px; height: 150px; border-radius: 50%; border: 3px solid var(--turquesa); margin: 20px auto; overflow: hidden; background: #1a1d21; }
        .preview-container img { width: 100%; height: 100%; object-fit: cover; }
        .file-input-wrapper { margin: 20px 0; }
        .btn-save { background: var(--turquesa); color: #1e2126; border: none; padding: 12px 25px; border-radius: 6px; font-weight: bold; cursor: pointer; width: 100%; }
        .btn-back { display: block; margin-top: 15px; color: #5c6370; text-decoration: none; font-size: 0.9rem; }
        .error-msg { background: rgba(224, 108, 117, 0.2); color: #e06c75; padding: 10px; border-radius: 6px; margin-bottom: 15px; border: 1px solid #e06c75; }
    </style>
</head>
<body>

<div class="upload-card">
    <h2 style="color: white; margin-top: 0;">Actualizar Foto</h2>
    <p style="font-size: 0.9rem;">Selecciona una imagen cuadrada para mejores resultados.</p>
    
    <?php echo $mensaje; ?>

    <div class="preview-container">
        <img id="imgPreview" src="assets/img/default-avatar.png" alt="Previsualización">
    </div>

    <form action="" method="POST" enctype="multipart/form-data">
        <div class="file-input-wrapper">
            <input type="file" name="foto" id="fotoInput" accept="image/*" required style="color: #5c6370;">
        </div>
        <button type="submit" class="btn-save">Guardar Cambios</button>
    </form>

    <a href="paciente_dashboard.php" class="btn-back">← Volver al Portal</a>
</div>

<script>
    // Script para previsualizar la imagen antes de subirla
    document.getElementById('fotoInput').onchange = function (evt) {
        const [file] = this.files;
        if (file) {
            document.getElementById('imgPreview').src = URL.createObjectURL(file);
        }
    }
</script>

</body>
</html>