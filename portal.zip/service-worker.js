/* service-worker.js CORREGIDO */
const CACHE_NAME = 'cms-gp-v1';
const urlsToCache = [
  './',
  './index.php',
  './assets/img/logo.png',
  './assets/img/icon-192.png',
  './assets/img/icon-512.png'
];

self.addEventListener('install', event => {
  self.skipWaiting(); // Fuerza al SW a activarse de inmediato
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', event => {
  // CORRECCIÓN CRÍTICA: Ignorar extensiones de Chrome y esquemas no soportados
  if (!event.request.url.startsWith('http')) {
      return;
  }

  event.respondWith(
    fetch(event.request)
      .then(response => {
        // Si la respuesta no es válida, la devolvemos tal cual sin cachear
        if (!response || response.status !== 200 || response.type !== 'basic') {
          return response;
        }

        // Clonamos y guardamos solo peticiones GET
        const responseToCache = response.clone();
        if(event.request.method === 'GET'){
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
        }
        return response;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );
});