// registro.js - Lógica Condicional y Cálculos para el Formulario de Registro

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar los campos condicionales al cargar la página
    mostrarCamposRelacionales();
    mostrarTerapiaPrevia();
    mostrarDrogas();
});


// =========================================================
// I. CÁLCULO DE EDAD
// =========================================================
function calcularEdad() {
    const fechaNacimiento = document.getElementById('fecha_nacimiento').value;
    if (!fechaNacimiento) return;

    const fechaNac = new Date(fechaNacimiento);
    const hoy = new Date();
    
    let edad = hoy.getFullYear() - fechaNac.getFullYear();
    const mes = hoy.getMonth() - fechaNac.getMonth();

    // Si aún no ha llegado el mes o día de cumpleaños, restar 1
    if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNac.getDate())) {
        edad--;
    }

    document.getElementById('edad').value = edad > 0 ? edad + ' años' : '';
}


// =========================================================
// II. LÓGICA CONDICIONAL: HISTORIAL FAMILIAR Y RELACIONAL
// =========================================================
function mostrarCamposRelacionales() {
    const estadoCivil = document.getElementById('estado_civil').value;
    const container = document.getElementById('campos_relacionales');
    let htmlContent = '';

    // Mostrar el contenedor solo si se seleccionó algo
    if (estadoCivil !== '' && estadoCivil !== 'Soltero') {
        container.style.display = 'block';
    } else {
        container.style.display = 'none';
        return;
    }

    if (estadoCivil === 'Casado' || estadoCivil === 'Union Libre') {
        // Lógica para Pareja Activa
        htmlContent = `
            <h3>Detalles de la Relación Actual</h3>
            <div class="campo"><label for="nombre_vinculo">Nombre de su Pareja:</label><input type="text" name="nombre_vinculo" required></div>
            <div class="campo"><label for="tiempo_duracion">Tiempo de Duración de la Relación:</label><input type="text" name="tiempo_duracion" placeholder="Ej: 5 años, 3 meses" required></div>
        `;
    } else if (estadoCivil === 'Divorciado' || estadoCivil === 'Viudo') {
        // Lógica para Separación/Pérdida
        let titulo = estadoCivil === 'Divorciado' ? 'Separación' : 'Pérdida';
        htmlContent = `
            <h3>Detalles de la ${titulo}</h3>
            <div class="campo"><label for="nombre_vinculo">Nombre de su Ex-Pareja (o Pareja Fallecida):</label><input type="text" name="nombre_vinculo" required></div>
            <div class="campo"><label for="tiempo_separacion">Tiempo de Separación (o Pérdida):</label><input type="text" name="tiempo_separacion" placeholder="Ej: 2 años, 6 meses" required></div>
            <div class="campo"><label for="causas_separacion">Causas Simples de la Separación/Pérdida:</label><textarea name="causas_separacion" required></textarea></div>
        `;
    }
    
    container.innerHTML = htmlContent;
}

function mostrarHijos() {
    const hijosSi = document.querySelector('input[name="tiene_hijos"][value="Sí"]');
    const detalleDiv = document.getElementById('detalle_hijos');

    if (hijosSi && hijosSi.checked) {
        detalleDiv.style.display = 'block';
    } else {
        detalleDiv.style.display = 'none';
    }
}


// =========================================================
// III. LÓGICA CONDICIONAL: ANTECEDENTES CLÍNICOS
// =========================================================
function mostrarTerapiaPrevia() {
    const terapiaSi = document.querySelector('input[name="terapia_previa_bool"][value="Sí"]');
    const detalleDiv = document.getElementById('detalle_terapia_previa');

    if (terapiaSi && terapiaSi.checked) {
        detalleDiv.style.display = 'block';
        // Habilitar campos requeridos solo si se muestran
        detalleDiv.querySelectorAll('input, textarea').forEach(el => el.setAttribute('required', ''));
    } else {
        detalleDiv.style.display = 'none';
        // Deshabilitar campos requeridos si se ocultan
        detalleDiv.querySelectorAll('input, textarea').forEach(el => el.removeAttribute('required'));
    }
}

function mostrarDrogas() {
    const usoDrogas = document.querySelector('input[name="drogas_alguna_vez"]:checked');
    const detalleDiv = document.getElementById('detalle_drogas');
    
    // Si la opción seleccionada es diferente de 'No'
    if (usoDrogas && usoDrogas.value !== 'No') {
        detalleDiv.style.display = 'block';
        detalleDiv.querySelectorAll('input').forEach(el => el.setAttribute('required', ''));
    } else {
        detalleDiv.style.display = 'none';
        detalleDiv.querySelectorAll('input').forEach(el => el.removeAttribute('required'));
    }
}

// =========================================================
// IV. VALIDACIÓN FINAL (BÁSICA)
// =========================================================
function validarFormulario() {
    // Aquí puedes añadir validaciones finales si es necesario (ej: chequear formato de email)
    console.log("Formulario validado por JS.");
    return true; 
}