<?php
// admin_dashboard.php - Versión Optimizada para Móviles y Escritorio
require 'db_connect.php';
require 'config_admin.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Verificación de seguridad
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

$view = $_GET['view'] ?? 'dashboard';
$admin_id = $_SESSION['admin_id'] ?? 1; 

// --- LÓGICA INTEGRADA DE IDENTIDAD DEL ADMINISTRADOR ---
$stmt_h = $pdo->prepare("SELECT username, nombre, email, foto FROM admins WHERE id = ?");
$stmt_h->execute([$admin_id]);
$admin_header = $stmt_h->fetch();

$ad_nom_display = !empty($admin_header['nombre']) ? $admin_header['nombre'] : ($admin_header['username'] ?? 'Admin');
$h_foto = "";

if (!empty($admin_header['foto']) && file_exists($admin_header['foto'])) {
    $h_foto = $admin_header['foto'];
} else {
    $email_hash = md5(strtolower(trim($admin_header['email'] ?? 'admin@admin.com')));
    $h_foto = "https://www.gravatar.com/avatar/$email_hash?s=100&d=mp";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CMS-GP Pro | Panel Administrativo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { 
            --bg: #0c0c0c; 
            --sidebar: #151515; 
            --card: #1e1e1e;
            --turquesa: #40E0D0; 
            --text: #e0e0e0; 
            --sidebar-width: 260px; 
        }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar */
        .sidebar { 
            width: var(--sidebar-width); 
            background: var(--sidebar); 
            border-right: 1px solid #222; 
            display: flex; 
            flex-direction: column; 
            transition: all 0.3s ease; 
            z-index: 1100;
        }

        /* Overlay para móviles */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.7);
            z-index: 1050;
            backdrop-filter: blur(4px);
        }
        
        .sidebar-header { padding: 25px; text-align: center; border-bottom: 1px solid #222; }
        .sidebar-header img { max-width: 50px; margin-bottom: 10px; }
        
        .nav-menu { flex: 1; padding: 20px 0; overflow-y: auto; }
        .nav-item { display: flex; align-items: center; padding: 13px 25px; color: #888; text-decoration: none; transition: 0.3s; border-left: 3px solid transparent; font-size: 0.95rem; }
        .nav-item i { margin-right: 15px; width: 20px; text-align: center; font-size: 1.1rem; }
        .nav-item:hover, .nav-item.active { background: #1a1a1a; color: var(--turquesa); border-left-color: var(--turquesa); }
        
        .main-content { flex: 1; display: flex; flex-direction: column; overflow-y: auto; width: 100%; position: relative; }
        .top-header { 
            padding: 10px 20px; 
            background: var(--sidebar); 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-bottom: 1px solid #222; 
            position: sticky; top: 0; z-index: 900; 
            min-height: 60px;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none; border: none;
            color: var(--turquesa); font-size: 1.5rem; cursor: pointer;
        }
        
        .user-profile-header { display: flex; align-items: center; gap: 12px; }
        .avatar-circle { width: 35px; height: 35px; border-radius: 50%; border: 2px solid var(--turquesa); object-fit: cover; background: #222; }
        
        .content-body { padding: 20px; max-width: 1400px; margin: 0 auto; width: 100%; box-sizing: border-box; }
        .admin-footer { padding: 20px; text-align: center; font-size: 0.8rem; color: #444; border-top: 1px solid #111; margin-top: auto; }

        /* RESPONSIVE DESIGN */
        @media (max-width: 768px) {
            .mobile-menu-btn { display: block; }
            .sidebar { 
                position: fixed; 
                left: -100%; 
                height: 100%; 
            }
            .sidebar.active { left: 0; }
            .sidebar.active + .sidebar-overlay { display: block; }
            .desktop-name { display: none; }
            .content-body { padding: 15px; }
            .top-header h2 { font-size: 0.9rem; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" onclick="toggleSidebar()"></div>

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="assets/img/logo.png" onerror="this.src='https://via.placeholder.com/50/40E0D0/000000?text=GP'">
            <h2 style="color:var(--turquesa); margin:0; font-size:1.2rem; letter-spacing: 1px;">CMS-GP</h2>
        </div>
        
        <nav class="nav-menu">
            <a href="?view=dashboard" class="nav-item <?php echo $view=='dashboard'?'active':''; ?>">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a href="?view=pacientes" class="nav-item <?php echo ($view=='pacientes'||$view=='detalle')?'active':''; ?>">
                <i class="fas fa-users"></i> Pacientes
            </a>
            <a href="?view=sesiones" class="nav-item <?php echo $view=='sesiones'?'active':''; ?>">
                <i class="fas fa-calendar-alt"></i> Sesiones
            </a>
            <a href="?view=contabilidad" class="nav-item <?php echo $view=='contabilidad'?'active':''; ?>">
                <i class="fas fa-wallet"></i> Contabilidad
            </a>
            
            <div style="padding: 20px 25px 5px; font-size: 0.65rem; color: #444; text-transform: uppercase; font-weight: bold;">Avanzado</div>
            
            <a href="?view=perfil" class="nav-item <?php echo $view=='perfil'?'active':''; ?>">
                <i class="fas fa-cog"></i> Configuración
            </a>
            
            <a href="logout.php" class="nav-item" style="color:#ff4d4d; margin-top: 10px;">
                <i class="fas fa-sign-out-alt"></i> Salir
            </a>
        </nav>
    </aside>

    <main class="main-content">
        <header class="top-header">
            <div style="display:flex; align-items:center; gap:15px;">
                <button class="mobile-menu-btn" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <h2 style="margin:0; font-weight: 500;">
                    <?php 
                        $titles = [
                            'dashboard' => 'Panel', 'pacientes' => 'Pacientes', 
                            'detalle' => 'Expediente', 'sesiones' => 'Agenda', 
                            'contabilidad' => 'Finanzas', 'perfil' => 'Perfil'
                        ];
                        echo $titles[$view] ?? 'Admin'; 
                    ?>
                </h2>
            </div>
            
            <div class="user-profile-header">
                <span class="desktop-name" style="font-size: 0.9rem; color: #888; font-weight: 500;"><?php echo htmlspecialchars($ad_nom_display); ?></span>
                <img src="<?php echo $h_foto; ?>" class="avatar-circle" alt="Perfil">
            </div>
        </header>

        <div class="content-body">
            <?php 
            switch ($view) {
                case 'pacientes': include 'admin_modules/admin_lista_pacientes.php'; break;
                case 'detalle': include 'admin_modules/admin_detalle.php'; break;
                case 'sesiones': include 'admin_modules/admin_lista_sesiones.php'; break;
                case 'contabilidad': include 'admin_modules/admin_contabilidad.php'; break;
                case 'perfil': include 'admin_modules/admin_perfil.php'; break;
                case 'dashboard': 
                default: include 'admin_modules/admin_home.php'; break;
            }
            ?>
        </div>
        
        <footer class="admin-footer">
            CMS-GP Pro &copy; <?php echo date('Y'); ?>
        </footer>
    </main>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }
    </script>
</body>
</html>