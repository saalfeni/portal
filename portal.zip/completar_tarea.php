<?php
// completar_tarea_ajax.php
require 'db_connect.php';

if (!isset($_SESSION['paciente_id'])) {
    echo json_encode(['success' => false]); exit;
}

$id = $_POST['id'];
$val = $_POST['val'];

$stmt = $pdo->prepare("UPDATE paciente_actividades SET completado = ? WHERE id = ? AND paciente_id = ?");
$success = $stmt->execute([$val, $id, $_SESSION['paciente_id']]);

echo json_encode(['success' => $success]);