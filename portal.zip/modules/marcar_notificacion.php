<?php
require 'db_connect.php';
if (!isset($_SESSION['paciente_id'])) exit;

$paciente_id = $_SESSION['paciente_id'];

if (isset($_GET['todo'])) {
    $stmt = $pdo->prepare("UPDATE notificaciones SET leido = 1 WHERE paciente_id = ?");
    $stmt->execute([$paciente_id]);
} elseif (isset($_GET['id'])) {
    $stmt = $pdo->prepare("UPDATE notificaciones SET leido = 1 WHERE id = ? AND paciente_id = ?");
    $stmt->execute([$_GET['id'], $paciente_id]);
}
echo json_encode(['success' => true]);