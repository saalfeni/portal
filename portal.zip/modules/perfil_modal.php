<div id="modal-perfil" class="modal-overlay" style="display:none;" onclick="closeProfileOutside(event)">
    <div class="modal-card" onclick="event.stopPropagation()">
        <div class="modal-header">
            <h3>Mi Perfil</h3>
            <button class="close-btn" onclick="closeProfile()">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="edit-photo-container">
                <div class="avatar-preview">
                    <img src="<?php echo $avatar_url; ?>" id="img-preview-modal">
                    <label for="input-foto" class="photo-overlay">
                        <i class="fas fa-camera"></i>
                    </label>
                </div>
                <p class="photo-hint">Haz clic en la foto para cambiarla</p>
                <form id="form-foto-modal" action="subir_foto.php" method="POST" enctype="multipart/form-data" style="display:none;">
                    <input type="file" id="input-foto" name="foto_perfil" accept="image/*" onchange="document.getElementById('form-foto-modal').submit()">
                </form>
            </div>

            <div class="divider"><span>Seguridad</span></div>

            <form action="actualizar_password.php" method="POST" class="form-modern">
                <div class="input-group">
                    <label>Nueva Contraseña</label>
                    <input type="password" name="new_password" required placeholder="••••••••">
                </div>
                <div class="input-group">
                    <label>Confirmar Contraseña</label>
                    <input type="password" name="confirm_password" required placeholder="••••••••">
                </div>
                <button type="submit" class="btn-primary-modal">Actualizar Contraseña</button>
            </form>
        </div>
    </div>
</div>

<style>
/* Estilos del Modal */
.modal-overlay {
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.9); backdrop-filter: blur(8px);
    z-index: 3000; display: flex; align-items: center; justify-content: center;
}
.modal-card {
    background: #1e1e1e; width: 90%; max-width: 380px; border-radius: 24px;
    border: 1px solid #333; overflow: hidden; animation: slideUp 0.3s ease-out;
}
@keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

.modal-header { padding: 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #2a2a2a; }
.modal-header h3 { margin: 0; font-size: 1.1rem; color: #fff; }
.close-btn { background: none; border: none; color: #666; font-size: 1.5rem; cursor: pointer; }

/* Foto Edición */
.edit-photo-container { text-align: center; padding: 10px 0; }
.avatar-preview {
    position: relative; width: 120px; height: 120px; margin: 0 auto;
    border-radius: 50%; border: 3px solid var(--turquesa); padding: 4px;
}
.avatar-preview img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; }
.photo-overlay {
    position: absolute; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.4); border-radius: 50%; display: flex;
    align-items: center; justify-content: center; color: #fff; font-size: 1.5rem;
    opacity: 0; transition: 0.3s; cursor: pointer;
}
.avatar-preview:hover .photo-overlay { opacity: 1; }
.photo-hint { font-size: 0.75rem; color: #666; margin-top: 10px; }

.divider { position: relative; text-align: center; margin: 25px 0; }
.divider:before { content: ""; position: absolute; left: 0; top: 50%; width: 100%; height: 1px; background: #333; }
.divider span { position: relative; background: #1e1e1e; padding: 0 15px; color: #555; font-size: 0.7rem; text-transform: uppercase; }

/* Formulario */
.form-modern { display: flex; flex-direction: column; gap: 15px; }
.input-group { display: flex; flex-direction: column; gap: 5px; }
.input-group label { font-size: 0.8rem; color: #aaa; margin-left: 5px; }
.input-group input {
    background: #252525; border: 1px solid #333; color: #fff; padding: 12px;
    border-radius: 12px; font-size: 0.9rem; outline: none; transition: 0.3s;
}
.input-group input:focus { border-color: var(--turquesa); }

.btn-primary-modal {
    background: var(--turquesa); color: #000; border: none; padding: 14px;
    border-radius: 12px; font-weight: bold; cursor: pointer; margin-top: 10px;
}
</style>

<script>
function openProfile() { document.getElementById('modal-perfil').style.display = 'flex'; }
function closeProfile() { document.getElementById('modal-perfil').style.display = 'none'; }
function closeProfileOutside(e) { if(e.target.id === 'modal-perfil') closeProfile(); }
</script>