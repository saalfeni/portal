<?php
// modules/actividades.php
if (!isset($pdo)) exit;

// Consultar todas las actividades
$stmt = $pdo->prepare("SELECT * FROM paciente_actividades WHERE paciente_id = ? ORDER BY completado ASC, fecha_asignacion DESC");
$stmt->execute([$id]);
$actividades = $stmt->fetchAll();
?>

<div class="actividades-container">
    <div class="module-header-inline">
        <h3>Mi Historial de Actividades</h3>
        <span class="count-badge"><?php echo count($actividades); ?></span>
    </div>

    <div class="tasks-list">
        <?php if (empty($actividades)): ?>
            <div class="empty-state">
                <i class="fas fa-feather"></i>
                <p>Aún no tienes actividades asignadas.</p>
            </div>
        <?php else: ?>
            <?php foreach ($actividades as $act): ?>
                <div class="task-item <?php echo $act['completado'] ? 'task-done' : 'task-pending'; ?>" id="task-<?php echo $act['id']; ?>">
                    <div class="checkbox-wrapper">
                        <input type="checkbox" 
                               id="chk-<?php echo $act['id']; ?>" 
                               <?php echo $act['completado'] ? 'checked' : ''; ?>
                               onchange="toggleTask(<?php echo $act['id']; ?>, this.checked)">
                        <label for="chk-<?php echo $act['id']; ?>"></label>
                    </div>
                    <div class="task-content">
                        <span class="task-desc"><?php echo nl2br(htmlspecialchars($act['descripcion'])); ?></span>
                        <span class="task-date">Asignada: <?php echo date('d M, Y', strtotime($act['fecha_asignacion'])); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<style>
.module-header-inline { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
.module-header-inline h3 { margin: 0; font-size: 1.2rem; color: #fff; }
.count-badge { background: #333; padding: 2px 10px; border-radius: 10px; font-size: 0.75rem; color: var(--turquesa); }

.task-item {
    background: var(--card); border-radius: 15px; padding: 18px;
    margin-bottom: 12px; display: flex; align-items: flex-start;
    gap: 15px; border: 1px solid #2a2a2a; transition: 0.3s;
}

/* Estilo para Tareas Pendientes (Negritas) */
.task-pending { border-left: 4px solid var(--turquesa); }
.task-pending .task-desc { font-weight: 700; color: #fff; font-size: 1rem; }

/* Estilo para Tareas Completadas */
.task-done { opacity: 0.6; }
.task-done .task-desc { text-decoration: line-through; color: var(--text-s); font-weight: 400; }

.task-content { display: flex; flex-direction: column; flex: 1; }
.task-date { font-size: 0.7rem; color: #555; margin-top: 5px; text-transform: uppercase; }

/* Custom Checkbox */
.checkbox-wrapper { position: relative; height: 24px; width: 24px; margin-top: 2px; }
.checkbox-wrapper input { opacity: 0; position: absolute; }
.checkbox-wrapper label {
    position: absolute; top: 0; left: 0; height: 24px; width: 24px;
    background: #333; border: 2px solid #444; border-radius: 50%; cursor: pointer;
}
.checkbox-wrapper input:checked + label { background: var(--turquesa); border-color: var(--turquesa); }
.checkbox-wrapper input:checked + label:after {
    content: '\f00c'; font-family: 'Font Awesome 6 Free'; font-weight: 900;
    color: #000; font-size: 12px; position: absolute; left: 4px; top: 2px;
}

.empty-state { text-align: center; padding: 50px 20px; color: #333; }
.empty-state i { font-size: 3rem; margin-bottom: 10px; }
</style>

<script>
function toggleTask(taskId, isChecked) {
    const val = isChecked ? 1 : 0;
    const item = document.getElementById('task-' + taskId);
    
    // Feedback visual inmediato
    if(isChecked) {
        item.classList.remove('task-pending');
        item.classList.add('task-done');
    } else {
        item.classList.add('task-pending');
        item.classList.remove('task-done');
    }

    // Usar URLSearchParams para asegurar el formato POST correcto
    const params = new URLSearchParams();
    params.append('id', taskId);
    params.append('val', val);

    fetch('completar_tarea.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            console.log("Tarea y notificación actualizadas");
            // Opcional: Si tienes un contador de notificaciones en el dashboard, podrías refrescarlo aquí
        } else {
            alert("Error al guardar el estado.");
            location.reload(); // Revertir si falló
        }
    })
    .catch(error => {
        console.error('Error:', error);
        location.reload();
    });
}
</script>