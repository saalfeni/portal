<?php
// modules/tests.php
if (!isset($pdo)) exit;

// 1. Consultar Progresos
// MMPI (567)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM mmpi2_respuestas WHERE paciente_id = ?");
$stmt->execute([$id]);
$resp_mmpi = $stmt->fetchColumn();
$prog_mmpi = round(($resp_mmpi / 567) * 100);

// BDI (21)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bdi2_respuestas WHERE paciente_id = ?");
$stmt->execute([$id]);
$resp_bdi = $stmt->fetchColumn();
$prog_bdi = round(($resp_bdi / 21) * 100);

// BAI (21)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bai_respuestas WHERE paciente_id = ?");
$stmt->execute([$id]);
$resp_bai = $stmt->fetchColumn();
$prog_bai = round(($resp_bai / 21) * 100);

// TDAH (18) - NUEVA LÓGICA
$stmt = $pdo->prepare("SELECT COUNT(*) FROM tdah_respuestas WHERE paciente_id = ?");
$stmt->execute([$id]);
$resp_tdah = $stmt->fetchColumn();
$prog_tdah = round(($resp_tdah / 18) * 100);

// Definir los tests para iterar fácilmente
$tests = [
    ['id' => 'mmpi', 'nombre' => 'MMPI-2 (Personalidad)', 'progreso' => $prog_mmpi, 'icono' => 'fa-file-medical', 'url' => 'tests/mmpi-2/test_mmpi.php', 'activo' => $p['test_mmpi_activo']],
    ['id' => 'bdi', 'nombre' => 'BDI-II (Depresión)', 'progreso' => $prog_bdi, 'icono' => 'fa-cloud-rain', 'url' => 'tests/bdi-2/test_bdi2.php', 'activo' => $p['test_bdi_activo']],
    ['id' => 'bai', 'nombre' => 'BAI (Ansiedad)', 'progreso' => $prog_bai, 'icono' => 'fa-wind', 'url' => 'tests/bai/test_bai.php', 'activo' => $p['test_bai_activo']],
    // INTEGRACIÓN TDAH
    ['id' => 'tdah', 'nombre' => 'Evaluación TDAH', 'progreso' => $prog_tdah, 'icono' => 'fa-brain', 'url' => 'tests/tdah/test_tdah.php', 'activo' => $p['test_tdah_activo']]
];

$ninguno_activo = true;
?>

<div class="module-container">
    <h2 class="view-title">Pruebas Psicométricas</h2>
    <p class="view-subtitle">Completa las evaluaciones asignadas por tu especialista.</p>

    <div class="tests-list">
        <?php foreach ($tests as $t): 
            if ($t['activo'] == 1): 
                $ninguno_activo = false;
        ?>
            <a href="<?php echo $t['url']; ?>" class="test-card-pwa">
                <div class="icon-side">
                    <i class="fas <?php echo $t['icono']; ?>"></i>
                </div>
                <div class="info-side">
                    <div class="test-name"><?php echo $t['nombre']; ?></div>
                    <div class="prog-text">Progreso: <?php echo $t['progreso']; ?>%</div>
                    <div class="prog-bg"><div class="prog-fill" style="width:<?php echo $t['progreso']; ?>%"></div></div>
                </div>
                <div class="arrow-side"><i class="fas fa-chevron-right"></i></div>
            </a>
        <?php 
            endif;
        endforeach; 
        
        if ($ninguno_activo): ?>
            <div class="empty-state">
                <i class="fas fa-lock"></i>
                <p>No tienes pruebas asignadas en este momento.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.test-card-pwa {
    background: var(--card); border-radius: 18px; padding: 18px;
    display: flex; align-items: center; gap: 15px; text-decoration: none;
    margin-bottom: 12px; border: 1px solid #2a2a2a; transition: 0.2s;
}
.test-card-pwa:active { transform: scale(0.97); background: #252525; }
.icon-side {
    width: 50px; height: 50px; border-radius: 12px; background: rgba(64, 224, 208, 0.1);
    display: flex; align-items: center; justify-content: center; color: var(--turquesa); font-size: 1.3rem;
}
.info-side { flex: 1; }
.test-name { color: #fff; font-weight: 600; font-size: 0.95rem; margin-bottom: 5px; }
.prog-text { color: var(--text-s); font-size: 0.75rem; margin-bottom: 5px; }
.prog-bg { width: 100%; height: 6px; background: #333; border-radius: 3px; overflow: hidden; }
.prog-fill { height: 100%; background: var(--turquesa); border-radius: 3px; }
.arrow-side { color: #444; }
.empty-state { text-align: center; padding: 60px 20px; color: #444; }
.empty-state i { font-size: 3rem; margin-bottom: 15px; }
</style>