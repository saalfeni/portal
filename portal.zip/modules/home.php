<?php
// modules/home.php
if (!isset($pdo)) exit; 

// 1. Consultar Actividades Pendientes
$stmt = $pdo->prepare("SELECT COUNT(*) FROM paciente_actividades WHERE paciente_id = ? AND completado = 0");
$stmt->execute([$id]);
$tareas_pendientes = $stmt->fetchColumn();

// 2. Consultar Tests Pendientes
$tests_pendientes_count = 0;
$check_tests = [
    ['activo' => $p['test_mmpi_activo'], 'tabla' => 'mmpi2_respuestas', 'total' => 567],
    ['activo' => $p['test_bdi_activo'], 'tabla' => 'bdi2_respuestas', 'total' => 21],
    ['activo' => $p['test_bai_activo'], 'tabla' => 'bai_respuestas', 'total' => 21],
    ['activo' => $p['test_tdah_activo'], 'tabla' => 'tdah_respuestas', 'total' => 18]
];

foreach ($check_tests as $ct) {
    if ($ct['activo'] == 1) {
        $st = $pdo->prepare("SELECT COUNT(*) FROM {$ct['tabla']} WHERE paciente_id = ?");
        $st->execute([$id]);
        $respondidas = $st->fetchColumn();
        if ($respondidas < $ct['total']) $tests_pendientes_count++;
    }
}

// 3. Consultar Próxima Cita con Modalidad y Link
$stmt = $pdo->prepare("SELECT proxima_cita, modalidad_cita, link_cita FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
$cita_data = $stmt->fetch();

$proxima_cita = $cita_data['proxima_cita'] ?? null;
$modalidad = $cita_data['modalidad_cita'] ?? 'presencial';
$link_raw = $cita_data['link_cita'] ?? '';

// Lógica para asegurar que el link sea una URL absoluta externa
$link_final = $link_raw;
if (!empty($link_raw) && !preg_match("~^(?:f|ht)tps?://~i", $link_raw)) {
    $link_final = "https://" . $link_raw;
}

$tiene_cita = ($proxima_cita && strtotime($proxima_cita) > time());

// 4. Saludo según la hora
$hora = date('H');
if ($hora < 12) $saludo = "Buenos días";
elseif ($hora < 19) $saludo = "Buenas tardes";
else $saludo = "Buenas noches";
?>

<div class="home-wrapper">
    <div class="welcome-card">
        <span class="saludo-top"><?php echo $saludo; ?>,</span>
        <h2 class="user-display-name"><?php echo explode(' ', $p['nombre_completo'])[0]; ?></h2>
        <p class="mood-prompt">¿Cómo te sientes hoy?</p>
    </div>

    <?php if ($tiene_cita): ?>
    <div class="status-alert all-clear" style="border-left: 4px solid var(--turquesa); background: linear-gradient(135deg, #1a1a1a 0%, #252525 100%);">
        <div class="status-icon">
            <i class="fas <?php echo ($modalidad == 'online') ? 'fa-video' : 'fa-calendar-check'; ?>"></i>
        </div>
        <div class="status-text">
            <h4>Próxima Sesión: <?php echo ($modalidad == 'online') ? 'En Línea' : 'Presencial'; ?></h4>
            <p><?php echo date('d M, g:i a', strtotime($proxima_cita)); ?></p>
        </div>
        <?php if($modalidad == 'online' && !empty($link_final)): ?>
            <a href="<?php echo htmlspecialchars($link_final); ?>" target="_blank" class="btn-action-home" style="background: #27ae60; color: white; text-decoration: none; padding: 10px 15px; border-radius: 10px; font-size: 0.8rem; font-weight: bold; text-align: center;">
                UNIRSE <i class="fas fa-external-link-alt" style="font-size: 0.7rem; margin-left: 5px;"></i>
            </a>
        <?php else: ?>
            <div class="btn-action-home" style="background: rgba(64, 224, 208, 0.1); color: var(--turquesa); padding: 8px 12px; border-radius: 10px; font-size: 0.75rem;">
                En Consultorio
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($tareas_pendientes > 0): ?>
    <div class="status-alert has-tasks">
        <div class="status-icon"><i class="fas fa-tasks"></i></div>
        <div class="status-text">
            <h4>Tareas Pendientes</h4>
            <p>Tienes <?php echo $tareas_pendientes; ?> actividades por completar.</p>
        </div>
        <button onclick="navigate('actividades')" class="btn-action-home">VER</button>
    </div>
    <?php endif; ?>

    <?php if ($tests_pendientes_count > 0): ?>
    <div class="status-alert has-tasks" style="border-left-color: #9b59b6;">
        <div class="status-icon" style="color: #9b59b6;"><i class="fas fa-clipboard-list"></i></div>
        <div class="status-text">
            <h4>Pruebas Pendientes</h4>
            <p>Hay <?php echo $tests_pendientes_count; ?> tests asignados para ti.</p>
        </div>
        <button onclick="navigate('tests')" class="btn-action-home" style="background: #9b59b6; color: white;">IR</button>
    </div>
    <?php endif; ?>
</div>

<style>
/* Estilos originales preservados */
.home-wrapper { padding: 5px 0; }
.welcome-card { margin-bottom: 25px; padding-left: 5px; }
.saludo-top { color: var(--turquesa); font-size: 1.1rem; font-weight: 300; }
.user-display-name { font-size: 2.2rem; margin: 0; font-weight: 700; color: #fff; }
.mood-prompt { color: var(--text-s); margin: 5px 0; font-style: italic; }
.status-alert { display: flex; align-items: center; padding: 20px; border-radius: 18px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.05); gap: 15px; }
.status-alert.has-tasks { background: linear-gradient(135deg, #1e1e1e 0%, #252525 100%); border-left: 4px solid #e67e22; }
.status-icon { font-size: 1.5rem; color: var(--turquesa); }
.status-alert.has-tasks .status-icon { color: #e67e22; }
.status-text h4 { margin: 0; font-size: 1rem; color: #fff; }
.status-text p { margin: 3px 0 0; font-size: 0.8rem; color: var(--text-s); }
.status-text { flex: 1; }
.btn-action-home { border: none; padding: 10px 18px; border-radius: 12px; font-weight: 700; font-size: 0.8rem; cursor: pointer; background: var(--turquesa); color: #000; }
</style>