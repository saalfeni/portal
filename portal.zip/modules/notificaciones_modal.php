<?php
// modules/notificaciones_modal.php - VERSIÓN FINAL SEGURA
if (!isset($pdo)) exit;

$notificaciones = [];
$total_sin_leer = 0;

try {
    // 1. Consulta usando el nombre exacto de tu DB: fecha_notificacion
    $stmt = $pdo->prepare("SELECT * FROM notificaciones WHERE paciente_id = ? ORDER BY fecha_notificacion DESC LIMIT 20");
    $stmt->execute([$id]);
    $notificaciones = $stmt->fetchAll();

    // 2. Contar no leídas
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notificaciones WHERE paciente_id = ? AND leido = 0");
    $stmt->execute([$id]);
    $total_sin_leer = $stmt->fetchColumn();
} catch (PDOException $e) {
    // Si hay error, registramos en el log pero no matamos la página
    error_log("Error SQL en Notificaciones: " . $e->getMessage());
}
?>

<div id="modal-notificaciones" class="modal-overlay" style="display:none;" onclick="closeNotifOutside(event)">
    <div class="modal-card drawer-right" onclick="event.stopPropagation()">
        <div class="modal-header">
            <h3><i class="fas fa-bell"></i> Notificaciones 
                <?php if($total_sin_leer > 0): ?><span class="badge-count"><?php echo $total_sin_leer; ?></span><?php endif; ?>
            </h3>
            <button class="close-btn" onclick="closeNotif()">&times;</button>
        </div>
        
        <div class="modal-body notif-scroll">
            <?php if (empty($notificaciones)): ?>
                <div class="empty-notif">
                    <i class="fas fa-bell-slash"></i>
                    <p>No tienes notificaciones aún.</p>
                </div>
            <?php else: ?>
                <?php foreach ($notificaciones as $n): 
                    $icon = 'fa-info-circle';
                    if($n['tipo'] == 'tarea') $icon = 'fa-tasks';
                    if($n['tipo'] == 'test') $icon = 'fa-clipboard-check';
                    if($n['tipo'] == 'cita') $icon = 'fa-calendar-alt';
                ?>
                    <div class="notif-item <?php echo $n['leido'] ? '' : 'unread'; ?>" 
                         onclick="marcarLeida(<?php echo $n['id']; ?>, '<?php echo $n['tipo']; ?>')">
                        <div class="notif-icon-circle"><i class="fas <?php echo $icon; ?>"></i></div>
                        <div class="notif-content">
                            <p class="notif-text"><?php echo htmlspecialchars($n['mensaje']); ?></p>
                            <span class="notif-time"><?php echo date('d M, H:i', strtotime($n['fecha_notificacion'])); ?></span>
                        </div>
                        <?php if(!$n['leido']): ?><div class="unread-dot"></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <?php if($total_sin_leer > 0): ?>
        <div class="modal-footer-notif">
            <button onclick="marcarTodoLeido()" class="btn-clear">Marcar todo como leído</button>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.drawer-right { animation: slideInRight 0.3s ease-out; height: 100%; position: absolute; right: 0; border-radius: 20px 0 0 20px !important; max-width: 350px !important; background: #1e1e1e; border-left: 1px solid #333; }
@keyframes slideInRight { from { transform: translateX(100%); } to { transform: translateX(0); } }
.notif-scroll { max-height: 85vh; overflow-y: auto; padding: 15px; }
.badge-count { background: #ff4444; color: white; font-size: 0.7rem; padding: 2px 8px; border-radius: 10px; margin-left: 5px; }
.notif-item { display: flex; align-items: flex-start; gap: 12px; padding: 15px; border-radius: 12px; margin-bottom: 8px; cursor: pointer; background: rgba(255,255,255,0.03); border-left: 3px solid transparent; }
.notif-item.unread { background: rgba(64, 224, 208, 0.05); border-left: 3px solid var(--turquesa); }
.notif-icon-circle { width: 35px; height: 35px; border-radius: 50%; background: #333; display: flex; align-items: center; justify-content: center; color: var(--turquesa); flex-shrink: 0; }
.notif-text { margin: 0; font-size: 0.85rem; color: #e0e0e0; line-height: 1.3; }
.notif-time { font-size: 0.7rem; color: #666; margin-top: 5px; display: block; }
.unread-dot { width: 8px; height: 8px; background: var(--turquesa); border-radius: 50%; margin-top: 15px; }
</style>

<script>
function closeNotif() { document.getElementById('modal-notificaciones').style.display = 'none'; }
function closeNotifOutside(e) { if(e.target.id === 'modal-notificaciones') closeNotif(); }

function marcarLeida(id, tipo) {
    fetch('marcar_notificacion.php?id=' + id)
    .then(() => {
        closeNotif();
        if(tipo === 'tarea') navigate('actividades');
        else if(tipo === 'test') navigate('tests');
        else if(tipo === 'cita') navigate('calendario');
        else location.reload();
    });
}

function marcarTodoLeido() {
    fetch('marcar_notificacion.php?todo=1')
    .then(() => location.reload());
}
</script>