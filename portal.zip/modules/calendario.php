<?php
// modules/calendario.php
if (!isset($pdo)) exit;

// 1. Obtener cita, modalidad y enlace
$stmt = $pdo->prepare("SELECT proxima_cita, modalidad_cita, link_cita FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
$cita_info = $stmt->fetch();

$proxima_cita = $cita_info['proxima_cita'] ?? null;
$modalidad = $cita_info['modalidad_cita'] ?? 'presencial';
$link_raw = $cita_info['link_cita'] ?? '';

// Lógica para asegurar protocolo HTTPS en links externos
$link_final = $link_raw;
if (!empty($link_raw) && !preg_match("~^(?:f|ht)tps?://~i", $link_raw)) {
    $link_final = "https://" . $link_raw;
}

// 2. Lógica del calendario visual
$fecha_resaltar = $proxima_cita ? date('Y-m-d', strtotime($proxima_cita)) : null;
$mes_actual = date('n');
$anio_actual = date('Y');
$dia_cita = $fecha_resaltar ? date('j', strtotime($fecha_resaltar)) : null;
$mes_cita = $fecha_resaltar ? date('n', strtotime($fecha_resaltar)) : null;

$num_dias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $anio_actual);
$primer_dia_sem = date('w', strtotime("$anio_actual-$mes_actual-01"));
$meses_es = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
?>

<div class="calendar-module">
    <div class="module-header-inline">
        <h3>Mi Próxima Sesión</h3>
    </div>

    <?php if ($proxima_cita && strtotime($proxima_cita) > time()): ?>
        <div class="appointment-banner">
            <div class="date-badge">
                <span class="day-num"><?php echo date('d', strtotime($proxima_cita)); ?></span>
                <span class="month-name"><?php echo substr($meses_es[date('n', strtotime($proxima_cita))], 0, 3); ?></span>
            </div>
            <div class="appointment-details">
                <h4 style="margin:0; color:#fff; font-size: 1.1rem;">
                    <?php echo date('H:i', strtotime($proxima_cita)); ?> hs
                </h4>
                <p style="margin:3px 0 0; color:var(--turquesa); font-size:0.8rem; font-weight:bold; text-transform:uppercase;">
                    <i class="fas <?php echo ($modalidad == 'online') ? 'fa-video' : 'fa-building'; ?>"></i> 
                    Sesión <?php echo ($modalidad == 'online') ? 'En Línea' : 'en Consultorio'; ?>
                </p>
            </div>
            
            <?php if($modalidad == 'online' && !empty($link_final)): ?>
                <a href="<?php echo htmlspecialchars($link_final); ?>" target="_blank" class="btn-join" style="background: #27ae60; color: white;">
                    <i class="fas fa-video"></i> UNIRSE
                </a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="empty-state-calendar" style="padding: 20px; background: #1a1a1a; border-radius: 20px; text-align: center; border: 1px dashed #333;">
            <i class="fas fa-calendar-day" style="font-size: 2rem; color: #333; margin-bottom: 10px;"></i>
            <p style="color: #666; font-size: 0.9rem;">No tienes sesiones programadas próximamente.</p>
        </div>
    <?php endif; ?>

    <div class="mini-calendar-ui" style="margin-top:20px;">
        <div class="cal-header">
            <h4><?php echo $meses_es[$mes_actual] . " " . $anio_actual; ?></h4>
        </div>
        <div class="cal-grid">
            <div class="cal-day-label">D</div><div class="cal-day-label">L</div><div class="cal-day-label">M</div>
            <div class="cal-day-label">M</div><div class="cal-day-label">J</div><div class="cal-day-label">V</div><div class="cal-day-label">S</div>
            
            <?php 
            for ($i = 0; $i < $primer_dia_sem; $i++) echo '<div></div>';
            for ($dia = 1; $dia <= $num_dias; $dia++):
                $es_hoy = ($dia == date('j') && $mes_actual == date('n'));
                $es_cita = ($dia == $dia_cita && $mes_actual == $mes_cita);
                $class = $es_cita ? 'cal-day cita' : ($es_hoy ? 'cal-day hoy' : 'cal-day');
                echo "<div class='$class'>$dia</div>";
            endfor;
            ?>
        </div>
    </div>
</div>

<style>
/* Estilos originales preservados */
.appointment-banner { background: linear-gradient(135deg, #1e1e1e 0%, #2a2a2a 100%); border-radius: 20px; padding: 20px; display: flex; align-items: center; gap: 20px; border: 1px solid #333; margin-bottom: 10px; }
.date-badge { background: var(--turquesa); color: #000; border-radius: 12px; width: 60px; height: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center; font-weight: 800; }
.day-num { font-size: 1.5rem; line-height: 1; }
.month-name { font-size: 0.7rem; text-transform: uppercase; }
.btn-join { margin-left: auto; color: white; padding: 10px 15px; border-radius: 10px; text-decoration: none; font-size: 0.8rem; font-weight: bold; }
.cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; text-align: center; }
.cal-day { padding: 10px 0; font-size: 0.9rem; color: #888; border-radius: 8px; }
.cal-day.hoy { color: var(--turquesa); font-weight: bold; background: rgba(64, 224, 208, 0.1); }
.cal-day.cita { background: var(--turquesa); color: #000; font-weight: bold; box-shadow: 0 0 15px rgba(64, 224, 208, 0.4); }
.cal-day-label { font-size: 0.7rem; color: #444; font-weight: bold; padding-bottom: 10px; }
</style>