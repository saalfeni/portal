<?php
// guardar_fcm_token.php
//session_start();
require 'db_connect.php';

if (isset($_POST['token']) && isset($_SESSION['paciente_id'])) {
    $token = $_POST['token'];
    $paciente_id = $_SESSION['paciente_id'];

    // Verificar si el token ya existe para este paciente
    $stmtCheck = $pdo->prepare("SELECT id FROM fcm_tokens WHERE token = ?");
    $stmtCheck->execute([$token]);

    if ($stmtCheck->rowCount() == 0) {
        // Si no existe, lo insertamos
        $stmt = $pdo->prepare("INSERT INTO fcm_tokens (paciente_id, token) VALUES (?, ?)");
        if ($stmt->execute([$paciente_id, $token])) {
            echo "Token guardado correctamente";
        } else {
            echo "Error al guardar";
        }
    } else {
        echo "Token ya existente";
    }
}
?>