<?php
// config_admin.php - Credenciales del Portal Privado

// Configuración de credenciales de acceso al CMS-GP
define('ADMIN_USER', 'afelix_admin'); // Tu nombre de usuario para acceder
define('ADMIN_PASS', '211219vyA!');   // Tu contraseña para acceder
?>