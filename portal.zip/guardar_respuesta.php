<?php
// guardar_respuesta.php
session_start();
require 'db_connect.php';

// IMPORTANTE PARA LOCALHOST: Si no hay sesión, usamos el paciente ID 1 para probar
$paciente_id = $_SESSION['paciente_id'] ?? 1; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p_id = $_POST['p_id'] ?? null;
    $res = $_POST['res'] ?? null;

    if ($p_id !== null && $res !== null) {
        try {
            $stmt = $pdo->prepare("INSERT INTO mmpi2_respuestas (paciente_id, pregunta_id, respuesta) 
                                   VALUES (?, ?, ?) 
                                   ON DUPLICATE KEY UPDATE respuesta = VALUES(respuesta)");
            $stmt->execute([$paciente_id, $p_id, $res]);
            echo "ok";
        } catch (Exception $e) {
            header("HTTP/1.1 500 Internal Server Error");
            echo $e->getMessage();
        }
    }
}