<?php
// actualizar_password.php - Procesamiento de cambio de clave para Pacientes
session_start();
require 'db_connect.php';

// Seguridad: Verificar que el paciente esté logueado
if (!isset($_SESSION['paciente_id'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitización básica
    $p1 = $_POST['new_password'];
    $p2 = $_POST['confirm_password'];
    $id_paciente = $_SESSION['paciente_id'];

    // 1. Validar que las contraseñas coincidan
    if ($p1 !== $p2) {
        header("Location: paciente_dashboard.php?status=error_match");
        exit;
    }

    // 2. Validar longitud mínima
    if (strlen($p1) < 6) {
        header("Location: paciente_dashboard.php?status=error_length");
        exit;
    }

    try {
        // 3. Generar el Hash seguro (BCRYPT es el estándar actual)
        $nuevo_hash = password_hash($p1, PASSWORD_BCRYPT);

        // 4. Actualizar en la base de datos
        $stmt = $pdo->prepare("UPDATE pacientes SET password = ? WHERE id = ?");
        $stmt->execute([$nuevo_hash, $id_paciente]);

        // 5. Redirigir con éxito
        header("Location: paciente_dashboard.php?status=pass_ok");
        exit;

    } catch (PDOException $e) {
        // En caso de error de base de datos
        error_log("Error en cambio de password: " . $e->getMessage());
        header("Location: paciente_dashboard.php?status=error_db");
        exit;
    }
} else {
    // Si intentan entrar al archivo directamente sin POST
    header("Location: paciente_dashboard.php");
    exit;
}