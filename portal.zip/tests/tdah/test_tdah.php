<?php
// tests/tdah/test_tdah.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require '../../db_connect.php';

// Validación de sesión del paciente (ajusta según tu variable de sesión)
if (!isset($_SESSION['paciente_id'])) { 
    die("Error: Debe iniciar sesión como paciente para realizar este test."); 
}

$paciente_id = $_SESSION['paciente_id'];

$preguntas = [
    // Dimensión: Inatención
    1 => "1. ¿Tiene dificultad para prestar atención a los detalles o comete errores por descuido?",
    2 => "2. ¿Tiene dificultad para mantener la atención en tareas o actividades?",
    3 => "3. ¿Parece no escuchar cuando se le habla directamente?",
    4 => "4. ¿No sigue instrucciones y no termina las tareas o deberes?",
    5 => "5. ¿Tiene dificultad para organizar sus tareas y actividades?",
    6 => "6. ¿Evita o le disgusta iniciar tareas que requieren un esfuerzo mental sostenido?",
    7 => "7. ¿Pierde cosas necesarias para sus actividades (llaves, documentos, celular)?",
    8 => "8. ¿Se distrae fácilmente por estímulos externos?",
    9 => "9. ¿Olvida realizar las actividades cotidianas?",
    // Dimensión: Hiperactividad / Impulsividad
    10 => "10. ¿Juguetea con o golpea las manos o los pies o se retuerce en el asiento?",
    11 => "11. ¿Se levanta en situaciones en que se espera que permanezca sentado?",
    12 => "12. ¿Se siente inquieto en situaciones inapropiadas?",
    13 => "13. ¿Le resulta difícil dedicarse tranquilamente a actividades recreativas?",
    14 => "14. ¿A menudo está 'activo' como si lo impulsara un motor?",
    15 => "15. ¿Habla excesivamente?",
    16 => "16. ¿Responde inesperadamente antes de que se haya concluido la pregunta?",
    17 => "17. ¿Le es difícil esperar su turno?",
    18 => "18. ¿Interrumpe o se entromete con otros en conversaciones o juegos?"
];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluación TDAH - Adultos</title>
    <style>
        :root { --turquesa: #40E0D0; --bg: #0c0c0c; --card: #151515; }
        body { background: var(--bg); color: #fff; font-family: 'Segoe UI', sans-serif; padding: 20px; line-height: 1.6; }
        .test-container { max-width: 700px; margin: auto; background: var(--card); padding: 30px; border-radius: 20px; border: 1px solid #333; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        .instr { background: rgba(64, 224, 208, 0.05); padding: 20px; border-left: 4px solid var(--turquesa); border-radius: 8px; margin-bottom: 30px; font-size: 0.95rem; color: #ccc; }
        .pregunta-row { margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #222; }
        .pregunta-row p { margin-bottom: 15px; font-weight: 500; }
        .opciones-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
        @media (min-width: 600px) { .opciones-grid { grid-template-columns: repeat(4, 1fr); } }
        .radio-btn { background: #222; border: 1px solid #444; padding: 12px 5px; text-align: center; border-radius: 10px; cursor: pointer; transition: 0.2s; font-size: 0.8rem; color: #888; }
        input[type="radio"] { display: none; }
        input[type="radio"]:checked + .radio-btn { background: var(--turquesa); color: #000; border-color: var(--turquesa); font-weight: bold; }
        .btn-enviar { width: 100%; background: var(--turquesa); color: #000; padding: 18px; border: none; border-radius: 12px; font-weight: bold; font-size: 1.1rem; cursor: pointer; margin-top: 20px; transition: 0.3s; }
        .btn-enviar:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(64, 224, 208, 0.3); }
    </style>
</head>
<body>
    <div class="test-container">
        <h2 style="color:var(--turquesa); margin-top:0;">Cuestionario TDAH (Adultos)</h2>
        <div class="instr">
            <strong>Instrucciones:</strong> Evalúe con qué frecuencia ha experimentado estos síntomas en los <strong>últimos 6 meses</strong>. Marque la opción que mejor describa su situación actual.
        </div>

        <form action="guardar_tdah.php" method="POST">
            <?php foreach($preguntas as $id => $texto): ?>
            <div class="pregunta-row">
                <p><?php echo $texto; ?></p>
                <div class="opciones-grid">
                    <?php 
                    $labels = [0 => "Nunca", 1 => "A veces", 2 => "A menudo", 3 => "Muy seguido"];
                    foreach($labels as $val => $label): ?>
                    <label>
                        <input type="radio" name="p<?php echo $id; ?>" value="<?php echo $val; ?>" required>
                        <div class="radio-btn"><?php echo $label; ?></div>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
            
            <div style="margin-top:20px;">
                <p><strong>Observaciones adicionales (opcional):</strong></p>
                <textarea name="observaciones" style="width:100%; background:#222; border:1px solid #444; border-radius:10px; color:#fff; padding:15px; height:80px;"></textarea>
            </div>

            <button type="submit" class="btn-enviar">FINALIZAR EVALUACIÓN</button>
        </form>
    </div>
</body>
</html>