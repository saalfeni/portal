<?php
require '../../db_connect.php';
require '../../config_admin.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in'])) { header('Location: ../../admin_login.php'); exit; }

$paciente_id = $_GET['id'] ?? null;
if (!$paciente_id) die("ID no válido.");

// Obtener datos
$stmt_p = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt_p->execute([$paciente_id]);
$paciente = $stmt_p->fetch();

$stmt_r = $pdo->prepare("SELECT * FROM tdah_respuestas WHERE paciente_id = ? ORDER BY pregunta_id ASC");
$stmt_r->execute([$paciente_id]);
$respuestas = $stmt_r->fetchAll();

// Lógica de calificación TDAH
$inatencion_items = range(1, 9);
$hiper_items = range(10, 18);

$puntos_inatencion = 0;
$puntos_hiper = 0;

foreach($respuestas as $r) {
    // En TDAH adultos, se cuenta si la respuesta es 2 (A menudo) o 3 (Muy a menudo)
    if($r['respuesta'] >= 2) {
        if(in_array($r['pregunta_id'], $inatencion_items)) $puntos_inatencion++;
        if(in_array($r['pregunta_id'], $hiper_items)) $puntos_hiper++;
    }
}

// Criterio diagnóstico: 5 o más síntomas en cualquier dimensión
$cumple_inatencion = ($puntos_inatencion >= 5);
$cumple_hiper = ($puntos_hiper >= 5);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte TDAH - <?php echo $paciente['nombre_completo']; ?></title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; padding: 40px; background: #fff; }
        .report-card { max-width: 800px; margin: auto; border: 1px solid #ddd; padding: 40px; border-radius: 10px; }
        .header { border-bottom: 2px solid var(--turquesa); padding-bottom: 20px; margin-bottom: 30px; }
        .grid-results { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .stat-box { padding: 20px; border-radius: 10px; text-align: center; color: #fff; }
        .pos-bg { background: #e74c3c; } /* Rojo si hay riesgo */
        .neg-bg { background: #2ecc71; } /* Verde si es normal */
        .score { font-size: 3rem; font-weight: bold; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="report-card">
        <div class="header">
            <h2>Evaluación Clínica de TDAH (DSM-5)</h2>
            <p>Paciente: <strong><?php echo htmlspecialchars($paciente['nombre_completo']); ?></strong></p>
        </div>

        <div class="grid-results">
            <div class="stat-box <?php echo $cumple_inatencion ? 'pos-bg' : 'neg-bg'; ?>">
                <div class="score"><?php echo $puntos_inatencion; ?> / 9</div>
                <strong>Síntomas de Inatención</strong>
                <p><?php echo $cumple_inatencion ? "Riesgo Elevado" : "Rango Normal"; ?></p>
            </div>
            <div class="stat-box <?php echo $cumple_hiper ? 'pos-bg' : 'neg-bg'; ?>">
                <div class="score"><?php echo $puntos_hiper; ?> / 9</div>
                <strong>Hiperactividad / Impulsividad</strong>
                <p><?php echo $cumple_hiper ? "Riesgo Elevado" : "Rango Normal"; ?></p>
            </div>
        </div>

        

        <div style="margin-top: 40px;">
            <h3>Interpretación Clínica</h3>
            <p>Según los criterios del DSM-5 para adultos, la presencia de 5 o más síntomas marcados como "A menudo" o "Muy a menudo" en una dimensión sugiere una probabilidad clínica significativa de TDAH.</p>
            
            <div style="background: #f9f9f9; padding: 20px; border-radius: 10px; margin-top: 20px;">
                <strong>Resultado Global:</strong><br>
                <?php if($cumple_inatencion || $cumple_hiper): ?>
                    <span style="color: #e74c3c; font-weight: bold;">Se recomienda evaluación diagnóstica profunda. El paciente cumple criterios de cribado para TDAH.</span>
                <?php else: ?>
                    <span style="color: #2ecc71; font-weight: bold;">Los resultados no muestran indicadores suficientes para el diagnóstico de TDAH en este momento.</span>
                <?php endif; ?>
            </div>
        </div>

        <button onclick="window.print()" class="no-print" style="margin-top:30px; padding:10px 20px; cursor:pointer;">Imprimir Informe</button>
    </div>
</body>
</html>