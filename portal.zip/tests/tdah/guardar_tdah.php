<?php
// tests/tdah/guardar_tdah.php
session_start();
require '../../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['paciente_id'])) {
    $paciente_id = $_SESSION['paciente_id'];
    
    try {
        $pdo->beginTransaction();
        
        // 1. Limpiar respuestas previas
        $stmt_del = $pdo->prepare("DELETE FROM tdah_respuestas WHERE paciente_id = ?");
        $stmt_del->execute([$paciente_id]);

        // 2. Insertar las 18 respuestas
        $stmt_ins = $pdo->prepare("INSERT INTO tdah_respuestas (paciente_id, pregunta_id, respuesta) VALUES (?, ?, ?)");

        for ($i = 1; $i <= 18; $i++) {
            $val = isset($_POST["p$i"]) ? (int)$_POST["p$i"] : 0;
            $stmt_ins->execute([$paciente_id, $i, $val]);
        }

        $pdo->commit();
        
        // Mostrar mensaje de éxito con estilo
        echo "
        <body style='background:#0c0c0c; color:white; font-family:sans-serif; display:flex; align-items:center; justify-content:center; height:100vh; margin:0;'>
            <div style='text-align:center; background:#151515; padding:40px; border-radius:20px; border:1px solid #333;'>
                <div style='font-size:50px; color:#40E0D0;'>✓</div>
                <h2>Test Completado</h2>
                <p style='color:#888;'>Tus respuestas han sido enviadas correctamente a tu terapeuta.</p>
                <br>
                <a href='../../index.php' style='color:#40E0D0; text-decoration:none; font-weight:bold;'>VOLVER AL INICIO</a>
            </div>
        </body>";
        
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Error crítico al guardar: " . $e->getMessage());
    }
} else {
    header("Location: ../../index.php");
}