<?php
// /portal/tests/mmpi-2/prueba_ruta.php
require_once '../../db_connect.php';

if (isset($pdo)) {
    echo "✅ Conexión exitosa. El sistema encuentra la base de datos: " . DB_NAME;
} else {
    echo "❌ Error: La conexión no se cargó.";
}
?>