<?php
// /portal/tests/mmpi-2/cargar_claves_avanzadas.php
require '../../db_connect.php';

// Estructura: [Escala, Pregunta, Respuesta que suma (1=V, 0=F), Tipo]
$claves_avanzadas = [
    // --- ESCALAS SUPLEMENTARIAS (Muestra del Apéndice C) ---
    ['A', 2, 1], ['A', 3, 1], ['A', 5, 1], ['A', 10, 1], ['A', 15, 1], // Ansiedad (A)
    ['R', 14, 0], ['R', 18, 0], ['R', 25, 0], ['R', 32, 0], ['R', 40, 0], // Represión (R)
    ['Fyo', 7, 1], ['Fyo', 11, 1], ['Fyo', 16, 1], ['Fyo', 23, 1], // Fuerza del Yo
    ['MAC-R', 6, 1], ['MAC-R', 12, 1], ['MAC-R', 19, 1], ['MAC-R', 26, 1], // MacAndrew Alcoholismo
    
    // --- ÍTEMS CRÍTICOS KOSS-BUTCHER (Alertas Rojas) ---
    // Ideación Suicida (Dirección Crítica: Verdadero)
    ['K-B_Suicida', 150, 1, 'critico'], 
    ['K-B_Suicida', 303, 1, 'critico'], 
    ['K-B_Suicida', 506, 1, 'critico'], 
    ['K-B_Suicida', 520, 1, 'critico'],
    
    // Estado Agudo de Confusión
    ['K-B_Confusion', 15, 1, 'critico'], 
    ['K-B_Confusion', 24, 1, 'critico'], 
    ['K-B_Confusion', 31, 1, 'critico'],
    
    // --- ÍTEMS CRÍTICOS LACHAR-WROBEL ---
    // Ansiedad Somática
    ['L-W_Somatica', 18, 1, 'critico'], 
    ['L-W_Somatica', 28, 1, 'critico'], 
    ['L-W_Somatica', 40, 1, 'critico']
];

try {
    $pdo->beginTransaction();
    
    // Preparar la inserción
    $stmt = $pdo->prepare("INSERT INTO mmpi2_escalas_claves (escala, pregunta_id, respuesta_esperada, tipo_escala) VALUES (?, ?, ?, ?)");
    
    foreach ($claves_avanzadas as $c) {
        // Si no se especificó tipo en el array, por defecto es 'suplementaria'
        $tipo = isset($c[3]) ? $c[3] : 'suplementaria';
        $stmt->execute([$c[0], $c[1], $c[2], $tipo]);
    }
    
    $pdo->commit();
    echo "<h1>Éxito</h1><p>Se han cargado las claves suplementarias y los ítems críticos correctamente.</p>";
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Error: " . $e->getMessage();
}