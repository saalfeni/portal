<?php
// /portal/tests/mmpi-2/baremos_mexico.php

class MMPI2_Baremos {
    /**
     * Baremos extraídos del Manual Moderno (MMPI-2 México).
     * Se incluyen puntos clave para permitir la interpolación lineal matemática,
     * cubriendo así todo el rango de respuestas sin saturar el código.
     */
    private static $baremos = [
        'm' => [ // TABLA B-7: VARONES (Norma Mexicana)
            // Escalas de Validez
            'L'  => [0=>30, 2=>36, 4=>43, 6=>50, 8=>57, 10=>64, 12=>71, 15=>81],
            'F'  => [0=>36, 5=>48, 10=>61, 15=>73, 20=>86, 25=>99, 30=>112],
            'K'  => [0=>30, 5=>30, 10=>34, 15=>45, 20=>55, 25=>66, 30=>77],
            
            // Escalas Clínicas
            'Hs' => [0=>32, 5=>45, 10=>57, 15=>70, 20=>82, 25=>95, 30=>107],
            'D'  => [10=>33, 15=>43, 20=>53, 25=>63, 30=>73, 35=>83, 40=>93],
            'Hy' => [10=>31, 15=>42, 20=>52, 25=>63, 30=>73, 35=>84, 40=>94],
            'Pd' => [10=>40, 15=>51, 20=>62, 25=>73, 30=>84, 35=>95],
            'Mf' => [15=>35, 25=>50, 35=>65, 45=>78],
            'Pa' => [5=>33, 10=>50, 15=>67, 20=>84, 25=>101],
            'Pt' => [10=>35, 20=>50, 30=>65, 40=>80, 50=>95],
            'Sc' => [10=>34, 20=>48, 30=>62, 40=>76, 50=>90, 60=>104],
            'Ma' => [10=>38, 15=>50, 20=>62, 25=>74, 30=>86],
            'Si' => [10=>31, 20=>45, 30=>58, 40=>71, 50=>84, 60=>97],

            // Escalas Suplementarias
            'A'     => [0=>30, 10=>38, 15=>48, 20=>59, 25=>69, 30=>80],
            'R'     => [0=>30, 10=>41, 15=>52, 20=>63, 25=>74, 30=>85],
            'Fyo'   => [10=>28, 20=>38, 30=>48, 40=>58, 50=>68],
            'MAC-R' => [10=>35, 20=>55, 25=>65, 30=>75],
            'EPK'   => [0=>30, 10=>45, 20=>60, 25=>68, 30=>75]
        ],
        'f' => [ // TABLA B-8: MUJERES (Norma Mexicana)
            // Escalas de Validez
            'L'  => [0=>32, 5=>49, 10=>65, 15=>82],
            'F'  => [0=>36, 10=>58, 20=>80, 30=>103],
            'K'  => [0=>30, 15=>46, 25=>67, 30=>77],

            // Escalas Clínicas (Muestra base, expandible según manual)
            'Hs' => [0=>34, 10=>59, 20=>84, 30=>108],
            'D'  => [10=>37, 20=>57, 30=>77, 40=>98],
            'Hy' => [10=>33, 20=>55, 30=>77, 40=>99],
            'Pd' => [10=>41, 20=>63, 30=>85, 40=>107],
            'Mf' => [20=>31, 30=>46, 40=>62, 50=>78],
            'Pa' => [5=>34, 15=>68, 25=>103],
            'Pt' => [10=>35, 30=>64, 50=>93],
            'Sc' => [10=>35, 30=>62, 50=>89, 70=>116],
            'Ma' => [10=>39, 20=>62, 30=>86],
            'Si' => [10=>31, 30=>57, 50=>83, 70=>109],

            // Escalas Suplementarias
            'A'     => [0=>30, 10=>40, 20=>61, 30=>82],
            'R'     => [0=>30, 10=>39, 15=>49, 25=>70, 30=>81],
            'Fyo'   => [10=>26, 20=>36, 30=>46, 40=>56, 50=>66],
            'MAC-R' => [10=>38, 20=>58, 24=>66, 30=>78],
            'EPK'   => [0=>30, 10=>44, 20=>58, 30=>73, 35=>80]
        ]
    ];

    /**
     * Calcula la Puntuación T utilizando interpolación lineal.
     * Esto permite obtener resultados precisos incluso para valores que no están
     * explícitamente definidos en los arreglos anteriores.
     */
    public static function obtenerT($escala, $natural, $genero) {
        $natural = (int)round($natural);
        $genero = ($genero == 'f') ? 'f' : 'm';
        
        // Si la escala no existe, retornamos un promedio neutro
        if (!isset(self::$baremos[$genero][$escala])) return 50;

        $tabla = self::$baremos[$genero][$escala];
        
        // Si el valor existe exactamente en el baremo
        if (isset($tabla[$natural])) return $tabla[$natural];

        // Lógica de búsqueda de límites para interpolación
        $keys = array_keys($tabla);
        sort($keys);
        
        // Si el valor está fuera de los rangos definidos
        if ($natural <= $keys[0]) return $tabla[$keys[0]];
        if ($natural >= end($keys)) return end($tabla);

        // Interpolación matemática
        for ($i = 0; $i < count($keys) - 1; $i++) {
            if ($natural > $keys[$i] && $natural < $keys[$i+1]) {
                $n1 = $keys[$i];
                $n2 = $keys[$i+1];
                $t1 = $tabla[$n1];
                $t2 = $tabla[$n2];
                
                // Fórmula: y = y1 + ((y2 - y1) / (x2 - x1)) * (x - x1)
                return (int)round($t1 + ($t2 - $t1) * ($natural - $n1) / ($n2 - $n1));
            }
        }
        return 50;
    }
}