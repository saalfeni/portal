<?php
// /portal/tests/mmpi-2/diccionario_interpretacion.php

class MMPI2_Interpretador {
    private static $textos = [
        'L' => "El paciente busca dar una imagen socialmente muy favorable. Sus resultados pueden estar minimizando problemas reales.",
        'F' => "Elevación en la escala de Incoherencia. Puede indicar confusión, distress severo o un intento de exagerar síntomas.",
        'Hs' => "Preocupación excesiva por la salud física. Tendencia a desarrollar síntomas físicos ante el estrés.",
        'D'  => "Indicadores de desánimo, sentimientos de tristeza, falta de esperanza y baja energía vital.",
        'Hy' => "Uso de la negación para evitar conflictos. Puede presentar quejas físicas como mecanismo de defensa.",
        'Pd' => "Dificultad para seguir normas sociales. Posibles rasgos de impulsividad o conflictos con la autoridad.",
        'Pa' => "Sensibilidad interpersonal elevada. Tendencia a la suspicacia o sentimientos de ser tratado injustamente.",
        'Pt' => "Niveles altos de ansiedad, rumiación mental, perfeccionismo y dudas constantes.",
        'Sc' => "Dificultades en la organización del pensamiento o sentimientos de alienación social.",
        'Ma' => "Energía excesiva, euforia o irritabilidad. Posible dificultad para inhibir impulsos.",
        'Si' => "Tendencia a la introversión social, preferencia por la soledad y timidez en grupos."
    ];

    public static function generarAnalisis($escalas_t) {
        $analisis = [];
        foreach ($escalas_t as $escala => $t) {
            if ($t >= 65 && isset(self::$textos[$escala])) {
                $analisis[] = "<strong>Escala $escala:</strong> " . self::$textos[$escala];
            }
        }
        return $analisis;
    }
}