<?php
// api_genero.php
session_start();
require '../../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['genero']) && isset($_SESSION['paciente_id'])) {
    $genero = ($_POST['genero'] === 'm') ? 'm' : 'f';
    $paciente_id = $_SESSION['paciente_id'];

    // 1. Actualizar en la base de datos
    $stmt = $pdo->prepare("UPDATE pacientes SET genero = ? WHERE id = ?");
    if ($stmt->execute([$genero, $paciente_id])) {
        // 2. Actualizar la sesión para que el modal no vuelva a aparecer
        $_SESSION['paciente_genero'] = ($genero === 'm') ? 'Masculino' : 'Femenino';
        echo "success";
    } else {
        http_response_code(500);
    }
}