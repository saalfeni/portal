<?php
// /portal/tests/mmpi-2/interpretar.php
session_start();
require '../../db_connect.php';
require 'baremos_mexico.php';

$paciente_id = $_GET['id'] ?? null;
if (!$paciente_id) die("ID de paciente no proporcionado.");

// 1. Datos del Paciente
$stmt = $pdo->prepare("SELECT nombre_completo, genero FROM pacientes WHERE id = ?");
$stmt->execute([$paciente_id]);
$paciente = $stmt->fetch();
if (!$paciente) die("Paciente no encontrado.");

$nombre = $paciente['nombre_completo'];
$gen = strtolower($paciente['genero'] ?? 'm');

// 2. Validación de completitud (Punto 3 de tu solicitud)
$stmt_count = $pdo->prepare("SELECT COUNT(*) FROM mmpi2_respuestas WHERE paciente_id = ?");
$stmt_count->execute([$paciente_id]);
$total_respondidas = $stmt_count->fetchColumn();

// 3. Cálculo de Puntuaciones Naturales
$sql = "SELECT c.escala, COUNT(*) as bruto FROM mmpi2_respuestas r
        JOIN mmpi2_escalas_claves c ON r.pregunta_id = c.pregunta_id AND r.respuesta = c.respuesta_esperada
        WHERE r.paciente_id = ? GROUP BY c.escala";
$stmt = $pdo->prepare($sql);
$stmt->execute([$paciente_id]);
$naturales = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// 4. Configuración de Escalas y Corrección K
$k = $naturales['K'] ?? 0;
$clinicas_list = [
    'Hs'=>($naturales['Hs']??0)+(0.5*$k), 'D'=>($naturales['D']??0), 'Hy'=>($naturales['Hy']??0),
    'Pd'=>($naturales['Pd']??0)+(0.4*$k), 'Mf'=>($naturales['Mf']??0), 'Pa'=>($naturales['Pa']??0),
    'Pt'=>($naturales['Pt']??0)+(1.0*$k), 'Sc'=>($naturales['Sc']??0)+(1.0*$k),
    'Ma'=>($naturales['Ma']??0)+(0.2*$k), 'Si'=>($naturales['Si']??0),
];
$suplementarias_list = ['A', 'R', 'Fyo', 'MAC-R', 'EPK'];

// 5. Ítems Críticos
$sql_c = "SELECT c.escala, p.pregunta FROM mmpi2_respuestas r
          JOIN mmpi2_escalas_claves c ON r.pregunta_id = c.pregunta_id AND r.respuesta = c.respuesta_esperada
          JOIN mmpi2_preguntas p ON r.pregunta_id = p.id
          WHERE r.paciente_id = ? AND c.tipo_escala = 'critico' ORDER BY c.escala";
$stmt_c = $pdo->prepare($sql_c);
$stmt_c->execute([$paciente_id]);
$alertas = $stmt_c->fetchAll();

$diccionario = [
    'L'=>'Mentira','F'=>'Atipicidad','K'=>'Defensividad','Hs'=>'Hipocondriasis','D'=>'Depresión',
    'Hy'=>'Histeria','Pd'=>'Desviación Psicopática','Mf'=>'Masculinidad/Feminidad','Pa'=>'Paranoia',
    'Pt'=>'Psicastenia','Sc'=>'Esquizofrenia','Ma'=>'Hipomanía','Si'=>'Introversión Social',
    'A'=>'Ansiedad','R'=>'Represión','Fyo'=>'Fuerza del Yo','MAC-R'=>'Alcoholismo','EPK'=>'Estrés Postraumático'
];

// 6. Función de Narrativa Dinámica Bipolar (Punto 4 de tu solicitud)
function obtenerNarrativaCompleta($esc, $t) {
    if ($t >= 65) {
        $m = [
            'Hs' => "Preocupación somática excesiva. Probable canalización de ansiedad vía síntomas físicos.",
            'D' => "Estado de ánimo deprimido, apatía y sentimientos de desesperanza.",
            'Hy' => "Tendencia a somatizar; necesidad marcada de aprobación social.",
            'Pd' => "Impulsividad y problemas recurrentes con figuras de autoridad.",
            'Pa' => "Suspicacia marcada, sentimientos de persecución o hipersensibilidad.",
            'Pt' => "Niveles altos de ansiedad, rumiación mental y perfeccionismo.",
            'Sc' => "Sentimientos de alienación, confusión o ideas inusuales.",
            'Ma' => "Energía excesiva, euforia o irritabilidad.",
            'Si' => "Introversión social marcada; evita el contacto grupal."
        ];
        return "<b>Elevación Clínica:</b> " . ($m[$esc] ?? "Se detecta un nivel alto con implicaciones clínicas.");
    }
    if ($t <= 40) {
        $b = [
            'D' => "Energía estable, optimismo y confianza en las capacidades personales.",
            'Pa' => "Flexibilidad mental, confianza en los demás y baja reactividad social.",
            'Ma' => "Bajo nivel de energía, estilo de vida pausado, posible fatiga.",
            'Si' => "Extroversión marcada, facilidad para establecer vínculos y gusto social.",
            'Pt' => "Seguridad personal, baja autocrítica y estabilidad emocional."
        ];
        return "<b>Nivel Bajo:</b> " . ($b[$esc] ?? "Puntuación por debajo de la media con rasgos adaptativos.");
    }
    return "Resultados dentro de la normalidad estadística.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte Profesional MMPI-2</title>
    <script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
      tinymce.init({
        selector: '.wysiwyg',
        menubar: false,
        plugins: 'lists advlist',
        toolbar: 'undo redo | bold italic | bullist numlist | removeformat',
        height: 250,
        promotion: false, branding: false,
        setup: function(ed) {
            ed.on('init', function() {
                ed.setContent(localStorage.getItem('mmpi_<?php echo $paciente_id; ?>_' + ed.id) || '');
            });
            ed.on('change', function() {
                localStorage.setItem('mmpi_<?php echo $paciente_id; ?>_' + ed.id, ed.getContent());
            });
        }
      });
    </script>
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f4f7f9; padding: 20px; color: #333; }
        .page { max-width: 950px; margin: auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 5px 25px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #40E0D0; padding-bottom: 10px; }
        .warning-box { background: #fff3cd; color: #856404; padding: 15px; border: 1px solid #ffeeba; border-radius: 5px; margin-bottom: 20px; font-weight: bold; font-size: 14px; text-align:center;}
        h2 { color: #2c3e50; border-left: 6px solid #40E0D0; padding-left: 15px; margin-top: 40px; text-transform: uppercase; font-size: 16px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #e1e8ed; padding: 10px; text-align: center; font-size: 13px; }
        th { background: #f8f9fa; }
        .high { background: #fff5f5; color: #d93025; font-weight: bold; }
        .low { background: #f0f7ff; color: #004085; font-weight: bold; }
        .chart-container { margin: 30px 0; text-align: center; }
        @media print { .no-print { display: none; } .page { box-shadow: none; border: none; padding: 0; } }
        .btn-print { position: fixed; bottom: 30px; right: 30px; background: #40E0D0; padding: 15px 35px; border-radius: 50px; border: none; font-weight: bold; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.3); }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<div class="page">
    <div class="header">
        <h1>Informe de Evaluación MMPI-2</h1>
        <p><strong>Paciente:</strong> <?php echo htmlspecialchars($nombre); ?> | <strong>ID:</strong> <?php echo $paciente_id; ?></p>
        <img src="../../assets/img/logo.png" style="width: 130px;">
    </div>

    <?php if($total_respondidas < 560): ?>
        <div class="warning-box">
            ⚠️ ADVERTENCIA: Este protocolo está INCOMPLETO (<?php echo $total_respondidas; ?> de 567 respuestas). 
            Los resultados pueden carecer de validez clínica y la interpretación debe ser cautelosa.
        </div>
    <?php endif; ?>

    <h2>1. Escalas de Validez y Clínicas</h2>
    <table>
        <thead>
            <tr><th>Escala</th><th>Nombre</th><th>Natural</th><th>T (Mx)</th><th>Interpretación Dinámica</th></tr>
        </thead>
        <tbody>
            <?php 
            $agrup = array_merge(array_fill_keys(['L','F','K'], 0), $clinicas_list);
            foreach ($agrup as $esc => $v_ign):
                $val = isset($clinicas_list[$esc]) ? $clinicas_list[$esc] : ($naturales[$esc] ?? 0);
                $t = MMPI2_Baremos::obtenerT($esc, $val, $gen);
                $narrativa = obtenerNarrativaCompleta($esc, $t);
                $cls = ($t >= 65) ? 'high' : (($t <= 40) ? 'low' : '');
            ?>
            <tr class="<?php echo $cls; ?>">
                <td><strong><?php echo $esc; ?></strong></td>
                <td style="text-align:left;"><?php echo $diccionario[$esc] ?? 'Escala Clínica'; ?></td>
                <td><?php echo round($val, 1); ?></td>
                <td><?php echo $t; ?></td>
                <td style="text-align:left; font-size: 12px;"><?php echo $narrativa; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <div class="chart-container">
        <h3>Perfil Zig-Zag Clínico y de Validez</h3>
        <canvas id="chartClinico"></canvas>
    </div>

    <div style="page-break-before: always;"></div>

    <h2>2. Escalas Suplementarias</h2>
    <table>
        <thead>
            <tr><th>Escala</th><th>Nombre</th><th>Natural</th><th>T (Mx)</th><th>Estatus</th></tr>
        </thead>
        <tbody>
            <?php foreach ($suplementarias_list as $e): 
                $v = $naturales[$e]??0; $t = MMPI2_Baremos::obtenerT($e, $v, $gen); 
                $cls_s = ($t >= 65) ? 'high' : (($t <= 40) ? 'low' : '');
            ?>
            <tr class="<?php echo $cls_s; ?>">
                <td><strong><?php echo $e; ?></strong></td>
                <td style="text-align:left;"><?php echo $diccionario[$e] ?? ''; ?></td>
                <td><?php echo $v; ?></td>
                <td><?php echo $t; ?></td>
                <td><?php echo ($t >= 65 ? 'Elevación' : ($t <= 40 ? 'Bajo' : 'Normal')); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="chart-container">
        <h3>Perfil de Escalas Suplementarias</h3>
        <canvas id="chartSup"></canvas>
    </div>

    <h2>3. Ítems Críticos Detectados</h2>

<?php
// Clasificar las alertas en dos grupos
$koss_butcher = [];
$lachar_wrobel = [];

foreach ($alertas as $a) {
    if (strpos($a['escala'], 'K-B_') !== false) {
        $koss_butcher[] = $a;
    } elseif (strpos($a['escala'], 'L-W_') !== false) {
        $lachar_wrobel[] = $a;
    }
}
?>

<div style="margin-bottom: 25px;">
    <h3 style="color: #2c3e50; font-size: 14px; border-bottom: 1px solid #eee;">Criterios de Koss-Butcher (Crisis Agudas)</h3>
    <?php if(!empty($koss_butcher)): ?>
        <table style="border: 1px solid #d93025; margin-bottom: 10px;">
            <thead><tr style="background:#f8d7da;color:#721c24;"><th>Área Clínica</th><th>Reactivo Detectado</th></tr></thead>
            <tbody>
                <?php foreach($koss_butcher as $a): ?>
                <tr>
                    <td width="30%"><strong><?php echo str_replace('K-B_', '', $a['escala']); ?></strong></td>
                    <td style="text-align:left;"><?php echo htmlspecialchars($a['pregunta']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="color: #6c757d; font-style: italic; font-size: 12px;">No se detectaron indicadores de crisis según Koss-Butcher.</p>
    <?php endif; ?>
</div>

<div>
    <h3 style="color: #2c3e50; font-size: 14px; border-bottom: 1px solid #eee;">Criterios de Lachar-Wrobel (Desajuste General)</h3>
    <?php if(!empty($lachar_wrobel)): ?>
        <table style="border: 1px solid #004085; margin-bottom: 10px;">
            <thead><tr style="background:#cce5ff;color:#004085;"><th>Área de Desajuste</th><th>Reactivo Detectado</th></tr></thead>
            <tbody>
                <?php foreach($lachar_wrobel as $a): ?>
                <tr>
                    <td width="30%"><strong><?php echo str_replace('L-W_', '', $a['escala']); ?></strong></td>
                    <td style="text-align:left;"><?php echo htmlspecialchars($a['pregunta']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="color: #6c757d; font-style: italic; font-size: 12px;">No se detectaron indicadores de desajuste según Lachar-Wrobel.</p>
    <?php endif; ?>
</div>

    <h2>4. Impresiones Generales (Editor WYSIWYG)</h2>
    <textarea id="imp" class="wysiwyg"></textarea>

    <h2>5. Recomendaciones</h2>
    <textarea id="rec" class="wysiwyg"></textarea>

    <div style="margin-top:80px; text-align:center; border-top: 1px solid #eee; padding-top: 20px;">
        <p>_____________________________________</p>
        <p><strong>Firma del Especialista Responsable</strong></p>
    </div>
</div>

<button onclick="window.print();" class="btn-print no-print">Imprimir / PDF</button>

<script>
const commonOpt = { 
    responsive: true, 
    plugins: { legend: { display: false } }, 
    scales: { 
        y: { 
            min: 30, max: 120, 
            grid: { color: (c) => c.tick.value === 65 || c.tick.value === 40 ? 'red' : '#eee', lineWidth: (c) => c.tick.value === 65 || c.tick.value === 40 ? 2 : 1 } 
        } 
    } 
};

// Gráfica Clínica
new Chart(document.getElementById('chartClinico'), {
    type: 'line',
    data: {
        labels: ['L','F','K','Hs','D','Hy','Pd','Mf','Pa','Pt','Sc','Ma','Si'],
        datasets: [{
            data: [
                <?php echo MMPI2_Baremos::obtenerT('L',$naturales['L']??0,$gen); ?>,
                <?php echo MMPI2_Baremos::obtenerT('F',$naturales['F']??0,$gen); ?>,
                <?php echo MMPI2_Baremos::obtenerT('K',$naturales['K']??0,$gen); ?>,
                <?php foreach($clinicas_list as $e=>$v) echo MMPI2_Baremos::obtenerT($e,$v,$gen).","; ?>
            ],
            borderColor: '#40E0D0', pointBackgroundColor: '#2c3e50', fill: false, tension: 0.2, pointRadius: 5
        }]
    }, options: commonOpt
});

// Gráfica Suplementaria (Restaurada)
new Chart(document.getElementById('chartSup'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($suplementarias_list); ?>,
        datasets: [{
            data: [<?php foreach($suplementarias_list as $e) echo MMPI2_Baremos::obtenerT($e,$naturales[$e]??0,$gen).","; ?>],
            backgroundColor: 'rgba(64, 224, 208, 0.6)', borderColor: '#40E0D0', borderWidth: 1
        }]
    }, options: commonOpt
});
</script>
</body>
</html>