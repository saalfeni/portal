<?php
// 1. INICIO DE SESIÓN Y CONEXIÓN (Siempre debe ir al principio)
session_start();
require_once '../../db_connect.php';

// 2. SEGURIDAD: Solo entran pacientes logueados
if (!isset($_SESSION['paciente_id'])) {
    header("Location: ../../index.php");
    exit;
}

$paciente_id = $_SESSION['paciente_id'];
$nombre = $_SESSION['paciente_nombre'] ?? 'Paciente';

// 3. VERIFICACIÓN DE ESTADO Y PROGRESO TOTAL
// Hacemos una sola consulta para optimizar el rendimiento
$stmt = $pdo->prepare("SELECT COUNT(*) FROM mmpi2_respuestas WHERE paciente_id = ?");
$stmt->execute([$paciente_id]);
$total_respondidas = (int)$stmt->fetchColumn();

// Si ya respondió las 567 y no está forzando ver un bloque, redirigir al dashboard
if ($total_respondidas >= 567 && !isset($_GET['bloque'])) {
    header("Location: ../../paciente_dashboard.php?status=finished");
    exit;
}

// 4. GESTIÓN DE BLOQUES (Paginación)
$preguntas_por_bloque = 25;
// Si no hay bloque en la URL, calculamos en cuál debería estar según su progreso
$bloque_actual = isset($_GET['bloque']) ? (int)$_GET['bloque'] : floor($total_respondidas / $preguntas_por_bloque) + 1;

// Evitar que el bloque sea 0 o negativo
if ($bloque_actual < 1) $bloque_actual = 1;

$inicio = ($bloque_actual - 1) * $preguntas_por_bloque;

// 5. OBTENER PREGUNTAS DEL BLOQUE
$stmt = $pdo->prepare("SELECT * FROM mmpi2_preguntas LIMIT :inicio, :cantidad");
$stmt->bindValue(':inicio', (int)$inicio, PDO::PARAM_INT);
$stmt->bindValue(':cantidad', (int)$preguntas_por_bloque, PDO::PARAM_INT);
$stmt->execute();
$preguntas = $stmt->fetchAll();

// 6. VERIFICAR RESPUESTAS EXISTENTES PARA ESTE BLOQUE (Para precargar si regresa)
$stmt = $pdo->prepare("SELECT pregunta_id, respuesta FROM mmpi2_respuestas WHERE paciente_id = ? AND pregunta_id > ? AND pregunta_id <= ?");
$stmt->execute([$paciente_id, $inicio, $inicio + $preguntas_por_bloque]);
$respuestas_existentes = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// 7. CÁLCULO DE PORCENTAJE PARA LA BARRA DE PROGRESO
$porcentaje_total = ($total_respondidas / 567) * 100;

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MMPI-2 | Evaluación</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --primary: #40E0D0; --bg: #121212; --card: #1e1e1e; --text: #e0e0e0; }
        body { background-color: var(--bg); color: var(--text); font-family: 'Segoe UI', sans-serif; margin: 0; padding-bottom: 80px; }
        
        /* Header & Logo */
        .header { text-align: center; padding: 20px; background: var(--card); border-bottom: 1px solid #333; }
        .logo { width: 80px; margin-bottom: 10px; }
        .platform-name { font-size: 1.2rem; font-weight: bold; color: var(--primary); letter-spacing: 1px; }
        .test-title { font-size: 0.9rem; opacity: 0.7; margin-top: 5px; }

        /* Información del Paciente */
        .paciente-info { background: #252525; padding: 15px; margin: 15px; border-radius: 10px; border-left: 4px solid var(--primary); }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 0.85rem; }

        /* Barra de Navegación Superior */
        .top-nav { display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; }
        .btn-exit { background: #333; color: white; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; text-decoration: none; font-size: 0.8rem; }

        /* Bloque de Preguntas */
        .container { padding: 0 15px; }
        .pregunta-card { background: var(--card); padding: 20px; border-radius: 12px; margin-bottom: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }
        .pregunta-texto { font-size: 1.05rem; line-height: 1.4; margin-bottom: 15px; }
        
        /* Opciones de Respuesta */
        .opciones { display: flex; gap: 10px; }
        .radio-btn { flex: 1; position: relative; }
        .radio-btn input { display: none; }
        .radio-label { display: block; text-align: center; padding: 12px; background: #333; border-radius: 8px; cursor: pointer; transition: 0.2s; font-weight: bold; border: 2px solid transparent; }
        
        input[value="1"]:checked + .radio-label { background: #2e7d32; border-color: #4caf50; }
        input[value="0"]:checked + .radio-label { background: #c62828; border-color: #f44336; }

        /* Footer Fijo */
        .footer-save { position: fixed; bottom: 0; left: 0; right: 0; background: var(--card); padding: 15px; display: flex; justify-content: space-around; border-top: 1px solid #333; z-index: 100; }
        .btn-next { background: var(--primary); color: black; border: none; padding: 12px 30px; border-radius: 25px; font-weight: bold; cursor: pointer; }

        /* Modal Género */
        #modalGenero { position: fixed; inset: 0; background: rgba(0,0,0,0.9); display: flex; justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: var(--card); padding: 30px; border-radius: 15px; text-align: center; width: 85%; }

        @media (max-width: 480px) {
            .pregunta-texto { font-size: 0.95rem; }
        }
    </style>
</head>
<body>

    <?php if (!isset($_SESSION['paciente_genero'])): ?>
    <div id="modalGenero">
        <div class="modal-content">
            <h3>Confirmación de Datos</h3>
            <p>Para procesar el test correctamente, por favor confirma tu género:</p>
            <div class="opciones">
                <button class="btn-exit" style="background:var(--primary); color:black;" onclick="setGenero('m')">Masculino</button>
                <button class="btn-exit" style="background:var(--primary); color:black;" onclick="setGenero('f')">Femenino</button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <header class="header">
        <img src="../../assets/img/logo.png" alt="Logo" class="logo">
        <div class="platform-name">SALUD EMOCIONAL CMS-GP</div>
        <div class="test-title">Inventario Multifásico de Personalidad de Minnesota (MMPI-2)</div>
    </header>

    <div class="top-nav">
        <div class="progreso-text">Progreso: <?php echo round($porcentaje_total, 1); ?>%</div>
        <a href="../../paciente_dashboard.php" class="btn-exit"><i class="fas fa-save"></i> Guardar y Salir</a>
    </div>

    <div class="paciente-info">
        <div class="info-grid">
            <div><i class="fas fa-user"></i> <?php echo $nombre; ?></div>
            <div><i class="fas fa-id-card"></i> ID: <?php echo $paciente_id; ?></div>
            <div><i class="fas fa-calendar"></i> <?php echo date('d/m/Y'); ?></div>
            <div id="displayGenero"><i class="fas fa-venus-mars"></i> <?php echo $_SESSION['paciente_genero'] ?? 'Pendiente'; ?></div>
        </div>
    </div>

    

    <form id="formMMPI" class="container">
        <?php foreach ($preguntas as $p): 
            $res = isset($respuestas_existentes[$p['id']]) ? $respuestas_existentes[$p['id']] : null;
        ?>
        <div class="pregunta-card">
            <div class="pregunta-texto"><strong><?php echo $p['id']; ?>.</strong> <?php echo htmlspecialchars($p['pregunta']); ?></div>
            <div class="opciones">
                <label class="radio-btn">
                    <input type="radio" name="p_<?php echo $p['id']; ?>" value="1" <?php echo $res === '1' ? 'checked' : ''; ?> required>
                    <span class="radio-label">Verdadero</span>
                </label>
                <label class="radio-btn">
                    <input type="radio" name="p_<?php echo $p['id']; ?>" value="0" <?php echo $res === '0' ? 'checked' : ''; ?>>
                    <span class="radio-label">Falso</span>
                </label>
            </div>
        </div>
        <?php endforeach; ?>
        
        <input type="hidden" name="bloque" value="<?php echo $bloque_actual; ?>">
    </form>

    <div class="footer-save">
        <?php if ($bloque_actual > 1): ?>
            <button type="button" class="btn-exit" onclick="irBloque(<?php echo $bloque_actual - 1; ?>)">Anterior</button>
        <?php endif; ?>
        
        <button type="button" class="btn-next" onclick="enviarBloque()">
            <?php echo ($bloque_actual < 23) ? 'Siguiente bloque' : 'Finalizar Test'; ?>
        </button>
    </div>

    <script>
    function setGenero(g) {
        fetch('api_genero.php', {
            method: 'POST',
            body: new URLSearchParams({genero: g})
        }).then(() => {
            document.getElementById('modalGenero').style.display = 'none';
            document.getElementById('displayGenero').innerHTML = '<i class="fas fa-venus-mars"></i> ' + (g === 'm' ? 'Masculino' : 'Femenino');
        });
    }

    async function enviarBloque() {
        const form = document.getElementById('formMMPI');
        if (!form.checkValidity()) {
            alert("Por favor responde todas las preguntas del bloque antes de continuar.");
            return;
        }

        const formData = new FormData(form);
        const btn = document.querySelector('.btn-next');
        btn.disabled = true;
        btn.innerHTML = "Guardando...";

        try {
            const response = await fetch('guardar_respuestas_bloque.php', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                const proximo = <?php echo $bloque_actual + 1; ?>;
                window.location.href = `test_mmpi.php?bloque=${proximo}`;
            }
        } catch (error) {
            alert("Error al guardar. Verifica tu conexión.");
            btn.disabled = false;
        }
    }

    function irBloque(b) {
        window.location.href = `test_mmpi.php?bloque=${b}`;
    }
    </script>

    <footer class="main-footer">
    <div style="max-width: 1200px; margin: auto;">
        <p><strong>CMS-GP | Portal de Salud Emocional</strong></p>
        <p>Desarrollado por Alberto Félix © <?php echo date('Y'); ?>. Todos los derechos reservados.</p>
        <p style="font-size: 0.75rem; margin-top: 10px;">La información contenida en este portal es confidencial y está protegida por la ley de protección de datos personales.</p>
    </div>
</footer>

</body>
</html>