<?php
// guardar_respuestas_bloque.php
session_start();
require '../../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['paciente_id'])) {
    $paciente_id = $_SESSION['paciente_id'];
    
    try {
        $pdo->beginTransaction();

        foreach ($_POST as $key => $value) {
            // Buscamos los inputs que empiezan con "p_" (ej. p_1, p_2...)
            if (strpos($key, 'p_') === 0) {
                $pregunta_id = str_replace('p_', '', $key);
                $respuesta = (int)$value;

                // Insertar o actualizar si el paciente cambia de opinión al retroceder
                $stmt = $pdo->prepare("INSERT INTO mmpi2_respuestas (paciente_id, pregunta_id, respuesta) 
                                       VALUES (?, ?, ?) 
                                       ON DUPLICATE KEY UPDATE respuesta = VALUES(respuesta)");
                $stmt->execute([$paciente_id, $pregunta_id, $respuesta]);
            }
        }

        $pdo->commit();
        echo "success";
    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo "Error: " . $e->getMessage();
    }
}