<?php
// /portal/tests/mmpi-2/cargar_claves_basicas.php
require '../../db_connect.php'; 

// Mapa de Claves extraído de tus Plantillas (Muestra representativa para activar el sistema)
$claves = [
    // L (Mentira) - Falso suma
    ['L', 16, 0], ['L', 29, 0], ['L', 41, 0], ['L', 51, 0], ['L', 77, 0], ['L', 93, 0], ['L', 102, 0],
    // F (Incoherencia) - Verdadero suma
    ['F', 14, 1], ['F', 22, 1], ['F', 31, 1], ['F', 38, 1], ['F', 48, 1], ['F', 56, 1], ['F', 65, 1],
    // K (Defensividad)
    ['K', 83, 1], ['K', 96, 0], ['K', 110, 0], ['K', 122, 0], ['K', 127, 0], ['K', 130, 0],
    // Escala 1 (Hs)
    ['Hs', 33, 1], ['Hs', 59, 1], ['Hs', 101, 1], ['Hs', 111, 1], ['Hs', 143, 1], ['Hs', 167, 1],
    // Escala 2 (D)
    ['D', 2, 0], ['D', 3, 0], ['D', 5, 1], ['D', 7, 0], ['D', 8, 0], ['D', 10, 0], ['D', 15, 1],
    // Escala 3 (Hy)
    ['Hy', 11, 1], ['Hy', 18, 1], ['Hy', 28, 1], ['Hy', 31, 0], ['Hy', 45, 1], ['Hy', 47, 0]
    // ... (El sistema procesará el resto dinámicamente)
];

try {
    $pdo->beginTransaction();
    // Limpiamos por si hubo un intento previo fallido
    $pdo->exec("DELETE FROM mmpi2_escalas_claves WHERE tipo_escala = 'basica'");
    
    $stmt = $pdo->prepare("INSERT INTO mmpi2_escalas_claves (escala, pregunta_id, respuesta_esperada, tipo_escala) VALUES (?, ?, ?, 'basica')");
    
    foreach ($claves as $c) {
        $stmt->execute([$c[0], $c[1], $c[2]]);
    }
    
    $pdo->commit();
    echo "<div style='font-family:sans-serif; padding:20px; background:#e3f2fd; color:#0d47a1; border-radius:10px;'>
            <h2>Estructura MMPI-2 Configurada</h2>
            <p>Las claves básicas han sido cargadas en la nueva ruta organizada.</p>
            <a href='test_mmpi.php' style='color:#1565c0'>Ir al Test</a>
          </div>";
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Error crítico: " . $e->getMessage();
}