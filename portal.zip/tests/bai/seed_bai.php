<?php
// tests/bai/seed_bai.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión manual para evitar redirecciones de otros archivos
$host = 'localhost';
$db   = 'cms-gp'; // Verifica que sea el nombre de tu BD
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
try {
     $pdo_test = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (\PDOException $e) {
     die("Error de conexión: " . $e->getMessage());
}

$paciente_id = 1;

try {
    // Limpiar
    $pdo_test->prepare("DELETE FROM bai_respuestas WHERE paciente_id = ?")->execute([$paciente_id]);

    // Insertar 21 respuestas aleatorias
    $stmt = $pdo_test->prepare("INSERT INTO bai_respuestas (paciente_id, pregunta_id, respuesta) VALUES (?, ?, ?)");

    for ($i = 1; $i <= 21; $i++) {
        $stmt->execute([$paciente_id, $i, rand(0, 3)]);
    }

    echo "<div style='font-family:sans-serif; text-align:center; margin-top:50px;'>";
    echo "<h2 style='color:green;'>✅ ¡Prueba generada!</h2>";
    echo "<p>Se insertaron respuestas aleatorias para el paciente 1.</p>";
    echo "<a href='interpretar_bai.php?id=$paciente_id' style='padding:15px; background:#40E0D0; color:black; text-decoration:none; font-weight:bold; border-radius:5px;'>VER INFORME BAI AHORA</a>";
    echo "</div>";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}