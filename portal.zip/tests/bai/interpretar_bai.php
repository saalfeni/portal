<?php
require '../../db_connect.php';
require '../../config_admin.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }

// 1. Validar Sesión y ID
if (!isset($_SESSION['admin_logged_in'])) { header('Location: ../../admin_login.php'); exit; }

$paciente_id = $_GET['id'] ?? null;
if (!$paciente_id) die("ID de paciente no válido.");

// 2. Obtener datos del paciente
$stmt_p = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt_p->execute([$paciente_id]);
$paciente = $stmt_p->fetch();

// 3. Obtener respuestas detalladas para el desglose
$stmt_r = $pdo->prepare("SELECT * FROM bai_respuestas WHERE paciente_id = ? ORDER BY pregunta_id ASC");
$stmt_r->execute([$paciente_id]);
$respuestas = $stmt_r->fetchAll();

// Calcular Puntaje Total
$puntaje = 0;
foreach($respuestas as $res) { $puntaje += $res['respuesta']; }

// 4. Lógica de Interpretación Clínica (Baremos de Beck)
if ($puntaje <= 7) {
    $rango = "Ansiedad Mínima";
    $color = "#2ecc71";
    $desc = "El nivel de ansiedad reportado se encuentra dentro de los límites normales.";
} elseif ($puntaje <= 15) {
    $rango = "Ansiedad Leve";
    $color = "#f1c40f";
    $desc = "Se detectan síntomas de ansiedad leve que podrían requerir monitoreo.";
} elseif ($puntaje <= 25) {
    $rango = "Ansiedad Moderada";
    $color = "#e67e22";
    $desc = "Existen síntomas clínicos de ansiedad moderada. Se sugiere intervención.";
} else {
    $rango = "Ansiedad Grave";
    $color = "#e74c3c";
    $desc = "Niveles de ansiedad significativamente altos. Requiere atención inmediata.";
}

// Diccionario de síntomas del BAI para el reporte
$sintomas = [
    1 => "Subjetivo de entumecimiento u hormigueo", 2 => "Sensación de calor", 3 => "Temblor de piernas",
    4 => "Incapacidad para relajarse", 5 => "Temor a que suceda lo peor", 6 => "Mareo o aturdimiento",
    7 => "Palpitaciones o taquicardia", 8 => "Inestabilidad", 9 => "Terror", 10 => "Nerviosismo",
    11 => "Sensación de ahogo", 12 => "Temblores de manos", 13 => "Inestabilidad / Tembloroso",
    14 => "Miedo a perder el control", 15 => "Dificultad para respirar", 16 => "Miedo a morir",
    17 => "Asustado", 18 => "Indigestión o malestar abdominal", 19 => "Desmayos",
    20 => "Rubor facial", 21 => "Sudoración (no debida al calor)"
];

$opciones = [0 => "Nada", 1 => "Levemente", 2 => "Moderadamente", 3 => "Severamente"];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Informe BAI - <?php echo htmlspecialchars($paciente['nombre_completo']); ?></title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f9f9f9; padding: 30px; }
        .page { background: #fff; max-width: 850px; margin: 0 auto; padding: 50px; box-shadow: 0 0 10px rgba(0,0,0,0.1); border-radius: 8px; }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #333; padding-bottom: 20px; }
        .score-circle { width: 120px; height: 120px; border-radius: 50%; border: 5px solid <?php echo $color; ?>; display: flex; flex-direction: column; align-items: center; justify-content: center; margin: 30px auto; }
        .score-num { font-size: 2.5rem; font-weight: bold; color: <?php echo $color; ?>; }
        .inter-label { text-align: center; font-size: 1.4rem; font-weight: bold; color: <?php echo $color; ?>; text-transform: uppercase; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 30px; font-size: 0.9rem; }
        th { background: #f4f4f4; text-align: left; padding: 10px; border-bottom: 2px solid #ddd; }
        td { padding: 8px 10px; border-bottom: 1px solid #eee; }
        .val-column { width: 100px; text-align: center; font-weight: bold; }
        @media print { .no-print { display: none; } body { background: #fff; padding: 0; } .page { box-shadow: none; width: 100%; } }
    </style>
</head>
<body>
    <div class="page">
        <div class="header">
            <div>
                <h1 style="margin:0;">Inventario de Ansiedad de Beck</h1>
                <p style="color:#666;">Reporte Clínico de Resultados (BAI)</p>
            </div>
            <div style="text-align: right; font-size: 0.9rem;">
                <strong>Paciente:</strong> <?php echo htmlspecialchars($paciente['nombre_completo']); ?><br>
                <strong>Fecha:</strong> <?php echo date('d/m/Y'); ?><br>
                <strong>ID:</strong> #<?php echo str_pad($paciente['id'], 4, "0", STR_PAD_LEFT); ?>
            </div>
        </div>

        <div class="score-circle">
            <span style="font-size: 0.7rem; color: #888;">PUNTAJE</span>
            <div class="score-num"><?php echo $puntaje; ?></div>
        </div>
        <div class="inter-label"><?php echo $rango; ?></div>
        
        <div style="background: #fcfcfc; border-left: 4px solid <?php echo $color; ?>; padding: 15px; font-style: italic; color: #444;">
            <?php echo $desc; ?>
        </div>

        

        <h3>Desglose de Síntomas</h3>
        <table>
            <thead>
                <tr>
                    <th>Ítem / Síntoma</th>
                    <th class="val-column">Respuesta</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($respuestas as $r): ?>
                <tr>
                    <td><?php echo $r['pregunta_id'] . ". " . ($sintomas[$r['pregunta_id']] ?? "Síntoma " . $r['pregunta_id']); ?></td>
                    <td class="val-column" style="color: <?php echo ($r['respuesta'] >= 2) ? '#e74c3c' : '#333'; ?>;">
                        <?php echo $opciones[$r['respuesta']] ?? $r['respuesta']; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="margin-top: 40px; font-size: 0.85rem; color: #777; line-height: 1.5;">
            <p><strong>Nota técnica:</strong> El BAI es un instrumento de autoinforme diseñado para medir la severidad de los síntomas de ansiedad. Los resultados deben ser interpretados por un profesional de la salud mental en conjunto con la historia clínica del paciente.</p>
        </div>

        <div class="no-print" style="margin-top: 40px; text-align: center;">
            <button onclick="window.print()" style="background: #333; color: #fff; padding: 12px 25px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold;">
                <i class="fas fa-print"></i> Imprimir Informe
            </button>
        </div>
    </div>
</body>
</html>