<?php
require_once '../../db_connect.php';

if (!isset($_SESSION['paciente_id'])) {
    header("Location: ../../index.php");
    exit;
}

$paciente_id = $_SESSION['paciente_id'];

// Procesar envío
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $respuestas = $_POST['p'] ?? [];
    if (count($respuestas) === 21) {
        $pdo->prepare("DELETE FROM bai_respuestas WHERE paciente_id = ?")->execute([$paciente_id]);
        $stmt = $pdo->prepare("INSERT INTO bai_respuestas (paciente_id, pregunta_id, respuesta) VALUES (?, ?, ?)");
        foreach ($respuestas as $p_id => $val) {
            $stmt->execute([$paciente_id, $p_id, $val]);
        }
        header("Location: ../../paciente_dashboard.php?status=bai_ok");
        exit;
    }
}

// Obtener preguntas
$preguntas = $pdo->query("SELECT * FROM bai_preguntas ORDER BY id ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario de Ansiedad (BAI) | CMS-GP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --bg: #121212; --card: #1e1e1e; --turquesa: #40E0D0; --text: #e0e0e0; }
        body { background: var(--bg); color: var(--text); font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: auto; }
        .header { text-align: center; margin-bottom: 30px; }
        .question-card { background: var(--card); padding: 20px; border-radius: 12px; margin-bottom: 15px; border-left: 4px solid var(--turquesa); }
        .options { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-top: 15px; }
        .option { background: #252525; padding: 10px; border-radius: 8px; cursor: pointer; text-align: center; font-size: 0.85rem; transition: 0.3s; border: 1px solid #333; }
        .option:hover { border-color: var(--turquesa); }
        input[type="radio"] { display: none; }
        input[type="radio"]:checked + .option { background: var(--turquesa); color: #000; font-weight: bold; }
        .btn-submit { width: 100%; padding: 15px; background: var(--turquesa); border: none; border-radius: 8px; font-weight: bold; cursor: pointer; margin-top: 20px; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Inventario de Ansiedad de Beck</h1>
        <p>Indique cuánto le ha molestado cada síntoma durante la última semana.</p>
    </div>
    <form method="POST">
        <?php foreach ($preguntas as $pre): ?>
        <div class="question-card">
            <strong><?php echo $pre['id']; ?>. <?php echo $pre['titulo']; ?></strong>
            <div class="options">
                <?php for($i=0; $i<=3; $i++): ?>
                <label>
                    <input type="radio" name="p[<?php echo $pre['id']; ?>]" value="<?php echo $i; ?>" required>
                    <div class="option"><?php echo $pre['opcion_'.$i]; ?></div>
                </label>
                <?php endfor; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <button type="submit" class="btn-submit">Finalizar Test</button>
    </form>
</div>
</body>
</html>