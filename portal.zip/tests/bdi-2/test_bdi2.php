<?php
// /portal/tests/bdi-2/test_bdi2.php
session_start();
require '../../db_connect.php';

// 1. Seguridad: Verificar sesión de paciente
if (!isset($_SESSION['paciente_id'])) {
    header("Location: ../../login_paciente.php");
    exit;
}
$paciente_id = $_SESSION['paciente_id'];

// Obtener datos básicos del paciente para el encabezado (opcional)
$stmt = $pdo->prepare("SELECT nombre_completo FROM pacientes WHERE id = ?");
$stmt->execute([$paciente_id]);
$paciente = $stmt->fetch();

// 2. Procesar Guardado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        // Limpiamos respuestas anteriores
        $stmt_del = $pdo->prepare("DELETE FROM bdi2_respuestas WHERE paciente_id = ?");
        $stmt_del->execute([$paciente_id]);

        $stmt_ins = $pdo->prepare("INSERT INTO bdi2_respuestas (paciente_id, pregunta_id, puntuacion, fecha_guardado) VALUES (?, ?, ?, NOW())");
        
        foreach ($_POST['resp'] as $preg_id => $puntos) {
            $stmt_ins->execute([$paciente_id, $preg_id, $puntos]);
        }
        
        $pdo->commit();
        header("Location: ../../paciente_dashboard.php?mensaje=test_bdi_ok");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error al guardar: " . $e->getMessage();
    }
}

// 3. Obtener Preguntas
$preguntas = $pdo->query("SELECT * FROM bdi2_preguntas ORDER BY id ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario BDI-II | Evaluación Clínica</title>
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --bg-dark: #121212;       
            --card-bg: #1e1e1e;       
            --text-main: #e0e0e0;     
            --text-muted: #a0a0a0;    
            --accent: #40E0D0;        /* Turquesa Clínico */
            --accent-hover: #2ac7b8;
            --border-color: #333;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* --- HEADER ADAPTADO (Estilo Dashboard pero Dark) --- */
        header {
            background-color: var(--card-bg);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid var(--accent);
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--text-main);
        }

        .brand-logo img {
            height: 40px;
            width: auto;
        }

        .header-info {
            text-align: right;
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .header-info span {
            display: block;
            color: var(--accent);
            font-weight: 600;
        }

        /* --- CONTENEDOR PRINCIPAL --- */
        .main-content {
            flex: 1;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }

        .test-container {
            width: 100%;
            max-width: 850px;
            background: var(--card-bg);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            border: 1px solid var(--border-color);
            position: relative;
        }

        h1 {
            color: var(--accent);
            text-align: center;
            font-weight: 300;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }

        .instrucciones {
            background: rgba(64, 224, 208, 0.08);
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid var(--accent);
            margin-bottom: 40px;
            color: var(--text-main);
        }

        /* --- ITEMS DEL TEST --- */
        .item-block {
            margin-bottom: 35px;
            padding: 20px;
            border-radius: 8px;
            background: rgba(255,255,255,0.02);
            border: 1px solid transparent;
            transition: border-color 0.3s;
        }
        
        .item-block:hover {
            border-color: rgba(64, 224, 208, 0.3);
        }

        .item-title {
            font-weight: 600;
            font-size: 1.1em;
            color: var(--accent);
            margin-bottom: 20px;
            display: block;
        }

        .option-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .option-label {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            background: #252525;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s ease;
            color: var(--text-muted);
        }

        .option-label:hover {
            background: #2a2a2a;
            color: var(--text-main);
            border-color: var(--accent);
        }

        /* Radio Buttons Customizados */
        input[type="radio"] {
            appearance: none;
            width: 18px;
            height: 18px;
            border: 2px solid var(--text-muted);
            border-radius: 50%;
            margin-right: 15px;
            position: relative;
            outline: none;
            cursor: pointer;
        }

        input[type="radio"]:checked {
            border-color: var(--accent);
        }

        input[type="radio"]:checked::after {
            content: '';
            width: 10px;
            height: 10px;
            background: var(--accent);
            border-radius: 50%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .option-label:has(input:checked) {
            background: rgba(64, 224, 208, 0.1);
            border-color: var(--accent);
            color: white;
        }
        
        /* Fallback para compatibilidad */
        input:checked + span { color: white; font-weight: 500; }

        .btn-submit {
            display: block;
            width: 100%;
            padding: 18px;
            background: var(--accent);
            color: #121212;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-top: 40px;
            text-transform: uppercase;
        }

        .btn-submit:hover {
            background: var(--accent-hover);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(64, 224, 208, 0.4);
        }

        /* --- FOOTER ADAPTADO --- */
        footer {
            background-color: var(--card-bg);
            color: var(--text-muted);
            text-align: center;
            padding: 20px;
            border-top: 1px solid var(--border-color);
            font-size: 0.85rem;
            margin-top: auto;
        }

        /* --- BARRA DE PROGRESO --- */
        .progress-indicator {
            height: 4px;
            background: #333;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .progress-fill {
            height: 100%;
            background: var(--accent);
            width: 0%;
            transition: width 0.3s;
            box-shadow: 0 0 10px var(--accent);
        }
    </style>
</head>
<body>

<div class="progress-indicator"><div class="progress-fill" id="progressBar"></div></div>

<header>
    <div class="brand-logo">
        <img src="../../assets/img/logo.png" alt="Logo CMS-GP">
        <span>CMS-GP</span>
    </div>
    <div class="header-info">
        <span>
            <?php 
            // Solución robusta para fecha en español sin usar strftime
            $dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
            $meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
            
            $dia_semana = $dias[date('w')];
            $dia_mes = date('j');
            $mes = $meses[date('n')];
            $anio = date('Y');
            
            echo "$dia_semana, $dia_mes de $mes de $anio";
            ?>
        </span>
        Paciente: <?php echo htmlspecialchars($paciente['nombre_completo'] ?? 'Invitado'); ?>
    </div>
</header>

<div class="main-content">
    <div class="test-container">
        <h1>Inventario Clínico BDI-II</h1>
        
        <div class="instrucciones">
            <i class="fas fa-info-circle"></i> <strong>Instrucciones:</strong><br>
            Lea cuidadosamente cada grupo de afirmaciones y seleccione la opción que mejor describa <strong>cómo se ha sentido durante las últimas dos semanas</strong>, incluyendo el día de hoy.
        </div>

        <?php if(isset($error)) echo "<div style='color:red;text-align:center;'>$error</div>"; ?>

        <form method="POST" id="bdiForm">
            <?php foreach($preguntas as $p): ?>
                <div class="item-block">
                    <span class="item-title"><?php echo $p['id']; ?>. <?php echo htmlspecialchars($p['titulo']); ?></span>
                    <div class="option-group">
                        <?php for($i=0; $i<=3; $i++): ?>
                        <label class="option-label">
                            <input type="radio" name="resp[<?php echo $p['id']; ?>]" value="<?php echo $i; ?>" required onclick="updateProgress()">
                            <span><?php echo htmlspecialchars($p['opcion_'.$i]); ?></span>
                        </label>
                        <?php endfor; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <button type="submit" class="btn-submit">Finalizar y Guardar Evaluación</button>
        </form>
    </div>
</div>

<footer>
    <div class="footer-content">
        <p><strong>CMS-GP: Gestión Psicológica Profesional</strong></p>
        <p>Desarrollado por Alberto Félix © <?php echo date('Y'); ?>. Todos los derechos reservados.</p>
        <p style="font-size: 0.75rem; margin-top: 5px; opacity: 0.6;">Información confidencial protegida por normas de salud mental.</p>
    </div>
</footer>

<script>
    function updateProgress() {
        const total = <?php echo count($preguntas); ?>;
        const checked = document.querySelectorAll('input[type="radio"]:checked').length;
        const percent = (checked / total) * 100;
        document.getElementById('progressBar').style.width = percent + '%';
    }
</script>

</body>
</html>