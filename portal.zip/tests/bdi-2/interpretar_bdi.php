<?php
// /portal/tests/bdi-2/interpretar_bdi.php
session_start();
require '../../db_connect.php';

// 1. Seguridad: Solo administrador
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    die("Acceso denegado.");
}

$paciente_id = $_GET['id'] ?? null;
if (!$paciente_id) die("ID de paciente no proporcionado.");

// 2. Datos del Paciente
$stmt = $pdo->prepare("SELECT nombre_completo, genero FROM pacientes WHERE id = ?");
$stmt->execute([$paciente_id]);
$paciente = $stmt->fetch();
$nombre = $paciente['nombre_completo'];

// 3. Obtener Respuestas y Calcular Puntuación
$stmt_res = $pdo->prepare("
    SELECT r.puntuacion, p.id as num_pregunta, p.titulo, 
           CASE r.puntuacion 
               WHEN 0 THEN p.opcion_0 
               WHEN 1 THEN p.opcion_1 
               WHEN 2 THEN p.opcion_2 
               WHEN 3 THEN p.opcion_3 
           END as texto_respuesta
    FROM bdi2_respuestas r
    JOIN bdi2_preguntas p ON r.pregunta_id = p.id
    WHERE r.paciente_id = ?
    ORDER BY p.id ASC
");
$stmt_res->execute([$paciente_id]);
$respuestas = $stmt_res->fetchAll();

$total_score = 0;
$riesgo_suicida = null;

foreach ($respuestas as $r) {
    $total_score += $r['puntuacion'];
    // El ítem 9 es el de Pensamientos Suicidas
    if ($r['num_pregunta'] == 9 && $r['puntuacion'] > 0) {
        $riesgo_suicida = [
            'nivel' => $r['puntuacion'],
            'texto' => $r['texto_respuesta']
        ];
    }
}

// 4. Determinar Nivel Clínico
$diagnostico = "";
$color_clase = "";
$ancho_barra = 0; // Para la gráfica visual (0-100%)

if ($total_score <= 13) {
    $diagnostico = "Depresión Mínima";
    $color_clase = "bg-success"; // Verde
    $ancho_barra = 20;
} elseif ($total_score <= 19) {
    $diagnostico = "Depresión Leve";
    $color_clase = "bg-warning"; // Amarillo
    $ancho_barra = 45;
} elseif ($total_score <= 28) {
    $diagnostico = "Depresión Moderada";
    $color_clase = "bg-orange"; // Naranja
    $ancho_barra = 70;
} else {
    $diagnostico = "Depresión Grave";
    $color_clase = "bg-danger"; // Rojo
    $ancho_barra = 100;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte BDI-II: <?php echo htmlspecialchars($nombre); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
      tinymce.init({
        selector: '.wysiwyg', menubar: false, branding: false, promotion: false,
        plugins: 'lists', toolbar: 'bold italic | bullist numlist',
        height: 200
      });
    </script>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f4f7f9; padding: 20px; color: #333; }
        .page { max-width: 900px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        
        .header { border-bottom: 3px solid #40E0D0; padding-bottom: 15px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
        .score-box { text-align: center; padding: 20px; border-radius: 8px; color: white; margin-bottom: 30px; }
        
        .bg-success { background: linear-gradient(135deg, #2ecc71, #27ae60); }
        .bg-warning { background: linear-gradient(135deg, #f1c40f, #f39c12); }
        .bg-orange  { background: linear-gradient(135deg, #e67e22, #d35400); }
        .bg-danger  { background: linear-gradient(135deg, #e74c3c, #c0392b); }

        .score-number { font-size: 3.5em; font-weight: bold; line-height: 1; }
        .score-label { font-size: 1.2em; text-transform: uppercase; letter-spacing: 1px; margin-top: 5px; }

        .alert-suicidio {
            border: 2px solid #c0392b; background-color: #fadbd8; color: #721c24;
            padding: 15px; border-radius: 8px; margin-bottom: 30px; display: flex; align-items: center; gap: 15px;
        }

        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 0.9em; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background-color: #f8f9fa; color: #555; }
        .score-cell { font-weight: bold; text-align: center; width: 50px; }
        
        /* Gráfico de Termómetro CSS */
        .thermometer-container { height: 30px; background: #ecf0f1; border-radius: 15px; overflow: hidden; margin: 20px 0; position: relative; }
        .thermometer-fill { height: 100%; transition: width 1s ease-in-out; }
        
        .btn-print { background: #34495e; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; float: right; }
        
        @media print { .btn-print, .wysiwyg-container { display: none; } body { background: white; } .page { box-shadow: none; margin: 0; padding: 0; } }
    </style>
</head>
<body>

<div class="page">
    <div class="header">
        <div>
            <h1 style="margin:0; color: #2c3e50;">Inventario de Depresión de Beck (BDI-II)</h1>
            <p style="margin:5px 0 0 0; color: #7f8c8d;">Paciente: <strong><?php echo htmlspecialchars($nombre); ?></strong> | Fecha: <?php echo date('d/m/Y'); ?></p>
        </div>
        <button onclick="window.print()" class="btn-print">🖨️ Imprimir / PDF</button>
    </div>

    <div class="score-box <?php echo $color_clase; ?>">
        <div class="score-number"><?php echo $total_score; ?></div>
        <div class="score-label"><?php echo $diagnostico; ?></div>
    </div>

    <?php if ($riesgo_suicida): ?>
    <div class="alert-suicidio">
        <span style="font-size: 2em;">⚠️</span>
        <div>
            <strong>ATENCIÓN CLÍNICA REQUERIDA: Indicador de Ideación Suicida</strong><br>
            El paciente respondió al Ítem 9: <em>"<?php echo htmlspecialchars($riesgo_suicida['texto']); ?>"</em> (Puntos: <?php echo $riesgo_suicida['nivel']; ?>)
        </div>
    </div>
    <?php endif; ?>

    <h3>Escala de Severidad</h3>
    <div class="thermometer-container">
        <div class="thermometer-fill <?php echo $color_clase; ?>" style="width: <?php echo $ancho_barra; ?>%;"></div>
    </div>
    <div style="display: flex; justify-content: space-between; font-size: 0.8em; color: #7f8c8d; margin-top: -15px;">
        <span>0 (Mínima)</span>
        <span>14 (Leve)</span>
        <span>20 (Moderada)</span>
        <span>29 (Grave)</span>
        <span>63 (Máx)</span>
    </div>

    <h3 style="margin-top: 40px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Desglose de Ítems</h3>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Área Evaluada</th>
                <th>Respuesta del Paciente</th>
                <th class="score-cell">Pts</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($respuestas as $r): ?>
            <tr style="<?php echo ($r['puntuacion'] >= 2) ? 'background-color: #fff8e1;' : ''; ?>">
                <td><?php echo $r['num_pregunta']; ?></td>
                <td><strong><?php echo htmlspecialchars($r['titulo']); ?></strong></td>
                <td><?php echo htmlspecialchars($r['texto_respuesta']); ?></td>
                <td class="score-cell"><?php echo $r['puntuacion']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h3 style="margin-top: 40px;">Notas de Evolución</h3>
    <textarea class="wysiwyg" placeholder="Escriba aquí sus observaciones clínicas sobre este resultado..."></textarea>
</div>

</body>
</html>