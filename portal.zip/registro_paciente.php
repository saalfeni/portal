<?php
// registro_paciente.php - Portal Público de Registro de Pacientes

// 🚨 SOLUCIÓN A PROBLEMAS DE ACENTOS Y CARACTERES ESPECIALES (Debe ser la primera línea enviada)
header('Content-Type: text/html; charset=utf-8'); 

session_start();
require 'db_connect.php'; 

// 🚨 SEGURIDAD: REDIRIGIR SI NO HAY TOKEN VÁLIDO EN SESIÓN
if (!isset($_SESSION['registro_token'])) {
    header('Location: paciente_dashboard.php?registro=exitoso');
    exit;
}

$mensaje_estado = "";
$fecha_registro = date("Y-m-d H:i:s");

// =========================================================
// INICIO DE PROCESAMIENTO POST
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Función de sanitización básica
    function sanitize($data) {
        return htmlspecialchars(strip_tags(trim($data)));
    }

    // --- A. Motivo de Consulta ---
    $motivo_consulta_data = [
        'motivo_explicito' => sanitize($_POST['motivo_consulta'] ?? ''),
        'tiempo_problema' => sanitize($_POST['tiempo_problema'] ?? ''),
        'expectativas' => sanitize($_POST['expectativas'] ?? ''),
    ];

    // --- B. Historial Relacional ---
    $relacional_data = [
        'estado_civil' => sanitize($_POST['estado_civil'] ?? ''),
        'nombre_vinculo' => sanitize($_POST['nombre_vinculo'] ?? ''),
        'relacion_tiempo_duracion' => sanitize($_POST['tiempo_duracion'] ?? ''),
        'separacion_tiempo' => sanitize($_POST['tiempo_separacion'] ?? ''),
        'separacion_causas' => sanitize($_POST['causas_separacion'] ?? ''),
        'tiene_hijos' => sanitize($_POST['tiene_hijos'] ?? 'No'),
        'hijos_detalle' => sanitize($_POST['hijos_detalle'] ?? ''),
        'relacion_origen' => sanitize($_POST['relacion_origen'] ?? ''),
    ];

    // --- C. Historial de Sustancias ---
    $sustancias_data = [
        'fuma' => sanitize($_POST['fuma'] ?? 'No'),
        'alcohol' => sanitize($_POST['alcohol'] ?? 'No'),
        'drogas_uso' => sanitize($_POST['drogas_alguna_vez'] ?? 'No'), 
        'drogas_tipo' => sanitize($_POST['drogas_tipo'] ?? ''),
        'drogas_ultimo_consumo' => sanitize($_POST['drogas_ultimo_consumo'] ?? ''),
    ];
    
    // --- D. Antecedentes Clínicos ---
    $antecedentes_clinicos_data = [
        'terapia_previa_bool' => sanitize($_POST['terapia_previa_bool'] ?? 'No'),
        'terapia_tiempo_duracion' => sanitize($_POST['terapia_duracion'] ?? ''),
        'terapia_tiempo_transcurrido' => sanitize($_POST['terapia_transcurrido'] ?? ''),
        'terapia_causas' => sanitize($_POST['terapia_causas'] ?? ''),
        'terapia_motivo_finalizacion' => sanitize($_POST['terapia_motivo_finalizacion'] ?? ''),
        'ant_psiquiatricos' => sanitize($_POST['ant_psiquiatricos'] ?? 'No'),
        'medicacion_psiquiatrica' => sanitize($_POST['medicacion'] ?? ''),
        'enfermedades_cronicas' => sanitize($_POST['enfermedades_cronicas'] ?? 'No'),
        'calidad_sueno' => sanitize($_POST['calidad_sueno'] ?? ''),
        'soporte_social' => sanitize($_POST['soporte_social'] ?? ''),
    ];

    // --- E. Datos de Contacto Fijos ---
    $contacto_data = [
        'telefono_contacto' => sanitize($_POST['tel_contacto'] ?? ''),
        'telefono_emergencia' => sanitize($_POST['tel_emergencia'] ?? ''),
        'relacion_emergencia' => sanitize($_POST['rel_emergencia'] ?? ''),
    ];


    // 2. CONSTRUCCIÓN DEL ARRAY PARA LA TABLA PACIENTES
    $datos_paciente = [
        'nombre_completo' => sanitize($_POST['nombre_completo'] ?? ''),
        'email' => sanitize($_POST['email'] ?? ''),
        'fecha_nacimiento' => sanitize($_POST['fecha_nacimiento'] ?? ''),
        'ultimo_grado_estudios' => sanitize($_POST['grado_estudios'] ?? ''),
        'ocupacion' => sanitize($_POST['ocupacion'] ?? ''),
        'aceptacion_consentimiento' => isset($_POST['consentimiento']) ? 1 : 0,

        // Datos JSON (Codificación)
        'motivo_consulta' => json_encode($motivo_consulta_data),
        'historial_relacional' => json_encode($relacional_data),
        'historial_sustancias' => json_encode($sustancias_data),
        'antecedentes_clinicos' => json_encode($antecedentes_clinicos_data),
        'datos_contacto' => json_encode($contacto_data),
    ];

    // 3. INSERCIÓN DE DATOS REAL (PDO)
    if ($pdo) {
        $sql = "INSERT INTO pacientes (
            nombre_completo, email, fecha_nacimiento, ultimo_grado_estudios, ocupacion,
            motivo_consulta, historial_relacional, historial_sustancias, antecedentes_clinicos, 
            datos_contacto, aceptacion_consentimiento
        ) VALUES (
            :nombre_completo, :email, :fecha_nacimiento, :grado_estudios, :ocupacion,
            :motivo_consulta, :historial_relacional, :historial_sustancias, :antecedentes_clinicos, 
            :datos_contacto, :consentimiento_bool
        )";
        
        try {
            $stmt = $pdo->prepare($sql);
            
            $params = [
                ':nombre_completo' => $datos_paciente['nombre_completo'],
                ':email' => $datos_paciente['email'],
                ':fecha_nacimiento' => $datos_paciente['fecha_nacimiento'],
                ':grado_estudios' => $datos_paciente['ultimo_grado_estudios'],
                ':ocupacion' => $datos_paciente['ocupacion'],
                ':motivo_consulta' => $datos_paciente['motivo_consulta'],
                ':historial_relacional' => $datos_paciente['historial_relacional'],
                ':historial_sustancias' => $datos_paciente['historial_sustancias'],
                ':antecedentes_clinicos' => $datos_paciente['antecedentes_clinicos'],
                ':datos_contacto' => $datos_paciente['datos_contacto'],
                ':consentimiento_bool' => $datos_paciente['aceptacion_consentimiento'],
            ];
            
            $stmt->execute($params);
            
            $last_id = $pdo->lastInsertId();
            
            // 🚨 LÓGICA DE TOKEN: MARCAR COMO USADO
            $token_usado = $_SESSION['registro_token'];
            $stmt_token = $pdo->prepare("UPDATE tokens_registro SET usado = 1, fecha_uso = NOW() WHERE token = ?");
            $stmt_token->execute([$token_usado]);
            
            // Limpiar la sesión para evitar que se use el mismo token
            unset($_SESSION['registro_token']);

            $mensaje_estado = "
                <div class='alerta exito'>
                    <h3>🎉 ¡Registro Exitoso!</h3>
                    <p>El paciente ha sido registrado con el ID: <strong>#{$last_id}</strong>. Gracias por completar el formulario.</p>
                </div>
            ";

        } catch (\PDOException $e) {
            $error_message = ($e->getCode() == 23000) ? "El correo electrónico ya existe en la base de datos." : $e->getMessage();
            $mensaje_estado = "
                <div class='alerta error'>
                    <h3>�?Error al Registrar</h3>
                    <p>Ha ocurrido un problema al guardar los datos: {$error_message}</p>
                </div>
            ";
        }
    } else {
        $mensaje_estado = "
            <div class='alerta error'>
                <h3>�?Error Crítico</h3>
                <p>La conexión a la base de datos no está disponible. Revise las credenciales en <code>db_connect.php</code>.</p>
            </div>
        ";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Paciente - CMS-GP</title>
    <link rel="stylesheet" href="admin_styles.css?v=1.1"> 
	<style>
        :root {
            --primary: #19aca9;
            --dark: #1e272e;
            --card-bg: #2f3542;
            --text-main: #ffffff;
            --text-grey: #96969a;
            --section-bg: #3c4556; /* Nuevo color para el fondo de las secciones */
            --accent-light: #38b8b5;
        }
        body { 
            background-color: var(--dark); 
            color: var(--text-grey); 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            padding: 20px; 
        }
        .container { 
            max-width: 700px; 
            margin: 0 auto; 
            background: var(--card-bg); 
            padding: 30px; 
            border-radius: 12px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.4); 
            position: relative; /* Para posicionar el logo */
        }
        
        /* LOGO Y TÍTULOS */
        .logo-container { position: absolute; top: 20px; left: 20px; display: block; z-index: 10; }
        .logo-container .logo { width: 50px; height: auto; opacity: 0.8; }
        h1 { color: var(--primary); text-align: center; font-size: 1.8em; margin: 0 0 15px 0; padding-top: 5px; }
        h2 { 
            color: var(--text-main); 
            font-size: 1.2em; 
            margin-top: 35px; 
            margin-bottom: 15px;
            background: var(--section-bg);
            padding: 10px 15px;
            border-left: 5px solid var(--primary); 
            border-radius: 4px;
        }
        .info-registro { text-align: right; font-size: 0.8em; color: var(--text-grey); margin-bottom: 20px;}
        .info-registro strong { color: var(--text-main); }


        /* CAMPOS DE FORMULARIO */
        .campo { margin-bottom: 20px; }
        label { display: block; margin-bottom: 6px; color: var(--text-main); font-weight: 500; font-size: 0.9em; }
        input[type="text"], input[type="email"], input[type="date"], textarea, select {
            width: 100%; padding: 12px; border: 1px solid #444; border-radius: 6px;
            background: var(--section-bg); color: var(--text-main); box-sizing: border-box;
            transition: border-color 0.2s;
        }
        input[type="text"]:focus, input[type="email"]:focus, textarea:focus, select:focus {
            border-color: var(--primary);
            outline: none;
        }
        textarea { height: 80px; resize: vertical; }

        /* RADIOS Y CHECKBOXES */
        .grupo-radio { display: flex; gap: 15px; margin-top: 5px; flex-wrap: wrap; }
        .grupo-radio label { 
            display: flex; align-items: center; 
            margin-bottom: 5px; color: var(--text-grey); 
            font-weight: normal; 
        }
        input[type="radio"], input[type="checkbox"] {
            width: auto; margin-right: 5px;
            /* Estilo personalizado para un look limpio */
            accent-color: var(--primary); 
        }

        /* OPCIONES CONDICIONALES */
        .opcion-condicional { 
            margin-top: 15px; padding: 15px; border: 1px dashed var(--primary); border-radius: 6px; 
            background: rgba(25, 172, 169, 0.1); 
            display: none; /* Controlado por JS */
        }
        .opcion-condicional label { color: var(--text-main); margin-top: 10px; }

        /* BOTÓN DE ENVÍO */
        .submit-btn {
            background: var(--primary); color: var(--text-main); padding: 15px 25px; border: none;
            border-radius: 8px; font-size: 1.1em; cursor: pointer; display: block; width: 100%;
            margin-top: 30px; transition: background 0.2s, transform 0.1s;
            font-weight: bold;
        }
        .submit-btn:hover { background: var(--accent-light); }
        .submit-btn:active { transform: scale(0.98); }

        /* ALERTAS y FOOTER */
        .alerta { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .exito { background: #d4edda; color: #155724; border-color: #c3e6cb; }
        .alerta.error { background: #f8d7da; color: #721c24; border-color: #f5c6cb; }
        .main-footer {
            border-top: 1px solid #444; margin-top: 40px; padding-top: 15px;
            text-align: center; font-size: 0.8em; color: var(--text-grey);
            display: flex; justify-content: center; align-items: center; gap: 15px;
        }
        .main-footer a { color: var(--primary); text-decoration: none; }
        .main-footer .footer-logo { width: 30px; opacity: 0.5; }

    </style>
</head>
<body>
    <div class="container">
        <a href="registro_paciente.php" class="logo-container">
            <img src="assets/img/logo.png" alt="CMS-GP Logo" class="logo">
        </a>
        
        <?php echo $mensaje_estado; ?> <h1>Registro de Paciente Nuevo</h1>
        
        <form method="POST" onsubmit="return validarFormulario()">
            
            <h2>I. Datos Generales</h2>
            <div class="campo"><label for="nombre_completo">Nombre Completo:</label><input type="text" id="nombre_completo" name="nombre_completo" required></div>
            <div class="campo"><label for="email">Correo Electrónico:</label><input type="email" id="email" name="email" required></div>
			<div class="campo"><label>Cree una contrase?a para su portal</label><input type="password" name="password_paciente" required minlength="6" placeholder="M��nimo 6 caracteres"></div>
            <div class="campo"><label for="fecha_nacimiento">Fecha de Nacimiento:</label><input type="date" id="fecha_nacimiento" name="fecha_nacimiento" onchange="calcularEdad()" required></div>
            <div class="campo"><label for="edad">Edad:</label><input type="text" id="edad" name="edad" readonly placeholder="Calculada automáticamente"></div>
            <div class="campo"><label for="grado_estudios">Último Grado de Estudios:</label><input type="text" id="grado_estudios" name="grado_estudios" required></div>
            <div class="campo"><label for="ocupacion">Ocupación/Profesión:</label><input type="text" id="ocupacion" name="ocupacion" required></div>
            
            <div class="campo"><label for="tel_contacto">Teléfono (Contacto):</label><input type="text" id="tel_contacto" name="tel_contacto" required></div>
            <div class="campo"><label for="tel_emergencia">Teléfono (Emergencia):</label><input type="text" id="tel_emergencia" name="tel_emergencia"></div>
            <div class="campo"><label for="rel_emergencia">Relación con Contacto de Emergencia:</label><input type="text" id="rel_emergencia" name="rel_emergencia"></div>

            <h2>II. Motivo de Consulta</h2>
            <div class="campo"><label for="motivo_consulta">Motivo de Consulta Explícito:</label><textarea id="motivo_consulta" name="motivo_consulta" required></textarea></div>
            <div class="campo"><label for="tiempo_problema">Tiempo del Problema:</label><input type="text" id="tiempo_problema" name="tiempo_problema"></div>
            <div class="campo"><label for="expectativas">¿Qué espera lograr con la terapia?</label><textarea id="expectativas" name="expectativas"></textarea></div>

            <h2>III. Historia Familiar y Relacional</h2>
            <div class="campo">
                <label for="estado_civil">Estado Civil Actual:</label>
                <select id="estado_civil" name="estado_civil" onchange="mostrarCamposRelacionales()" required>
                    <option value="">Seleccione...</option>
                    <option value="Soltero">Soltero</option>
                    <option value="Casado">Casado</option>
                    <option value="Union Libre">Unión Libre</option>
                    <option value="Divorciado">Divorciado</option>
                    <option value="Viudo">Viudo</option>
                </select>
            </div>

            <div id="campos_relacionales" class="opcion-condicional">
                </div>
            
            <div class="campo"><label for="relacion_origen">Relación con la Familia de Origen:</label>
                <select id="relacion_origen" name="relacion_origen" required>
                    <option value="Buena">Buena</option>
                    <option value="Conflictiva">Conflictiva</option>
                    <option value="Distante">Distante</option>
                    <option value="Otra">Otra (especifique en notas)</option>
                </select>
            </div>
            
            <div class="campo">
                <label>¿Tiene hijos?</label>
                <div class="grupo-radio">
                    <label><input type="radio" name="tiene_hijos" value="Sí" onclick="mostrarHijos()"> Sí</label>
                    <label><input type="radio" name="tiene_hijos" value="No" onclick="mostrarHijos()" checked> No</label>
                </div>
            </div>
            <div id="detalle_hijos" class="opcion-condicional" style="display:none;">
                <label for="hijos_detalle">Número y Edades de los Hijos:</label>
                <textarea id="hijos_detalle" name="hijos_detalle"></textarea>
            </div>


            <h2>IV. Antecedentes Clínicos y Salud Mental</h2>
            
            <div class="campo">
                <label>Ud o algún miembro de su familia cercana han tenido alguna aproximación con la Terapia?</label>
                <div class="grupo-radio">
                    <label><input type="radio" name="terapia_previa_bool" value="Sí" onclick="mostrarTerapiaPrevia()"> Sí</label>
                    <label><input type="radio" name="terapia_previa_bool" value="No" onclick="mostrarTerapiaPrevia()" checked> No</label>
                </div>
            </div>
            <div id="detalle_terapia_previa" class="opcion-condicional">
                <label for="terapia_duracion">Tiempo de duración:</label><input type="text" id="terapia_duracion" name="terapia_duracion">
                <label for="terapia_transcurrido">Tiempo transcurrido de la última sesión:</label><input type="text" id="terapia_transcurrido" name="terapia_transcurrido">
                <label for="terapia_causas">Causas (Motivo de consulta en ese momento):</label><textarea id="terapia_causas" name="terapia_causas"></textarea>
                <label for="terapia_motivo_finalizacion">Motivo de finalización de la terapia:</label><textarea id="terapia_motivo_finalizacion" name="terapia_motivo_finalizacion"></textarea>
            </div>


            <h3>Uso de Sustancias</h3>
            <?php 
                $sustancias = ['Fuma', 'Alcohol', 'Drogas alguna vez'];
                $opciones_uso = ['Frecuentemente', 'Socialmente', 'Ocasionalmente', 'A veces', 'Casi Nunca', 'No'];
            ?>
            <?php foreach ($sustancias as $s): ?>
            <div class="campo">
                <label><?php echo $s; ?></label>
                <div class="grupo-radio">
                    <?php 
                    $name = strtolower(str_replace(' ', '_', $s));
                    foreach ($opciones_uso as $op): ?>
                    <label><input type="radio" name="<?php echo $name; ?>" value="<?php echo $op; ?>" <?php echo ($op === 'No') ? 'checked' : ''; ?> <?php echo ($s === 'Drogas alguna vez') ? 'onclick="mostrarDrogas()"' : ''; ?>> <?php echo $op; ?></label>
                    <?php endforeach; ?>
                </div>
                
                <?php if ($s === 'Drogas alguna vez'): ?>
                    <div id="detalle_drogas" class="opcion-condicional">
                        <label for="drogas_tipo">Tipo de Sustancia:</label><input type="text" id="drogas_tipo" name="drogas_tipo">
                        <label for="drogas_ultimo_consumo">Tiempo del último consumo:</label><input type="text" id="drogas_ultimo_consumo" name="drogas_ultimo_consumo">
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            
            <div class="campo"><label for="ant_psiquiatricos">Antecedentes Psiquiátricos (Diagnóstico y Fecha):</label><input type="text" id="ant_psiquiatricos" name="ant_psiquiatricos" placeholder="Ej: Depresión mayor, 2018"></div>
            <div class="campo"><label for="medicacion">Uso de Medicación Psiquiátrica (Nombre y Dosis):</label><input type="text" id="medicacion" name="medicacion" placeholder="Ej: Sertralina 50mg"></div>
            <div class="campo"><label for="enfermedades_cronicas">Enfermedades Médicas Crónicas:</label><input type="text" id="enfermedades_cronicas" name="enfermedades_cronicas" placeholder="Ej: Diabetes, Hipertensión"></div>
            <div class="campo"><label for="calidad_sueno">Calidad del Sueño:</label>
                <select id="calidad_sueno" name="calidad_sueno" required>
                    <option value="Bueno">Bueno (7-9 horas, reparador)</option>
                    <option value="Regular">Regular (Despertares, cansancio)</option>
                    <option value="Malo">Malo (Insomnio o hipersomnia)</option>
                </select>
            </div>
            <div class="campo"><label for="soporte_social">Soporte Social/Amigos (Evaluación simple):</label>
                <select id="soporte_social" name="soporte_social" required>
                    <option value="Alto">Alto (Red de apoyo sólida)</option>
                    <option value="Medio">Medio (Algunas amistades, familia)</option>
                    <option value="Bajo">Bajo (Aislamiento o conflictos)</option>
                </select>
            </div>

            <h2>V. Confidencialidad y Finalización</h2>
            <div class="campo">
                <label style="display: flex; align-items: center;">
                    <input type="checkbox" name="consentimiento" id="consentimiento" value="1" required> 
                    He leído y acepto el 
                    <a href="consentimiento_informado.php" target="_blank" style="color: var(--primary); text-decoration: underline; margin-left: 5px;">
                        Consentimiento Informado (Requisito legal)
                    </a>
                </label>
            </div>
            
            <button type="submit" class="submit-btn">Completar Registro (Enviar a Terapeuta)</button>
        </form>
        
        <footer class="main-footer">
            <p>&copy; <?php echo date('Y'); ?> CMS-GP | Desarrollado por Alberto Félix. <a href="mailto:hello@albertofelix.click">hello@albertofelix.click</a></p>
            <img src="assets/img/logo.png" alt="CMS-GP Logo" class="footer-logo">
        </footer>

    </div>

    <script src="assets/js/registro.js"></script>
</body>
</html>