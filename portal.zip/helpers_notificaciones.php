<?php
// helpers_notificaciones.php

function nuevaNotificacion($pdo, $paciente_id, $mensaje, $tipo = 'info') {
    try {
        if (!$pdo) return false;

        $stmt = $pdo->prepare("INSERT INTO notificaciones (paciente_id, mensaje, tipo) VALUES (?, ?, ?)");
        $stmt->execute([$paciente_id, $mensaje, $tipo]);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}
?>