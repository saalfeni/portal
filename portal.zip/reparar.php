<?php
require 'db_connect.php';
$email = "afelix@gruponalix.com";
$pass = "123456";
$hash = password_hash($pass, PASSWORD_BCRYPT);

$stmt = $pdo->prepare("UPDATE pacientes SET password = ? WHERE email = ?");
if($stmt->execute([$hash, $email])) {
    echo "¡Base de datos actualizada correctamente para Alberto!";
} else {
    echo "Error al actualizar.";
}
?>