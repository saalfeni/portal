<?php
// guardar_actividad.php - Procesa la asignación de tareas y dispara notificaciones
require 'db_connect.php'; // Este archivo ya gestiona la sesión (session_start)
require 'helpers_notificaciones.php'; 
require 'helpers_push.php'; 

// 1. Seguridad: Verificar sesión de admin
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit;
}

// 2. Procesar el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $paciente_id = filter_input(INPUT_POST, 'paciente_id', FILTER_VALIDATE_INT);
    $actividad = htmlspecialchars(trim($_POST['actividad']));

    if ($paciente_id && !empty($actividad)) {
        try {
            $pdo->beginTransaction();

            // PASO A: Guardar la actividad en el historial
            $sql = "INSERT INTO paciente_actividades (paciente_id, descripcion, fecha_asignacion, completado) VALUES (?, ?, NOW(), 0)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$paciente_id, $actividad]);

            // PASO B: Generar la Notificación Interna (Campanita)
            $resumen = substr($actividad, 0, 45) . (strlen($actividad) > 45 ? '...' : '');
            $mensaje_noti = "Nueva tarea: " . $resumen;
            nuevaNotificacion($pdo, $paciente_id, $mensaje_noti, 'tarea');

            // PASO C: Disparar Notificación PUSH al móvil
            // Lo ponemos dentro del try para que si falla, podamos capturar el error
            enviarPush($pdo, $paciente_id, "Nueva Tarea Asignada", "Tienes una nueva actividad pendiente en tu portal.");

            $pdo->commit();

            // Redireccionar con éxito
            header("Location: admin_detalle.php?id=$paciente_id&tab=registro&status=tarea_enviada");
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            // Esto nos dirá exactamente qué falló si hay un error
            die("Error crítico al procesar la actividad: " . $e->getMessage());
        }
    } else {
        header("Location: admin_detalle.php?id=$paciente_id&error=datos_vacios");
        exit;
    }
} else {
    header('Location: admin_dashboard.php');
    exit;
}