-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-12-2025 a las 23:16:19
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cms-gp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `cedula` varchar(50) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `firma` varchar(255) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `nombre`, `titulo`, `email`, `cedula`, `foto`, `firma`, `fecha_registro`) VALUES
(1, 'admin', '$2y$10$8On9hh5/6XbEainAm8Xlre3cE8FtIH/1fBRnSzshYmRs5Epm0gQnS', 'Administrador Pro', '', '', '', 'uploads/perfil/admin_1767135508.jpg', NULL, '2025-12-30 22:24:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bai_preguntas`
--

CREATE TABLE `bai_preguntas` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `opcion_0` varchar(100) DEFAULT 'En absoluto',
  `opcion_1` varchar(100) DEFAULT 'Levemente, no me molestó mucho',
  `opcion_2` varchar(100) DEFAULT 'Moderadamente, fue muy desagradable pero pude soportarlo',
  `opcion_3` varchar(100) DEFAULT 'Severamente, casi no pude soportarlo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `bai_preguntas`
--

INSERT INTO `bai_preguntas` (`id`, `titulo`, `opcion_0`, `opcion_1`, `opcion_2`, `opcion_3`) VALUES
(1, 'Hormigueo o entumecimiento', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(2, 'Sensación de calor', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(3, 'Temblor en las piernas', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(4, 'Incapacidad para relajarse', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(5, 'Temor a que ocurra lo peor', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(6, 'Mareo o aturdimiento', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(7, 'Palpitaciones o aceleración del corazón', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(8, 'Inestabilidad', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(9, 'Terror o pavor', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(10, 'Nerviosismo', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(11, 'Sensación de bloqueo o asfixia', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(12, 'Temblores en las manos', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(13, 'Inquietud / Inestabilidad motora', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(14, 'Temor a perder el control', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(15, 'Dificultad para respirar', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(16, 'Temor a morir', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(17, 'Sobresalto', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(18, 'Molestias digestivas o abdominales', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(19, 'Palidez / Desvanecimiento', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(20, 'Rubor facial', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo'),
(21, 'Sudoración (no debida al calor)', 'En absoluto', 'Levemente, no me molestó mucho', 'Moderadamente, fue muy desagradable pero pude soportarlo', 'Severamente, casi no pude soportarlo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bai_respuestas`
--

CREATE TABLE `bai_respuestas` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) UNSIGNED NOT NULL,
  `pregunta_id` int(11) NOT NULL,
  `respuesta` int(1) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `bai_respuestas`
--

INSERT INTO `bai_respuestas` (`id`, `paciente_id`, `pregunta_id`, `respuesta`, `fecha`) VALUES
(1, 1, 1, 2, '2025-12-31 01:07:05'),
(2, 1, 2, 3, '2025-12-31 01:07:05'),
(3, 1, 3, 3, '2025-12-31 01:07:05'),
(4, 1, 4, 0, '2025-12-31 01:07:05'),
(5, 1, 5, 1, '2025-12-31 01:07:05'),
(6, 1, 6, 0, '2025-12-31 01:07:05'),
(7, 1, 7, 2, '2025-12-31 01:07:05'),
(8, 1, 8, 0, '2025-12-31 01:07:05'),
(9, 1, 9, 1, '2025-12-31 01:07:05'),
(10, 1, 10, 3, '2025-12-31 01:07:05'),
(11, 1, 11, 2, '2025-12-31 01:07:05'),
(12, 1, 12, 0, '2025-12-31 01:07:05'),
(13, 1, 13, 2, '2025-12-31 01:07:05'),
(14, 1, 14, 3, '2025-12-31 01:07:05'),
(15, 1, 15, 1, '2025-12-31 01:07:05'),
(16, 1, 16, 0, '2025-12-31 01:07:05'),
(17, 1, 17, 1, '2025-12-31 01:07:05'),
(18, 1, 18, 1, '2025-12-31 01:07:05'),
(19, 1, 19, 2, '2025-12-31 01:07:05'),
(20, 1, 20, 2, '2025-12-31 01:07:05'),
(21, 1, 21, 1, '2025-12-31 01:07:05'),
(22, 2, 1, 2, '2025-12-31 18:36:46'),
(23, 2, 2, 3, '2025-12-31 18:36:46'),
(24, 2, 3, 0, '2025-12-31 18:36:46'),
(25, 2, 4, 3, '2025-12-31 18:36:46'),
(26, 2, 5, 0, '2025-12-31 18:36:46'),
(27, 2, 6, 2, '2025-12-31 18:36:46'),
(28, 2, 7, 1, '2025-12-31 18:36:46'),
(29, 2, 8, 2, '2025-12-31 18:36:46'),
(30, 2, 9, 2, '2025-12-31 18:36:46'),
(31, 2, 10, 3, '2025-12-31 18:36:46'),
(32, 2, 11, 0, '2025-12-31 18:36:46'),
(33, 2, 12, 0, '2025-12-31 18:36:46'),
(34, 2, 13, 1, '2025-12-31 18:36:46'),
(35, 2, 14, 0, '2025-12-31 18:36:46'),
(36, 2, 15, 3, '2025-12-31 18:36:46'),
(37, 2, 16, 3, '2025-12-31 18:36:46'),
(38, 2, 17, 2, '2025-12-31 18:36:46'),
(39, 2, 18, 1, '2025-12-31 18:36:46'),
(40, 2, 19, 0, '2025-12-31 18:36:46'),
(41, 2, 20, 0, '2025-12-31 18:36:46'),
(42, 2, 21, 1, '2025-12-31 18:36:46');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bdi2_preguntas`
--

CREATE TABLE `bdi2_preguntas` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `opcion_0` text DEFAULT NULL,
  `opcion_1` text DEFAULT NULL,
  `opcion_2` text DEFAULT NULL,
  `opcion_3` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `bdi2_preguntas`
--

INSERT INTO `bdi2_preguntas` (`id`, `titulo`, `opcion_0`, `opcion_1`, `opcion_2`, `opcion_3`) VALUES
(1, 'Tristeza', 'No me siento triste.', 'Me siento triste gran parte del tiempo.', 'Me siento triste todo el tiempo.', 'Estoy tan triste o soy tan infeliz que no puedo soportarlo.'),
(2, 'Pesimismo', 'No estoy desalentado respecto de mi futuro.', 'Me siento más desalentado respecto de mi futuro que lo que solía estar.', 'No espero que las cosas funcionen para mí.', 'Siento que mi futuro es desesperanzador y que las cosas solo empeorarán.'),
(3, 'Fracaso', 'No me siento como un fracasado.', 'He fracasado más de lo que hubiera debido.', 'Cuando miro hacia atrás, veo muchos fracasos.', 'Siento que como persona soy un fracaso total.'),
(4, 'Pérdida de Placer', 'Obtengo tanto placer como siempre de las cosas de las que disfruto.', 'No disfruto tanto de las cosas como solía hacerlo.', 'Obtengo muy poco placer de las cosas de las que solía disfrutar.', 'No puedo obtener ningún placer de las cosas de las que solía disfrutar.'),
(5, 'Sentimientos de Culpa', 'No me siento particularmente culpable.', 'Me siento culpable respecto de varias cosas que he hecho o que debería haber hecho.', 'Me siento bastante culpable la mayor parte del tiempo.', 'Me siento culpable todo el tiempo.'),
(6, 'Sentimientos de Castigo', 'No siento que este siendo castigado.', 'Siento que tal vez pueda ser castigado.', 'Espero ser castigado.', 'Siento que estoy siendo castigado.'),
(7, 'Disconformidad con uno mismo', 'Siento lo mismo que siempre acerca de mí mismo.', 'He perdido la confianza en mí mismo.', 'Estoy decepcionado de mí mismo.', 'No me gusto a mí mismo.'),
(8, 'Autocrítica', 'No me critico ni me culpo más de lo habitual.', 'Estoy más crítico conmigo mismo de lo que solía estarlo.', 'Me critico a mí mismo por todos mis errores.', 'Me culpo a mí mismo por todo lo malo que sucede.'),
(9, 'Pensamientos o Deseos Suicidas', 'No tengo ningún pensamiento de matarme.', 'Tengo pensamientos de matarme, pero no lo haría.', 'Me gustaría matarme.', 'Me mataría si tuviera la oportunidad.'),
(10, 'Llanto', 'No lloro más de lo que solía hacerlo.', 'Lloro más de lo que solía hacerlo.', 'Lloro por cualquier pequeñez.', 'Siento ganas de llorar pero no puedo.'),
(11, 'Agitación', 'No estoy más inquieto o tenso que lo habitual.', 'Me siento más inquieto o tenso que lo habitual.', 'Estoy tan inquieto o agitado que me es difícil quedarme quieto.', 'Estoy tan inquieto o agitado que tengo que estar siempre en movimiento o haciendo algo.'),
(12, 'Pérdida de Interés', 'No he perdido el interés en otras personas o actividades.', 'Estoy menos interesado en otras personas o cosas de lo que solía estar.', 'He perdido casi todo el interés en otras personas o cosas.', 'Me es difícil interesarme por algo.'),
(13, 'Indecisión', 'Tomo mis decisiones tan bien como siempre.', 'Me resulta más difícil tomar decisiones que lo habitual.', 'Tengo mucha más dificultad en tomar decisiones que lo habitual.', 'Tengo problemas para tomar cualquier decisión.'),
(14, 'Desvalorización', 'No siento que yo no valga nada.', 'No me considero tan valioso y útil como solía serlo.', 'Me siento menos valioso cuando me comparo con los demás.', 'Siento que no valgo nada.'),
(15, 'Pérdida de Energía', 'Tengo tanta energía como siempre.', 'Tengo menos energía de la que solía tener.', 'No tengo suficiente energía para hacer demasiado.', 'No tengo energía suficiente para hacer nada.'),
(16, 'Cambios en el Patrón de Sueño', 'No he experimentado ningún cambio en mis hábitos de sueño.', 'Duermo un poco más/menos que lo habitual.', 'Duermo mucho más/menos que lo habitual.', 'Duermo la mayor parte del día o me despierto 1-2 horas más temprano y no puedo volver a dormir.'),
(17, 'Irritabilidad', 'No estoy más irritable que lo habitual.', 'Estoy más irritable que lo habitual.', 'Estoy mucho más irritable que lo habitual.', 'Estoy irritable todo el tiempo.'),
(18, 'Cambios en el Apetito', 'No he experimentado ningún cambio en mi apetito.', 'Mi apetito es un poco menor/mayor que lo habitual.', 'Mi apetito es mucho menor/mayor que lo habitual.', 'No tengo nada de apetito o tengo ganas de comer todo el tiempo.'),
(19, 'Dificultad de Concentración', 'Puedo concentrarme tan bien como siempre.', 'No puedo concentrarme tan bien como habitualmente.', 'Me es difícil mantener la mente en algo por mucho tiempo.', 'No puedo concentrarme en nada.'),
(20, 'Cansancio o Fatiga', 'No estoy más cansado o fatigado que lo habitual.', 'Me canso o fatigo más fácilmente que lo habitual.', 'Estoy demasiado cansado o fatigado para hacer muchas de las cosas que solía hacer.', 'Estoy demasiado cansado o fatigado para hacer casi cualquier cosa.'),
(21, 'Pérdida de Interés en el Sexo', 'No he notado ningún cambio reciente en mi interés por el sexo.', 'Estoy menos interesado en el sexo de lo que solía estarlo.', 'Estoy mucho menos interesado en el sexo ahora.', 'He perdido completamente el interés en el sexo.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bdi2_respuestas`
--

CREATE TABLE `bdi2_respuestas` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) UNSIGNED NOT NULL,
  `pregunta_id` int(11) NOT NULL,
  `puntuacion` int(11) NOT NULL,
  `fecha_guardado` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `bdi2_respuestas`
--

INSERT INTO `bdi2_respuestas` (`id`, `paciente_id`, `pregunta_id`, `puntuacion`, `fecha_guardado`) VALUES
(22, 2, 1, 0, '2025-12-26 16:49:56'),
(23, 2, 2, 2, '2025-12-26 16:49:56'),
(24, 2, 3, 1, '2025-12-26 16:49:56'),
(25, 2, 4, 3, '2025-12-26 16:49:56'),
(26, 2, 5, 1, '2025-12-26 16:49:56'),
(27, 2, 6, 0, '2025-12-26 16:49:56'),
(28, 2, 7, 1, '2025-12-26 16:49:56'),
(29, 2, 8, 3, '2025-12-26 16:49:56'),
(30, 2, 9, 1, '2025-12-26 16:49:56'),
(31, 2, 10, 2, '2025-12-26 16:49:56'),
(32, 2, 11, 3, '2025-12-26 16:49:56'),
(33, 2, 12, 2, '2025-12-26 16:49:56'),
(34, 2, 13, 0, '2025-12-26 16:49:56'),
(35, 2, 14, 2, '2025-12-26 16:49:56'),
(36, 2, 15, 1, '2025-12-26 16:49:56'),
(37, 2, 16, 1, '2025-12-26 16:49:56'),
(38, 2, 17, 2, '2025-12-26 16:49:56'),
(39, 2, 18, 0, '2025-12-26 16:49:56'),
(40, 2, 19, 1, '2025-12-26 16:49:56'),
(41, 2, 20, 2, '2025-12-26 16:49:56'),
(42, 2, 21, 1, '2025-12-26 16:49:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fcm_tokens`
--

CREATE TABLE `fcm_tokens` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) UNSIGNED NOT NULL,
  `token` text NOT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `fcm_tokens`
--

INSERT INTO `fcm_tokens` (`id`, `paciente_id`, `token`, `fecha_registro`) VALUES
(1, 2, 'f95xeb3SkSR9XM1Yi99sYE:APA91bH0ldH2smH_pJ2LH34ZCvy4y_ns2iokg4uwDK2VV1jRCi96M6XvTh3TAFk-Iv4BsVXf36j-5Pu8Aa5vPunfQGU7A6T3EQuGiDlfPrzmStJihI4Ea88', '2025-12-27 16:53:27'),
(2, 2, 'dNGDotbbO93m0XyD2I0CP7:APA91bGPjSmGABgm2GZaKYNzk8zkPNORsOEjDXKiaEsAcWydsi7OkDZdFceYNTGvB2qWc6ylMrcfaPcgW1bXzQaaXYK66Q3560Fp9byuOv752qo8VzcFVzo', '2025-12-27 17:45:50');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mmpi2_claves`
--

CREATE TABLE `mmpi2_claves` (
  `id` int(11) NOT NULL,
  `escala` varchar(20) DEFAULT NULL,
  `pregunta_id` int(11) DEFAULT NULL,
  `respuesta_esperada` tinyint(4) DEFAULT NULL,
  `grupo_escala` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mmpi2_escalas_claves`
--

CREATE TABLE `mmpi2_escalas_claves` (
  `id` int(11) NOT NULL,
  `escala` varchar(10) DEFAULT NULL,
  `pregunta_id` int(11) DEFAULT NULL,
  `respuesta_esperada` int(11) DEFAULT NULL,
  `tipo_escala` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mmpi2_escalas_claves`
--

INSERT INTO `mmpi2_escalas_claves` (`id`, `escala`, `pregunta_id`, `respuesta_esperada`, `tipo_escala`) VALUES
(1, 'A', 2, 1, 'suplementaria'),
(2, 'A', 3, 1, 'suplementaria'),
(3, 'A', 5, 1, 'suplementaria'),
(4, 'A', 10, 1, 'suplementaria'),
(5, 'A', 15, 1, 'suplementaria'),
(6, 'R', 14, 0, 'suplementaria'),
(7, 'R', 18, 0, 'suplementaria'),
(8, 'R', 25, 0, 'suplementaria'),
(9, 'R', 32, 0, 'suplementaria'),
(10, 'R', 40, 0, 'suplementaria'),
(11, 'Fyo', 7, 1, 'suplementaria'),
(12, 'Fyo', 11, 1, 'suplementaria'),
(13, 'Fyo', 16, 1, 'suplementaria'),
(14, 'Fyo', 23, 1, 'suplementaria'),
(15, 'MAC-R', 6, 1, 'suplementaria'),
(16, 'MAC-R', 12, 1, 'suplementaria'),
(17, 'MAC-R', 19, 1, 'suplementaria'),
(18, 'MAC-R', 26, 1, 'suplementaria'),
(19, 'K-B_Suicid', 150, 1, 'critico'),
(20, 'K-B_Suicid', 303, 1, 'critico'),
(21, 'K-B_Suicid', 506, 1, 'critico'),
(22, 'K-B_Suicid', 520, 1, 'critico'),
(23, 'K-B_Confus', 15, 1, 'critico'),
(24, 'K-B_Confus', 24, 1, 'critico'),
(25, 'K-B_Confus', 31, 1, 'critico'),
(26, 'L-W_Somati', 18, 1, 'critico'),
(27, 'L-W_Somati', 28, 1, 'critico'),
(28, 'L-W_Somati', 40, 1, 'critico'),
(29, 'K-B_Ideaci', 150, 1, 'critico'),
(30, 'K-B_Ideaci', 303, 1, 'critico'),
(31, 'K-B_Ideaci', 506, 1, 'critico'),
(32, 'K-B_Ideaci', 520, 1, 'critico'),
(33, 'K-B_Ideaci', 524, 1, 'critico'),
(34, 'K-B_Ideaci', 530, 1, 'critico'),
(35, 'K-B_Incohe', 15, 1, 'critico'),
(36, 'K-B_Incohe', 24, 1, 'critico'),
(37, 'K-B_Incohe', 31, 1, 'critico'),
(38, 'K-B_Incohe', 121, 1, 'critico'),
(39, 'K-B_Amenaz', 27, 1, 'critico'),
(40, 'K-B_Amenaz', 134, 1, 'critico'),
(41, 'K-B_Amenaz', 211, 1, 'critico'),
(42, 'K-B_Amenaz', 548, 1, 'critico'),
(43, 'L-W_Desaju', 38, 1, 'critico'),
(44, 'L-W_Desaju', 48, 1, 'critico'),
(45, 'L-W_Desaju', 73, 1, 'critico'),
(46, 'L-W_Depres', 5, 1, 'critico'),
(47, 'L-W_Depres', 15, 1, 'critico'),
(48, 'L-W_Depres', 233, 1, 'critico'),
(49, 'L-W_Somati', 18, 1, 'critico'),
(50, 'L-W_Somati', 117, 1, 'critico'),
(51, 'L-W_Somati', 175, 1, 'critico');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mmpi2_preguntas`
--

CREATE TABLE `mmpi2_preguntas` (
  `id` int(11) NOT NULL,
  `pregunta` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `mmpi2_preguntas`
--

INSERT INTO `mmpi2_preguntas` (`id`, `pregunta`) VALUES
(1, 'Me gustan las revistas de mecánica.'),
(2, 'Tengo buen apetito.'),
(3, 'Me despierto fresco (a) y descansado (a) en la mayoría de las mañanas.'),
(4, 'Creo que me gustaría el trabajo de bibliotecario.'),
(5, 'Me despierto fácilmente con el ruido.'),
(6, 'Mi padre es (era) un buen hombre.'),
(7, 'Me gusta leer artículos sobre crímenes en los diarios.'),
(8, 'Mis manos y mis pies están por lo general suficientemente calientes.'),
(9, 'Mi vida diaria está llena de cosas que me mantienen interesado (a).'),
(10, 'Soy tan capaz de trabajar como lo he sido siempre.'),
(11, 'Me parece tener un nudo en la garganta la mayor parte del tiempo.'),
(12, 'Mi vida sexual es satisfactoria.'),
(13, 'Una persona debiera tratar de comprender sus sueños y guiarse por ellos o tenerlos en cuenta como un aviso o advertencia.'),
(14, 'Disfruto con los cuentos de detectives o de misterio.'),
(15, 'Trabajo bajo mucha tensión'),
(16, 'De vez en cuando pienso en cosas demasiado malas como para hablar de ellas.'),
(17, 'Estoy seguro (a) que la vida me trata mal.'),
(18, 'Sufro de ataques de náuseas y vómitos.'),
(19, 'Cuando acepto un nuevo trabajo me gusta que me “soplen” a quién tengo que halagar.'),
(20, 'Muy rara vez sufro de estreñimiento.'),
(21, 'En algunas ocasiones he tenido muchísimos deseos de abandonar mi hogar.'),
(22, 'Nadie parece comprenderme.'),
(23, 'A veces me dan ataques de risa o de llanto que no puedo controlar.'),
(24, 'A veces se posesionan de mí espíritus malignos.'),
(25, 'Me gustaría ser cantante.'),
(26, 'Creo que lo mejor es quedarme callado (a) cuando estoy en dificultades.'),
(27, 'Cuando alguien me juega una mala pasada, siento que debiera pagarle con la misma moneda, si es que puedo, sólo por principio.'),
(28, 'Padezco de acidez estomacal varias veces por semana.'),
(29, 'A veces siento ganas de decir palabrotas.'),
(30, 'Tengo pesadillas una que otra noche.'),
(31, 'Me cuesta concentrarme en una tarea o trabajo.'),
(32, 'He tenido experiencias muy peculiares y extrañas.'),
(33, 'Raras veces me preocupo por mi salud.'),
(34, 'Nunca me he visto envuelto (a) en problemas a causa de mi comportamiento sexual.'),
(35, 'Cuando era chico (a), algunas veces me robé cosas sin importancia.'),
(36, 'Casi siempre tengo tos.'),
(37, 'A veces me dan ganas de hacer añicos las cosas.'),
(38, 'He tenido períodos de días, semanas o meses en que no podía ocuparme de nada porque no tenía ánimo de hacerlo.'),
(39, 'Mi sueño es sobresaltado e intranquilo'),
(40, 'La mayor parte del tiempo parece que me duele toda la cabeza.'),
(41, 'No siempre digo la verdad.'),
(42, 'Si la gente no la hubiera “agarrado conmigo”, yo habría tenido mucho más éxito.'),
(43, 'Mi habilidad para razonar, juzgar y tomar decisiones es ahora mejor que nunca.'),
(44, 'Una vez por semana o con más frecuencia, siento repentinamente calor por todo el cuerpo, sin causa aparente.'),
(45, 'Me encuentro en tan buenas condiciones de salud física como la mayoría de mis amigos.'),
(46, 'Cuando me encuentro en la calle con amigos del colegio o con personas conocidas a quienes no he visto desde hace mucho tiempo, prefiero hacerme el desentendido (a) a menos que ellos me hablen primero.'),
(47, 'Casi nunca siento dolores en el corazón o en el pecho.'),
(48, 'La mayor parte del tiempo preferiría sentarme a soñar despierto (a) en lugar de hacer cualquier otra cosa.'),
(49, 'Soy una persona sociable.'),
(50, 'Con frecuencia he tenido que recibir órdenes de alguien que no sabía tanto como yo.'),
(51, 'No leo todos los editoriales del diario todos los días.'),
(52, 'No he vivido correctamente.'),
(53, 'Con frecuencia algunas partes de mi cuerpo me arden, pican, hormiguean o se me adormecen.'),
(54, 'A mi familia no le gusta el trabajo que he escogido (o el que pienso escoger) como ocupación principal de toda mi vida.'),
(55, 'A veces insisto tanto en algo, que los demás pierden la paciencia conmigo.'),
(56, 'Quisiera poder ser tan feliz como otras personas parecen serlo.'),
(57, 'Muy rara vez siento dolor en la nuca.'),
(58, 'Creo que muchísima gente exagera sus desgracias para ganarse la compasión y ayuda de los demás.'),
(59, 'Sufro de malestares en la boca del estómago varias veces a la semana o con más frecuencia.'),
(60, 'Cuando estoy con gente me perturba escuchar cosas muy extrañas.'),
(61, 'Soy una persona importante.'),
(62, 'A menudo he deseado ser mujer. (o, si usted es mujer:) Nunca me ha pesado ser mujer.'),
(63, 'No me siento herido con facilidad.'),
(64, 'Disfruto leyendo novelas de amor.'),
(65, 'Casi siempre me siento melancólico (a).'),
(66, 'Sería mejor si casi todas las leyes fueran desechadas.'),
(67, 'Me gusta la poesía.'),
(68, 'De vez en cuando molesto o fastidio a los animales.'),
(69, 'Creo que me gustaría el tipo de trabajo que hace un guardabosque.'),
(70, 'Me dejan callado (a) fácilmente en una discusión.'),
(71, 'En estos días me parece difícil no perder la esperanza de llegar a lograr algo.'),
(72, 'Mi alma a veces abandona mi cuerpo.'),
(73, 'Decididamente no tengo confianza en mí mismo (a).'),
(74, 'Me gustaría ser florista.'),
(75, 'Generalmente siento que la vida vale la pena.'),
(76, 'Se necesita argumentar mucho para convencer de la verdad a la mayor parte de la gente.'),
(77, 'De vez en cuando dejo para mañana lo que debo hacer hoy.'),
(78, 'Le agrado a la mayoría de la gente.'),
(79, 'No me importa que se burlen de mí.'),
(80, 'Me gustaría ser enfermero (a).'),
(81, 'Creo que la mayoría de la gente mentiría para salir adelante.'),
(82, 'Hago muchas cosas de las que me arrepiento más tarde (me arrepiento más de las cosas o con más frecuencia de lo que otros parecen hacerlo).'),
(83, 'Tengo muy pocas peleas con miembros de mi familia.'),
(84, 'Cuando chico (a) me suspendieron del colegio uno o más veces por mala conducta.'),
(85, 'A veces siento un fuerte impulso a hacer algo dañino o chocante.'),
(86, 'Me gusta ir a fiestas y a otras reuniones donde hay mucha alegría y ruido.'),
(87, 'He encontrado problemas tan llenos de alternativas, que me ha sido imposible llegar a una decisión sobre ellos.'),
(88, 'Creo que la mujer debiera tener tanta libertad sexual como el hombre.'),
(89, 'Mis luchas más difíciles son conmigo mismo.'),
(90, 'Yo quiero (quise) a mi padre.'),
(91, 'Pocas veces o nunca me dan calambres o espasmos musculares.'),
(92, 'Me importa poco lo que me pase.'),
(93, 'A veces, cuando no me siento bien, ando irritable.'),
(94, 'Muchas veces siento como si hubiera hecho algo incorrecto o perverso.'),
(95, 'Casi siempre estoy contento.'),
(96, 'Veo cosas, animales o gente a mi alrededor que otros no ven.'),
(97, 'Parece que mi cabeza o mi nariz están congestionadas la mayor parte del tiempo.'),
(98, 'Algunas personas son tan mandonas que siento el deseo de hacer lo contrario de lo que me piden, aunque sepa que tienen la razón.'),
(99, 'A alguien la ha agarrado contra mí.'),
(100, 'Nunca he hecho algo peligroso sólo por la emoción de hacerlo.'),
(101, 'A menudo siento como si tuviera un cintillo apretándome la cabeza.'),
(102, 'A veces me enojo.'),
(103, 'Disfruto más de una carrera o juego cuando apuesto.'),
(104, 'La mayoría de la gente es honrada principalmente por temor a ser descubierta.'),
(105, 'En el colegio a veces me llevaron con el Director por hacer travesuras.'),
(106, 'Mi manera de hablar es como ha sido siempre (ni más rápida ni más lenta, ni balbuceante ni ronca).'),
(107, 'Creo que están conspirando contra mí.'),
(108, 'Cualquier persona capaz o dispuesta a trabajar duro, tiene buenas posibilidades de tener éxito.'),
(109, 'Me parece que soy tan capaz e inteligente, como la mayoría de los que me rodean.'),
(110, 'La mayoría de la gente se vale de medios un tanto incorrectos para obtener beneficios o ventajas antes de perderlos.'),
(111, 'Sufro mucho de trastornos estomacales.'),
(112, 'Me gusta el teatro.'),
(113, 'Sé quién es el responsable de la mayoría de mis problemas.'),
(114, 'A veces me siento tan fuertemente atraído por los objetos personales de otros, tales como zapatos, guantes, etc., que deseo tenerlos o robarlos, aunque no tenga un uso para ellos.'),
(115, 'No me asusta ni me descompone ver sangre.'),
(116, 'A menudo no puedo comprender por qué he andado “malhumorado (a)” y “gruñón”.'),
(117, 'Nunca he vomitado o escupido sangre.'),
(118, 'No me preocupa el contagio de enfermedades.'),
(119, 'Me gusta recoger flores o cultivar plantas de interior.'),
(120, 'Con frecuencia siento que es necesario sacar la cara por lo que creo que es justo.'),
(121, 'Nunca me he entregado a prácticas sexuales fuera de lo común.'),
(122, 'A veces los pensamientos pasan por mi mente con mayor rapidez de lo que puedo expresarlos con palabras.'),
(123, 'Si pudiera entrar a un cine sin pagar, con la seguridad de no ser visto, probablemente lo haría.'),
(124, 'Generalmente pienso qué razón oculta puede tener otra persona cuando me hace un favor.'),
(125, 'Creo que mi vida de hogar es tan agradable como la de la mayoría de la gente que conozco.'),
(126, 'Creo que la ley debe hacerse cumplir.'),
(127, 'La crítica o los retos me hieren terriblemente.'),
(128, 'Me gusta cocinar.'),
(129, 'Mi conducta está determinada en gran medida por las costumbres de quienes me rodean.'),
(130, 'Verdaderamente a veces siento que no sirvo para nada.'),
(131, 'Cuando niño (a) pertenecía a un grupo o pandilla que trataba de mantenerse unida contra viento y marea.'),
(132, 'Creo en otra vida después de ésta.'),
(133, 'Me gustaría ser soldado.'),
(134, 'A veces siento el deseo de agarrarme a puñetazos con alguien.'),
(135, 'Muchas veces he perdido una oportunidad porque no he podido decidirme a tiempo.'),
(136, 'Me impacienta que me pidan consejo o que me interrumpan cuando estoy trabajando en algo importante.'),
(137, 'Acostumbraba a llevar un diario de vida.'),
(138, 'Creo que estoy siendo atacado.'),
(139, 'Preferiría ganar a perder en un juego.'),
(140, 'Casi todas las noches me voy a dormir sin pensamientos o ideas que me preocupen.'),
(141, 'Durante los últimos años he estado bien la mayor parte del tiempo.'),
(142, 'Nunca he tenido ataques o convulsiones.'),
(143, 'No estoy subiendo o bajando de peso.'),
(144, 'Creo que me están siguiendo.'),
(145, 'Siento que frecuentemente me han castigado sin razón.'),
(146, 'Lloro con facilidad.'),
(147, 'No puedo entender lo que leo tan bien como antes.'),
(148, 'Nunca en mi vida me he sentido mejor que ahora.'),
(149, 'A veces siento adolorida la parte superior de mi cabeza.'),
(150, 'Algunas veces siento como si debiera herirme a mí mismo (a) o a otro.'),
(151, 'Me molesta que me “tomen el pelo” tan hábilmente que tenga que admitir que me engañaron.'),
(152, 'No me canso con facilidad.'),
(153, 'Me gusta conocer gente importante porque eso me hace sentir importante.'),
(154, 'Siento miedo cuando miro hacia abajo desde un lugar alto.'),
(155, 'No me sentiría nervioso (a) si algún familiar mío tuviera dificultades con la ley.'),
(156, 'Me apasiona la vida errante y nunca me siento feliz a menos que esté viajando o vagabundeando de un lugar a otro.'),
(157, 'No me preocupa lo que otros piensen de mí.'),
(158, 'Me siento incómodo al hacer una payasada en una fiesta, aún cuando otros estén haciendo lo mismo.'),
(159, 'Nunca me he desmayado.'),
(160, 'Me gustaba el colegio.'),
(161, 'Frecuentemente tengo que esforzarme por no demostrar que soy tímido.'),
(162, 'Alguien ha tratado de envenenarme.'),
(163, 'No le tengo mucho miedo a las serpientes.'),
(164, 'Rara vez o nunca tengo mareos.'),
(165, 'Mi memoria parece estar bien.'),
(166, 'Me preocupan las cuestiones sexuales.'),
(167, 'Me cuesta entablar conversación con gente que recién conozco.'),
(168, 'He tenido periodos en que he hecho cosas, sin saber después qué es lo que estaba haciendo.'),
(169, 'Cuando me aburro, me gusta promover algo emocionante.'),
(170, 'Tengo miedo de volverme loco (a).'),
(171, 'Estoy en contra de dar dinero a los mendigos.'),
(172, 'Con frecuencia noto que mi mano tiembla cuando trato de hacer algo.'),
(173, 'Puedo leer por muchas horas sin que se me canse la vista.'),
(174, 'Me gusta leer y estudiar acerca de las cosas en que estoy trabajando.'),
(175, 'Siento debilidad general la mayor parte del tiempo.'),
(176, 'Muy pocas veces me duele la cabeza.'),
(177, 'Mis manos no se me han puesto torpes o poco hábiles.'),
(178, 'Algunas veces cuando paso una vergüenza, empiezo a transpirar, lo que me molesta muchísimo.'),
(179, 'No he tenido dificultad en mantener el equilibrio cuando camino.'),
(180, 'Hay algo que no anda bien en mi mente.'),
(181, 'No sufro ataques de rinitis alérgica (estornudos crónicos, comezón en la cara) o de asma.'),
(182, 'He tenido ataques durante los cuáles no podía controlar mis movimientos o el habla, pero me daba cuenta de lo que ocurría a mi alrededor.'),
(183, 'No me agradan todas las personas que conozco.'),
(184, 'Muy pocas veces sueño despierto (a).'),
(185, 'Desearía no ser tan tímido.'),
(186, 'No tengo miedo de manejar dinero.'),
(187, 'Si yo fuera reportero (a), me gustaría mucho escribir noticias sobre teatro.'),
(188, 'Disfruto con muchas clases de juegos y diversiones distintas.'),
(189, 'Me gusta coquetear.'),
(190, 'Mi familia me trata más como niño(a) que como adulto.'),
(191, 'Me gustaría ser periodista.'),
(192, 'Mi madre es (era) una buena mujer.'),
(193, 'Cuando camino tengo mucho cuidado de no pisar las líneas de las veredas.'),
(194, 'Nunca he tenido erupciones en la piel que me hayan preocupado.'),
(195, 'Hay muy poco amor y compañerismo en mi familia, en comparación con otros hogares.'),
(196, 'Frecuentemente me encuentro preocupado por algo.'),
(197, 'Creo que me gustaría el trabajo de contratista de obras.'),
(198, 'Frecuentemente oigo voces sin saber de dónde vienen.'),
(199, 'Me gusta la ciencia.'),
(200, 'No me cuesta pedir ayuda a mis amigos, aunque no pueda devolverles el favor.'),
(201, 'Me gusta mucho cazar.'),
(202, 'Con frecuencia mis padres han objetado el tipo de gente con la que acostumbraba andar.'),
(203, 'A veces chismorreo un poco.'),
(204, 'Aparentemente oigo tan bien como la mayoría de la gente.'),
(205, 'Algunos de mis familiares tienen hábitos que me incomodan y me fastidian muchísimo.'),
(206, 'A veces siento que puedo decidirme con extraordinaria facilidad.'),
(207, 'Me gustaría pertenecer a varios clubes o asociaciones.'),
(208, 'Rara vez noto los latidos de mi corazón y muy pocas veces me falta el aliento.'),
(209, 'Me gusta hablar sobre sexo.'),
(210, 'Me gusta visitar lugares donde nunca he estado.'),
(211, 'He sido formado (a) en un modo de vida basado en el deber y lo he seguido siempre fielmente.'),
(212, 'Algunas veces he sido un obstáculo para personas que estaban tratando de hacer algo, no porque eso fuera de mucha importancia, sino por cuestión de principios.'),
(213, 'Me enojo con facilidad, pero se me pasa pronto.'),
(214, 'He sido bastante independiente y libre en la disciplina familiar.'),
(215, 'Medito mucho las cosas o le doy mucha vuelta a las cosas.'),
(216, 'Alguien ha estado tratando de robarme.'),
(217, 'Casi todos mis parientes congenian o simpatizan conmigo.'),
(218, 'Tengo periodos de tanta intranquilidad, que no puedo permanecer sentado(a) en una silla por mucho tiempo.'),
(219, 'He sufrido desengaños amorosos.'),
(220, 'Nunca me preocupo por mi aspecto.'),
(221, 'Sueño frecuentemente con cosas que es mejor guardarlas para mí.'),
(222, 'Se debe enseñar a los niños los hechos fundamentales del sexo.'),
(223, 'Creo que no soy más nervioso(a) que la mayoría de las personas.'),
(224, 'Sufro de pocas o ninguna clase de dolor.'),
(225, 'Mi modo de hacer las cosas tiende a ser mal interpretado por los otros.'),
(226, 'A veces, sin ningún motivo o incluso cuando las cosas andan mal, me siento excesivamente feliz, “como un rey”.'),
(227, 'No culpo a nadie por tratar de apoderarse de lo que más pueda en este mundo.'),
(228, 'Hay personas que tratan de robar mis pensamientos o ideas.'),
(229, 'He tenido momentos en que mi mente se ha quedado en blanco, mis actividades se interrumpieron y yo no sabía lo que pasaba a mí alrededor.'),
(230, 'Puedo ser amigable con personas que hacen cosas que considero incorrectas.'),
(231, 'Me gusta estar en un grupo en que se hagan bromas unos a otros.'),
(232, 'A veces, en las elecciones, voto por personas acerca de quienes sé muy poco.'),
(233, 'Me cuesta empezar a hacer cualquier cosa.'),
(234, 'Creo que estoy condenado(a) o que no tengo salvación.'),
(235, 'En el colegio fui lento(a) para aprender.'),
(236, 'Si fuera artista me gustaría dibujar flores.'),
(237, 'No me molesta ser mejor parecido(a) de lo que soy.'),
(238, 'Transpiro con facilidad, aún en días fríos.'),
(239, 'Tengo absoluta confianza en mí mismo.'),
(240, 'A veces me ha sido imposible evitar el robar o el llevarme algo de una tienda.'),
(241, 'Es más seguro no confiar en nadie.'),
(242, 'Una o más veces por semana me pongo muy agitado(a).'),
(243, 'Cuando estoy en un grupo de gente, me cuesta pensar en cosas de qué hablar.'),
(244, 'Cuando me siento abatido(a), algo emocionante me saca casi siempre de ese estado.'),
(245, 'Cuando salgo de casa no me preocupo si las puertas y ventanas quedan bien cerradas.'),
(246, 'Creo que mis pecados son imperdonables.'),
(247, 'Tengo adormecida(s) una o varias partes de mi piel.'),
(248, 'No culpo a la persona que se aprovecha de alguien que se expone a que le ocurra tal cosa.'),
(249, 'Mi vista es tan buena ahora como lo ha sido en años.'),
(250, 'A veces me ha divertido tanto la astucia de un pillo que he deseado que se salga con la suya.'),
(251, 'Con frecuencia he sentido que desconocidos me miraban con ojos críticos.'),
(252, 'Todo tiene el mismo sabor.'),
(253, 'Todos los días tomo una cantidad extraordinaria de agua.'),
(254, 'La mayoría de la gente se hace de amigos porque les pueden ser útiles.'),
(255, 'No noto que me zumben o silben los oídos con frecuencia.'),
(256, 'De vez en cuando siento odio hacia miembros de mi familia a los que habitualmente quiero.'),
(257, 'Si fuera reportero(a), me gustaría mucho escribir noticias deportivas.'),
(258, 'Puedo dormir de día pero no de noche.'),
(259, 'Estoy seguro(a) de que la gente habla de mí.'),
(260, 'De vez en cuando me río de chistes sucios.'),
(261, 'Tengo muy pocos temores en comparación con mis amigos.'),
(262, 'No me perturbaría ante un grupo de personas si se me pidiera iniciar una discusión o dar mi opinión sobre algo que conozco bien.'),
(263, 'Siempre me da rabia con la ley cuando se pone en libertad a un criminal gracias a los alegatos de un abogado astuto.'),
(264, 'He bebido alcohol en exceso.'),
(265, 'Por lo general no le hablo a la gente hasta que ellos me hablan a mí.'),
(266, 'Nunca he tenido problemas con la ley.'),
(267, 'Tengo periodos en los que me siento desacostumbradamente alegre, sin que exista una razón especial.'),
(268, 'Me gustaría que no me perturbaran mis pensamientos sexuales.'),
(269, 'Si varias personas se hallan en apuros, lo mejor que pueden hacer es ponerse de acuerdo sobre lo que van a decir y mantenerse firmes en ello.'),
(270, 'No me molesta en forma especial ver sufrir a los animales.'),
(271, 'Creo que siento con mayor intensidad que la mayoría de la gente.'),
(272, 'Nunca en mi vida me ha gustado jugar con muñecas.'),
(273, 'Muchas veces la vida es una carga pesada para mí.'),
(274, 'Soy tan quisquilloso(a) acerca de algunos asuntos, que ni siquiera puedo hablar de ellos.'),
(275, 'En el colegio me era muy difícil hablar frente al grupo.'),
(276, 'Yo quiero (quería) a mi madre.'),
(277, 'Aun cuando esté acompañado(a), me siento solo(a) la mayor parte del tiempo.'),
(278, 'Recibo toda la comprensión que debiera.'),
(279, 'Rehúso participar en aquellos juegos para los que no soy bueno.'),
(280, 'Creo que hago amistades tan rápidamente como los demás.'),
(281, 'Me molesta tener gente a mi alrededor.'),
(282, 'Me han dicho que camino dormido.'),
(283, 'El hombre que provoca la tentación dejando la propiedad de valor sin protección, es tan culpable del robo como el ladrón mismo.'),
(284, 'Creo que casi todo el mundo diría una mentira para evitarse un problema.'),
(285, 'Soy más sensible que la mayoría de la gente.'),
(286, 'A la mayor parte de la gente, en su fuero interno, le disgusta esforzarse para ayudar a los demás.'),
(287, 'Muchos de mis sueños son en torno a temas sexuales.'),
(288, 'Mis padres y familiares me encuentran más defectos de los que debieran.'),
(289, 'Me siento avergonzado(a) con facilidad.'),
(290, 'Me preocupo del dinero y los negocios.'),
(291, 'Nunca he estado enamorado.'),
(292, 'Las cosas que han hecho algunos de mis familiares, me han asustado.'),
(293, 'Casi nunca sueño.'),
(294, 'Frecuentemente me salen manchas rojas en el cuello.'),
(295, 'Nunca he quedado paralizado(a) ni he sufrido de ninguna debilidad muscular desacostumbrada.'),
(296, 'Algunas veces quedo afónico(a) o me cambia la voz, aunque no esté resfriado(a).'),
(297, 'Mi madre o mi padre frecuentemente me obligaron a obedecer, aún cuando yo creía que no tenían razón.'),
(298, 'A veces percibo olores extraños.'),
(299, 'No puedo concentrarme en una sola cosa.'),
(300, 'Tengo razones para sentir celos de uno o más miembros de mi familia.'),
(301, 'Siento angustia por algo o por alguien casi todo el tiempo.'),
(302, 'Pierdo fácilmente la paciencia con la gente.'),
(303, 'La mayor parte del tiempo desearía estar muerto(a).'),
(304, 'A veces me siento tan excitado(a), que me cuesta dormirme.'),
(305, 'Ciertamente, en cuanto a preocupaciones, me ha “llovido sobre mojado”.'),
(306, 'A nadie le importa mucho lo que le sucede a uno.'),
(307, 'A veces oigo tan bien que me molesta.'),
(308, 'Se me olvida inmediatamente lo que la gente me dice.'),
(309, 'Generalmente tengo que detenerme y pensar antes de hacer algo, aunque sean asuntos sin importancia.'),
(310, 'A menudo cruzo la calle para evitar encontrarme con alguien que veo venir.'),
(311, 'A menudo siento como si las cosas no fueran reales.'),
(312, 'La única parte interesante del diario es la página cómica.'),
(313, 'Tengo la costumbre de contar cosas sin importancia, tales como puntos oscuros en anuncios luminosos, etc.'),
(314, 'No tengo enemigos que realmente deseen hacerme daño.'),
(315, 'Tiendo a ponerme en guardia con la gente que es algo más amistosa de lo que yo esperaba.'),
(316, 'Tengo pensamientos extraños y peculiares.'),
(317, 'Me angustio y me altero cuando tengo que salir de casa para hacer un corto viaje.'),
(318, 'Por lo general espero tener éxito en las cosas que hago.'),
(319, 'Digo cosas muy extrañas cuando estoy solo(a).'),
(320, 'He tenido miedo a cosas o personas que sabía que no me podían hacer daño.'),
(321, 'No temo entrar solo(a) a un recinto donde ya hay gente reunida hablando.'),
(322, 'Tengo miedo de usar un cuchillo o cualquier otra cosa muy afilada o puntiaguda.'),
(323, 'Algunas veces disfruto hiriendo a las personas que amo.'),
(324, 'Con facilidad puedo infundirle miedo a otros y a veces lo hago sólo por diversión.'),
(325, 'Tengo más dificultad para concentrarme que la que parecen tener los demás.'),
(326, 'Varias veces he dejado de hacer algo porque me he creído poco capaz.'),
(327, 'Malas palabras, a menudo palabras horribles, vienen a mi mente y no puedo librarme de ellas.'),
(328, 'A veces algún pensamiento sin importancia se me viene a la cabeza y me molesta por días.'),
(329, 'Casi todos los días sucede algo que me asusta.'),
(330, 'A veces estoy lleno(a) de energía.'),
(331, 'Tiendo a tomar las cosas muy en serio.'),
(332, 'A veces he disfrutado al ser herido(a) por un ser querido.'),
(333, 'La gente dice cosas insultantes y groseras de mí.'),
(334, 'Me siento incómodo(a) en lugares cerrados.'),
(335, 'No soy una persona demasiado cohibida'),
(336, 'Alguien controla mi mente.'),
(337, 'En las reuniones sociales o fiestas, es más probable que me siente solo(a) o con una sola persona en vez de unirme al grupo.'),
(338, 'La gente a menudo me desilusiona.'),
(339, 'Algunas veces he sentido que las dificultades se acumulan de tal modo que no podía superarlas.'),
(340, 'Me encanta ir a bailes.'),
(341, 'A veces mi mente parece trabajar más lentamente que de costumbre.'),
(342, 'En el metro, autobús, etc., con frecuencia converso con desconocidos.'),
(343, 'Disfruto con los niños.'),
(344, 'Disfruto apostando cuando se trata de poco dinero.'),
(345, 'Si me dieran la oportunidad, podría hacer algunas cosas que serían de gran beneficio para la humanidad.'),
(346, 'A menudo he conocido a personas a quienes suponía expertas y que no eran mejores que yo.'),
(347, 'Me siento un fracasado(a) cuando oigo hablar del éxito de alguien a quien conozco bien.'),
(348, 'A menudo pienso: “desearía volver a ser niño(a)”.'),
(349, 'Nunca estoy más feliz que cuando estoy solo.'),
(350, 'Si se diese la oportunidad yo sería un buen líder.'),
(351, 'Me siento incómodo(a) con los cuentos groseros.'),
(352, 'Por lo general, la gente exige más respeto para sus propios derechos, que lo que está dispuesta a concederle a los demás.'),
(353, 'Disfruto de las reuniones sociales sólo por estar con gente.'),
(354, 'Trato de recordar anécdotas interesantes para contárselas a otras personas.'),
(355, 'Una o más veces en mi vida he sentido que alguien me hacía hacer cosas hipnotizándome.'),
(356, 'Me es difícil dejar de lado una tarea que he emprendido aún cuando sea por poco tiempo.'),
(357, 'Frecuentemente no me entero de los chismes y habladurías del grupo a que pertenezco.'),
(358, 'A menudo he encontrado personas envidiosas de mis buenas ideas, sólo porque ellas no las habían pensado primero.'),
(359, 'Gozo con la excitación de una multitud.'),
(360, 'No me importa conocer gente nueva.'),
(361, 'Alguien ha estado tratando de influir en mi mente.'),
(362, 'Recuerdo haberme “hecho el enfermo(a)”, para zafarme de algo.'),
(363, 'Mis preocupaciones parecen desaparecer cuando estoy con un grupo de amigos animados.'),
(364, 'Me dan ganas de rendirme fácilmente cuando las cosas me salen mal.'),
(365, 'Me gusta hacerle saber a la gente lo que pienso acerca de las cosas.'),
(366, 'He tenido periodos en que me sentía tan lleno de energía que me parecía que no necesitaba dormir por varios días.'),
(367, 'Siempre que me es posible, evito encontrarme en una multitud.'),
(368, 'Me acobardo al enfrentar una crisis o dificultad.'),
(369, 'Tiendo a dejar de hacer algo que deseo cuando otros creen que no vale la pena hacerlo.'),
(370, 'Me gustan las fiestas y eventos sociales.'),
(371, 'A menudo he deseado pertenecer al sexo opuesto.'),
(372, 'No me enojo con facilidad.'),
(373, 'En el pasado he hecho cosas malas de las que nunca le he contado nada a nadie.'),
(374, 'La mayoría de la gente utiliza medios no muy correctos para salir adelante en la vida.'),
(375, 'Me pongo nervioso cuando me hacen preguntas personales.'),
(376, 'Creo que no puedo planificar mi propio futuro.'),
(377, 'No estoy contento con mi forma de ser.'),
(378, 'Me enojo cuando mis amigos o familiares me aconsejan cómo vivir mi vida.'),
(379, 'Me pegaron mucho cuando era pequeño.'),
(380, 'Me molesta que digan cosas agradables de mí.'),
(381, 'No me gusta oír a los demás opinando sobre la vida.'),
(382, 'A menudo tengo serios desacuerdos con personas cercanas a mí.'),
(383, 'Cuando las cosas se ponen realmente malas, sé que puedo contar con mi familia.'),
(384, 'Me gustaba jugar “a las visitas” cuando era un niño.'),
(385, 'No le tengo miedo al fuego.'),
(386, 'A veces me he mantenido a distancia de una persona por temor a hacer o decir algo que pudiera lamentar más tarde.'),
(387, 'Puedo expresar mis verdaderos sentimientos sólo cuando bebo.'),
(388, 'Rara vez estoy “bajoneado”.'),
(389, 'A menudo me dicen que soy “intenso”.'),
(390, 'Me gustaría dejar de preocuparme por cosas que he dicho y que pudiesen haber herido los sentimientos de alguien.'),
(391, 'Me siento incapaz de hablar de mí mismo.'),
(392, 'Le tengo miedo a los relámpagos entre otras cosas.'),
(393, 'Me gusta mantener a la gente a la expectativa acerca de lo que voy a hacer luego.'),
(394, 'Mis planes frecuentemente han tenido múltiples contratiempos que me han obligado a abandonarlos.'),
(395, 'Me asusta estar sólo en la oscuridad.'),
(396, 'A menudo me he sentido mal cuando me han malentendido al tratar de evitar que alguien cometa un error.'),
(397, 'Los huracanes me aterran.'),
(398, 'Frecuentemente pido un consejo a la gente.'),
(399, 'El futuro es demasiado incierto como para que una persona haga planes serios.'),
(400, 'Con frecuencia, aun cuando todo me salga bien, siento que nada me importa.'),
(401, 'No le tengo miedo al agua.'),
(402, 'Frecuentemente tengo que “consultar con la almohada” antes de decidir qué hacer.'),
(403, 'A menudo la gente ha interpretado mal mis intenciones cuando trataba de corregirla y ayudarla.'),
(404, 'No tengo dificultad para tragar la comida.'),
(405, 'Por lo general soy tranquilo(a) y no me altero fácilmente.'),
(406, 'Ciertamente disfrutaría al ganarle a un pillo con sus propias armas.'),
(407, 'Merezco severos castigos por mis pecados.'),
(408, 'Tiendo a preocuparme tanto por los desengaños, que no puedo dejar de pensar en ellos.'),
(409, 'Me molesta que alguien me observe cuando trabajo, aunque yo sepa que puedo hacerlo bien.'),
(410, 'A menudo me siento tan molesto(a) cuando alguien trata de meterse en una fila, que le llamo la atención.'),
(411, 'A veces pienso que no sirvo para nada.'),
(412, 'Cuando era pequeño, a menudo no iba a la escuela debiendo hacerlo.'),
(413, 'Uno o dos miembros de mi familia son muy nerviosos.'),
(414, 'A veces he tenido que ser rudo con personas groseras o molestosas.'),
(415, 'Me preocupo mucho por posibles desgracias.'),
(416, 'Tengo opiniones políticas claras.'),
(417, 'Me gustaría ser piloto de carreras.'),
(418, 'No hay problema en hacerle el quite a la ley sin quebrantarle.'),
(419, 'Hay algunas personas a quienes detesto tanto, que íntimamente siento placer cuando los pillan haciendo algo incorrecto.'),
(420, 'Me pone nervioso tener que esperar.'),
(421, 'Puedo dejar de hacer algo que quiero hacer si los demás creen que no lo estoy haciendo bien.'),
(422, 'Me gustaba la acción cuando era joven.'),
(423, 'Frecuentemente debo de hacer todo lo necesario para ganarle una discusión a alguien que me ha llevado la contraria.'),
(424, 'Me molesta que me mire la gente en las calles, tiendas, autobuses, etc.'),
(425, 'El hombre que más tenía que ver conmigo cuando era niño(a) (mi padre, padrastro, etc.) fue muy estricto.'),
(426, 'Me gustaba jugar al “avión” (rayuela).'),
(427, 'Nunca he tenido visiones.'),
(428, 'Varias veces me he arrepentido de la trayectoria de trabajo de toda mi vida.'),
(429, 'Excepto por orden del médico, nunca tomo drogas o pastillas para dormir.'),
(430, 'A menudo lamento ser tan mal genio y gruñón.'),
(431, 'En el colegio mis notas de conducta fueron habitualmente malas.'),
(432, 'Me fascina el fuego.'),
(433, 'Cuando estoy acorralado(a), digo sólo aquella parte de la verdad que es probable que no me perjudique.'),
(434, 'Si me encontrara en dificultades junto con varios amigos que fueran tan culpables como yo, preferiría echarme toda la culpa que delatarlos.'),
(435, 'A menudo le tengo miedo a la oscuridad.'),
(436, 'Cuando un hombre está con una mujer generalmente está pensando en cosas relativas al sexo de ella.'),
(437, 'Generalmente “le hablo claro” a la gente a quién estoy tratando de cambiar.'),
(438, 'Me produce terror la idea de un terremoto.'),
(439, 'Rápidamente me vuelvo ciento por ciento partidario(a) de una buena idea.'),
(440, 'Generalmente resuelvo las cosas solo(a) en vez de buscar a alguien que me enseñe.'),
(441, 'Temo encontrarme en un closet o lugar pequeño cerrado.'),
(442, 'Debo admitir que a veces me he preocupado sin motivo por algo que realmente no importaba.'),
(443, 'No trato de ocultar la mala opinión o lástima que me inspira una persona, a fin de que ésta no sepa mi manera de pensar.'),
(444, 'Soy una persona muy tensa.'),
(445, 'Frecuentemente he trabajado para personas que parece que arreglan las cosas de tal modo, que ellas son las que reciben el reconocimiento de una buena labor, sin embargo son capaces de atribuir los errores a los otros que están bajo ellos.'),
(446, 'A veces me es difícil defender mis derechos por ser tan reservado(a).'),
(447, 'La suciedad me asusta o me repugna.'),
(448, 'Tengo una vida de ensueños acerca de la cual no cuento a nadie.'),
(449, 'Algunos de mis familiares tienen mal genio.'),
(450, 'No puedo hacer nada bien.'),
(451, 'A menudo me he sentido culpable porque he fingido mayor pesar acerca de algo del que realmente sentía.'),
(452, 'Como norma, defiendo con firmeza mis propias opiniones.'),
(453, 'No temo a las arañas.'),
(454, 'El futuro me parece sin esperanzas.'),
(455, 'Los miembros de mi familia y mis parientes más cercanos de llevan bastante bien.'),
(456, 'Me gustaría usar ropa cara.'),
(457, 'La gente puede hacerme cambiar de opinión muy fácilmente, aún en cosas sobre las que yo creía estar decidido(a).'),
(458, 'Me ponen nerviosos ciertos animales.'),
(459, 'Puedo soportar tanto dolor como los demás.'),
(460, 'Varias veces he sido el último en darme por vencido al tratar de hacer algo.'),
(461, 'Me irrita que la gente me apure.'),
(462, 'No tengo miedo a los ratones.'),
(463, 'Varias veces por semana siento como si algo terrible fuera a suceder.'),
(464, 'Me siento cansado(a) la mayor parte del tiempo.'),
(465, 'Me gusta reparar los cerrojos de las puertas'),
(466, 'A veces estoy seguro(a) que los demás saben lo que estoy pensando.'),
(467, 'Me gusta leer sobre ciencia.'),
(468, 'Tengo miedo de estar solo(a) en un sitio amplio al descubierto.'),
(469, 'Algunas veces me siento a punto de derrumbarme.'),
(470, 'Un gran número de personas son culpables de mala conducta sexual.'),
(471, 'Con frecuencia he tenido miedo en la noche.'),
(472, 'Me molesta mucho que se me olvide dónde pongo las cosas.'),
(473, 'La persona hacia quien sentía mayor afecto y admiración cuando niño(a), era una mujer (madre, hermana, tía u otra mujer).'),
(474, 'Me gustan más las historias de aventuras que las románticas.'),
(475, 'A menudo me confundo y olvido qué quiero decir.'),
(476, 'Soy muy torpe y atolondrado.'),
(477, 'Me gustan mucho los deportes rudos (como el rugby y el fútbol).'),
(478, 'Odio a toda mi familia.'),
(479, 'Algunas personas piensan que es difícil llegar a conocerme.'),
(480, 'Paso la mayor parte de mi tiempo libre solo.'),
(481, 'Cuando la gente hace algo que me molesta se lo hago saber.'),
(482, 'Generalmente me cuesta mucho decidir qué hacer.'),
(483, 'La gente no me encuentra atractivo(a).'),
(484, 'La gente no es muy amable conmigo.'),
(485, 'A menudo siento que no soy tan bueno como los demás.'),
(486, 'Soy muy empecinado(a).'),
(487, 'He disfrutado fumando marihuana.'),
(488, 'Las enfermedades mentales son una señal de debilidad.'),
(489, 'Tengo problema de alcoholismo o drogadicción.'),
(490, 'Los fantasmas o espíritus pueden influir en la gente.'),
(491, 'Me siento desorientado cuando tengo que tomar decisiones importantes.'),
(492, 'Siempre trato de agradar, incluso cuando me molestan o critican.'),
(493, 'Cuando tengo un problema, me ayuda conversarlo con alguien.'),
(494, 'Mis metas principales en la vida, están a mi alcance.'),
(495, 'Pienso que la gente debería guardarse sus problemas personales.'),
(496, 'No siento mucha presión y estrés últimamente.'),
(497, 'Me molesta mucho pensar en hacer cambios en mi vida.'),
(498, 'Mis mayores problemas los causa el comportamiento de alguien cercano a mí.'),
(499, 'Odio ir al médico, incluso cuando estoy enfermo.'),
(500, 'Aunque no estoy contento con mi vida, no hay nada que pueda hacer al respecto por el momento.'),
(501, 'Hablar de los problemas y preocupaciones que uno tiene, a menudo es más útil que tomar drogas o medicamentos.'),
(502, 'Tengo algunos hábitos que son realmente dañinos.'),
(503, 'Cuando hay que resolver problemas, generalmente dejo que los demás lo hagan.'),
(504, 'Reconozco varios defectos en mí que sé que no podré cambiar.'),
(505, 'Estoy tan aburrido(a) de lo que tengo que hacer cada día, que me gustaría dejarlo y olvidarlo.'),
(506, 'Recientemente ha contemplado la posibilidad de suicidarme.'),
(507, 'A menudo me pongo muy irritable, cuando me interrumpen en mi trabajo.'),
(508, 'A menudo siento que puedo leer la mente de los demás.'),
(509, 'Me pone nervioso tomar decisiones importantes.'),
(510, 'Los demás me dicen que como demasiado rápido.'),
(511, 'Por lo menos una vez a la semana me emborracho o me drogo.'),
(512, 'He tenido una pérdida trágica en mi vida, de la cual sé que no me recuperaré jamás.'),
(513, 'A veces me enojo tanto que no sé lo que me pasa.'),
(514, 'Cuando me piden algo me cuesta decir no.'),
(515, 'Nunca soy más feliz que cuando estoy solo(a).'),
(516, 'Mi vida está vacía y no tiene sentido.'),
(517, 'Me cuesta conservar un trabajo.'),
(518, 'He cometido muchos grandes errores en mi vida.'),
(519, 'Me enojo conmigo mismo por ceder demasiado ante los demás.'),
(520, 'Últimamente he pensado mucho en suicidarme.'),
(521, 'Me gusta tomar decisiones y asignar tareas a los demás.'),
(522, 'Incluso si mi familia no está, siempre habrá alguien que se haga cargo de mí.'),
(523, 'Detesto hacer cola en los cines, restaurantes o recintos deportivos.'),
(524, 'Nadie lo sabe, pero he intentado suicidarme.'),
(525, 'Todo ocurre con demasiada prisa alrededor mío.'),
(526, 'Sé que soy una carga para los demás.'),
(527, 'Después de un mal día, generalmente necesito unos tragos para relajarme.'),
(528, 'Gran parte de los problemas que tengo se deben a la mala suerte.'),
(529, 'A veces no puedo dejar de hablar.'),
(530, 'A veces me auto infiero cortes o heridas sin saber por qué.'),
(531, 'Trabajo muchas horas a pesar de que mi trabajo no lo requiere.'),
(532, 'Generalmente me siento mejor después de un buen grito.'),
(533, 'Olvido dónde dejo las cosas.'),
(534, 'Si pudiera comenzar mi vida de nuevo, no cambiaría mucho.'),
(535, 'Me pongo muy irritable cuando la gente de la que dependo no hace su trabajo a tiempo.'),
(536, 'Si me irrito, con toda seguridad me duele la cabeza.'),
(537, 'Disfruto negociando asuntos difíciles.'),
(538, 'La mayoría de los hombres son infieles a sus esposas de vez en cuando.'),
(539, 'Últimamente ya no tengo ganas de solucionar mis problemas.'),
(540, 'Me he enojado y roto muebles o platos, estando bebido.'),
(541, 'Trabajo mejor cuando tengo un plazo impostergable.'),
(542, 'A veces me he enojado tanto con alguien como si fuera a estallar.'),
(543, 'A veces se me ocurren pensamientos terribles sobre mi familia.'),
(544, 'Los demás me dicen que tengo problemas de alcoholismo, pero no estoy de acuerdo con ellos.'),
(545, 'Siempre tengo muy poco tiempo para hacer las cosas.'),
(546, 'Últimamente pienso cada vez con mayor frecuencia en la muerte y la vida después de la muerte (y el más allá).'),
(547, 'A menudo guardo cosas que probablemente nunca usaré.'),
(548, 'A veces he tenido tanta rabia que he herido físicamente a alguien.'),
(549, 'Últimamente siento que me están evaluando en todo lo que hago.'),
(550, 'Tengo muy poco que ver con mis parientes ahora.'),
(551, 'A menudo me parece oír mis pensamientos en voz alta.'),
(552, 'Cuando estoy triste, visitar amigos puede subirme el ánimo.'),
(553, 'Gran parte de lo que me sucede ahora parece haberme sucedido antes.'),
(554, 'Cuando las cosas se ponen difíciles me dan ganas de darme por vencido.'),
(555, 'No puedo entrar solo en una pieza oscura, ni en mi propia casa.'),
(556, 'El dinero me preocupa mucho.'),
(557, 'El hombre debe ser el jefe de familia.'),
(558, 'El único lugar en que me siento relajado es en mi casa.'),
(559, 'A la gente con que trabajo no les interesan mis problemas.'),
(560, 'Estoy conforme con el dinero que gano.'),
(561, 'Generalmente tengo energía suficiente para hacer mi trabajo.'),
(562, 'Me cuesta aceptar cumplidos.'),
(563, 'En la mayoría de los matrimonios uno o ambos cónyuges son infelices.'),
(564, 'Casi nunca pierdo mi autocontrol.'),
(565, 'Últimamente me cuesta mucho recordar lo que me dicen.'),
(566, 'Cuando estoy triste o tengo pena, es mi trabajo el que sufre.'),
(567, 'La mayoría de las parejas casadas no se demuestran mucho afecto.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mmpi2_respuestas`
--

CREATE TABLE `mmpi2_respuestas` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `pregunta_id` int(11) NOT NULL,
  `respuesta` tinyint(1) NOT NULL COMMENT '1=Verdadero, 0=Falso',
  `fecha_guardado` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `mmpi2_respuestas`
--

INSERT INTO `mmpi2_respuestas` (`id`, `paciente_id`, `pregunta_id`, `respuesta`, `fecha_guardado`) VALUES
(1, 1, 1, 1, '2025-12-19 15:12:56'),
(2, 1, 2, 0, '2025-12-19 15:12:57'),
(3, 1, 3, 0, '2025-12-19 15:12:58'),
(4, 1, 4, 1, '2025-12-19 15:13:28'),
(5, 1, 5, 1, '2025-12-19 15:13:29'),
(6, 1, 6, 1, '2025-12-19 15:13:30'),
(7, 1, 7, 0, '2025-12-19 15:13:30'),
(8, 1, 8, 0, '2025-12-19 15:13:31'),
(9, 1, 9, 0, '2025-12-19 15:13:31'),
(680, 3, 1, 0, '2025-12-26 18:55:25'),
(681, 3, 2, 1, '2025-12-26 18:55:25'),
(682, 3, 3, 1, '2025-12-26 18:55:25'),
(683, 3, 4, 0, '2025-12-26 18:55:25'),
(684, 3, 5, 1, '2025-12-26 18:55:25'),
(685, 3, 6, 0, '2025-12-26 18:55:25'),
(686, 3, 7, 0, '2025-12-26 18:55:25'),
(687, 3, 8, 0, '2025-12-26 18:55:25'),
(688, 3, 9, 0, '2025-12-26 18:55:25'),
(689, 3, 10, 1, '2025-12-26 18:55:25'),
(690, 3, 11, 0, '2025-12-26 18:55:25'),
(691, 3, 12, 0, '2025-12-26 18:55:25'),
(692, 3, 13, 0, '2025-12-26 18:55:25'),
(693, 3, 14, 0, '2025-12-26 18:55:25'),
(694, 3, 15, 1, '2025-12-26 18:55:25'),
(695, 3, 16, 0, '2025-12-26 18:55:25'),
(696, 3, 17, 0, '2025-12-26 18:55:25'),
(697, 3, 18, 0, '2025-12-26 18:55:25'),
(698, 3, 19, 0, '2025-12-26 18:55:25'),
(699, 3, 20, 0, '2025-12-26 18:55:25'),
(700, 3, 21, 0, '2025-12-26 18:55:25'),
(701, 3, 22, 0, '2025-12-26 18:55:25'),
(702, 3, 23, 0, '2025-12-26 18:55:25'),
(703, 3, 24, 1, '2025-12-26 18:55:25'),
(704, 3, 25, 0, '2025-12-26 18:55:25'),
(705, 3, 26, 0, '2025-12-26 18:55:25'),
(706, 3, 27, 1, '2025-12-26 18:55:25'),
(707, 3, 28, 0, '2025-12-26 18:55:25'),
(708, 3, 29, 0, '2025-12-26 18:55:25'),
(709, 3, 30, 0, '2025-12-26 18:55:25'),
(710, 3, 31, 1, '2025-12-26 18:55:25'),
(711, 3, 32, 0, '2025-12-26 18:55:25'),
(712, 3, 33, 0, '2025-12-26 18:55:25'),
(713, 3, 34, 0, '2025-12-26 18:55:25'),
(714, 3, 35, 0, '2025-12-26 18:55:25'),
(715, 3, 36, 0, '2025-12-26 18:55:25'),
(716, 3, 37, 0, '2025-12-26 18:55:25'),
(717, 3, 38, 1, '2025-12-26 18:55:25'),
(718, 3, 39, 0, '2025-12-26 18:55:25'),
(719, 3, 40, 0, '2025-12-26 18:55:25'),
(720, 3, 41, 0, '2025-12-26 18:55:25'),
(721, 3, 42, 0, '2025-12-26 18:55:25'),
(722, 3, 43, 0, '2025-12-26 18:55:25'),
(723, 3, 44, 0, '2025-12-26 18:55:25'),
(724, 3, 45, 0, '2025-12-26 18:55:25'),
(725, 3, 46, 0, '2025-12-26 18:55:25'),
(726, 3, 47, 0, '2025-12-26 18:55:25'),
(727, 3, 48, 1, '2025-12-26 18:55:25'),
(728, 3, 49, 0, '2025-12-26 18:55:25'),
(729, 3, 50, 0, '2025-12-26 18:55:25'),
(730, 3, 51, 0, '2025-12-26 18:55:25'),
(731, 3, 52, 0, '2025-12-26 18:55:25'),
(732, 3, 53, 0, '2025-12-26 18:55:25'),
(733, 3, 54, 0, '2025-12-26 18:55:25'),
(734, 3, 55, 0, '2025-12-26 18:55:25'),
(735, 3, 56, 0, '2025-12-26 18:55:25'),
(736, 3, 57, 0, '2025-12-26 18:55:25'),
(737, 3, 58, 0, '2025-12-26 18:55:25'),
(738, 3, 59, 0, '2025-12-26 18:55:25'),
(739, 3, 60, 0, '2025-12-26 18:55:25'),
(740, 3, 61, 0, '2025-12-26 18:55:25'),
(741, 3, 62, 0, '2025-12-26 18:55:25'),
(742, 3, 63, 0, '2025-12-26 18:55:25'),
(743, 3, 64, 0, '2025-12-26 18:55:25'),
(744, 3, 65, 0, '2025-12-26 18:55:25'),
(745, 3, 66, 0, '2025-12-26 18:55:25'),
(746, 3, 67, 0, '2025-12-26 18:55:25'),
(747, 3, 68, 0, '2025-12-26 18:55:25'),
(748, 3, 69, 0, '2025-12-26 18:55:25'),
(749, 3, 70, 0, '2025-12-26 18:55:25'),
(750, 3, 71, 0, '2025-12-26 18:55:25'),
(751, 3, 72, 0, '2025-12-26 18:55:25'),
(752, 3, 73, 1, '2025-12-26 18:55:25'),
(753, 3, 74, 0, '2025-12-26 18:55:25'),
(754, 3, 75, 0, '2025-12-26 18:55:25'),
(755, 3, 76, 0, '2025-12-26 18:55:25'),
(756, 3, 77, 0, '2025-12-26 18:55:25'),
(757, 3, 78, 0, '2025-12-26 18:55:25'),
(758, 3, 79, 0, '2025-12-26 18:55:25'),
(759, 3, 80, 0, '2025-12-26 18:55:25'),
(760, 3, 81, 0, '2025-12-26 18:55:25'),
(761, 3, 82, 0, '2025-12-26 18:55:25'),
(762, 3, 83, 0, '2025-12-26 18:55:25'),
(763, 3, 84, 0, '2025-12-26 18:55:25'),
(764, 3, 85, 0, '2025-12-26 18:55:25'),
(765, 3, 86, 0, '2025-12-26 18:55:25'),
(766, 3, 87, 0, '2025-12-26 18:55:25'),
(767, 3, 88, 0, '2025-12-26 18:55:25'),
(768, 3, 89, 0, '2025-12-26 18:55:25'),
(769, 3, 90, 0, '2025-12-26 18:55:25'),
(770, 3, 91, 0, '2025-12-26 18:55:25'),
(771, 3, 92, 1, '2025-12-26 18:55:25'),
(772, 3, 93, 0, '2025-12-26 18:55:25'),
(773, 3, 94, 0, '2025-12-26 18:55:25'),
(774, 3, 95, 0, '2025-12-26 18:55:25'),
(775, 3, 96, 0, '2025-12-26 18:55:25'),
(776, 3, 97, 0, '2025-12-26 18:55:25'),
(777, 3, 98, 0, '2025-12-26 18:55:25'),
(778, 3, 99, 0, '2025-12-26 18:55:25'),
(779, 3, 100, 0, '2025-12-26 18:55:25'),
(780, 3, 101, 0, '2025-12-26 18:55:25'),
(781, 3, 102, 0, '2025-12-26 18:55:25'),
(782, 3, 103, 0, '2025-12-26 18:55:25'),
(783, 3, 104, 0, '2025-12-26 18:55:25'),
(784, 3, 105, 0, '2025-12-26 18:55:25'),
(785, 3, 106, 0, '2025-12-26 18:55:25'),
(786, 3, 107, 0, '2025-12-26 18:55:25'),
(787, 3, 108, 0, '2025-12-26 18:55:25'),
(788, 3, 109, 0, '2025-12-26 18:55:25'),
(789, 3, 110, 0, '2025-12-26 18:55:25'),
(790, 3, 111, 0, '2025-12-26 18:55:25'),
(791, 3, 112, 0, '2025-12-26 18:55:25'),
(792, 3, 113, 0, '2025-12-26 18:55:25'),
(793, 3, 114, 0, '2025-12-26 18:55:25'),
(794, 3, 115, 0, '2025-12-26 18:55:25'),
(795, 3, 116, 0, '2025-12-26 18:55:25'),
(796, 3, 117, 1, '2025-12-26 18:55:25'),
(797, 3, 118, 0, '2025-12-26 18:55:25'),
(798, 3, 119, 0, '2025-12-26 18:55:25'),
(799, 3, 120, 0, '2025-12-26 18:55:25'),
(800, 3, 121, 1, '2025-12-26 18:55:25'),
(801, 3, 122, 0, '2025-12-26 18:55:25'),
(802, 3, 123, 0, '2025-12-26 18:55:25'),
(803, 3, 124, 0, '2025-12-26 18:55:25'),
(804, 3, 125, 0, '2025-12-26 18:55:25'),
(805, 3, 126, 0, '2025-12-26 18:55:25'),
(806, 3, 127, 0, '2025-12-26 18:55:25'),
(807, 3, 128, 0, '2025-12-26 18:55:25'),
(808, 3, 129, 0, '2025-12-26 18:55:25'),
(809, 3, 130, 0, '2025-12-26 18:55:25'),
(810, 3, 131, 0, '2025-12-26 18:55:25'),
(811, 3, 132, 0, '2025-12-26 18:55:25'),
(812, 3, 133, 0, '2025-12-26 18:55:25'),
(813, 3, 134, 1, '2025-12-26 18:55:25'),
(814, 3, 135, 0, '2025-12-26 18:55:25'),
(815, 3, 136, 0, '2025-12-26 18:55:25'),
(816, 3, 137, 0, '2025-12-26 18:55:25'),
(817, 3, 138, 0, '2025-12-26 18:55:25'),
(818, 3, 139, 1, '2025-12-26 18:55:25'),
(819, 3, 140, 0, '2025-12-26 18:55:25'),
(820, 3, 141, 0, '2025-12-26 18:55:25'),
(821, 3, 142, 0, '2025-12-26 18:55:25'),
(822, 3, 143, 0, '2025-12-26 18:55:25'),
(823, 3, 144, 0, '2025-12-26 18:55:25'),
(824, 3, 145, 0, '2025-12-26 18:55:25'),
(825, 3, 146, 0, '2025-12-26 18:55:25'),
(826, 3, 147, 0, '2025-12-26 18:55:25'),
(827, 3, 148, 0, '2025-12-26 18:55:25'),
(828, 3, 149, 0, '2025-12-26 18:55:25'),
(829, 3, 150, 1, '2025-12-26 18:55:25'),
(830, 3, 151, 0, '2025-12-26 18:55:25'),
(831, 3, 152, 0, '2025-12-26 18:55:25'),
(832, 3, 153, 0, '2025-12-26 18:55:25'),
(833, 3, 154, 0, '2025-12-26 18:55:25'),
(834, 3, 155, 0, '2025-12-26 18:55:25'),
(835, 3, 156, 1, '2025-12-26 18:55:25'),
(836, 3, 157, 0, '2025-12-26 18:55:25'),
(837, 3, 158, 0, '2025-12-26 18:55:25'),
(838, 3, 159, 0, '2025-12-26 18:55:25'),
(839, 3, 160, 0, '2025-12-26 18:55:25'),
(840, 3, 161, 0, '2025-12-26 18:55:25'),
(841, 3, 162, 0, '2025-12-26 18:55:25'),
(842, 3, 163, 0, '2025-12-26 18:55:25'),
(843, 3, 164, 0, '2025-12-26 18:55:25'),
(844, 3, 165, 0, '2025-12-26 18:55:25'),
(845, 3, 166, 0, '2025-12-26 18:55:25'),
(846, 3, 167, 0, '2025-12-26 18:55:25'),
(847, 3, 168, 0, '2025-12-26 18:55:25'),
(848, 3, 169, 0, '2025-12-26 18:55:25'),
(849, 3, 170, 0, '2025-12-26 18:55:25'),
(850, 3, 171, 0, '2025-12-26 18:55:25'),
(851, 3, 172, 0, '2025-12-26 18:55:25'),
(852, 3, 173, 0, '2025-12-26 18:55:25'),
(853, 3, 174, 0, '2025-12-26 18:55:25'),
(854, 3, 175, 1, '2025-12-26 18:55:25'),
(855, 3, 176, 0, '2025-12-26 18:55:25'),
(856, 3, 177, 0, '2025-12-26 18:55:25'),
(857, 3, 178, 0, '2025-12-26 18:55:25'),
(858, 3, 179, 0, '2025-12-26 18:55:25'),
(859, 3, 180, 0, '2025-12-26 18:55:25'),
(860, 3, 181, 0, '2025-12-26 18:55:25'),
(861, 3, 182, 0, '2025-12-26 18:55:25'),
(862, 3, 183, 0, '2025-12-26 18:55:25'),
(863, 3, 184, 0, '2025-12-26 18:55:25'),
(864, 3, 185, 0, '2025-12-26 18:55:25'),
(865, 3, 186, 0, '2025-12-26 18:55:25'),
(866, 3, 187, 0, '2025-12-26 18:55:25'),
(867, 3, 188, 0, '2025-12-26 18:55:25'),
(868, 3, 189, 0, '2025-12-26 18:55:25'),
(869, 3, 190, 0, '2025-12-26 18:55:25'),
(870, 3, 191, 0, '2025-12-26 18:55:25'),
(871, 3, 192, 0, '2025-12-26 18:55:25'),
(872, 3, 193, 0, '2025-12-26 18:55:25'),
(873, 3, 194, 0, '2025-12-26 18:55:25'),
(874, 3, 195, 0, '2025-12-26 18:55:25'),
(875, 3, 196, 0, '2025-12-26 18:55:25'),
(876, 3, 197, 0, '2025-12-26 18:55:25'),
(877, 3, 198, 0, '2025-12-26 18:55:25'),
(878, 3, 199, 0, '2025-12-26 18:55:25'),
(879, 3, 200, 0, '2025-12-26 18:55:25'),
(880, 3, 201, 0, '2025-12-26 18:55:25'),
(881, 3, 202, 1, '2025-12-26 18:55:25'),
(882, 3, 203, 0, '2025-12-26 18:55:25'),
(883, 3, 204, 0, '2025-12-26 18:55:25'),
(884, 3, 205, 0, '2025-12-26 18:55:25'),
(885, 3, 206, 0, '2025-12-26 18:55:25'),
(886, 3, 207, 0, '2025-12-26 18:55:25'),
(887, 3, 208, 0, '2025-12-26 18:55:25'),
(888, 3, 209, 0, '2025-12-26 18:55:25'),
(889, 3, 210, 0, '2025-12-26 18:55:25'),
(890, 3, 211, 1, '2025-12-26 18:55:25'),
(891, 3, 212, 0, '2025-12-26 18:55:25'),
(892, 3, 213, 0, '2025-12-26 18:55:25'),
(893, 3, 214, 0, '2025-12-26 18:55:25'),
(894, 3, 215, 0, '2025-12-26 18:55:25'),
(895, 3, 216, 0, '2025-12-26 18:55:25'),
(896, 3, 217, 0, '2025-12-26 18:55:25'),
(897, 3, 218, 0, '2025-12-26 18:55:25'),
(898, 3, 219, 0, '2025-12-26 18:55:25'),
(899, 3, 220, 0, '2025-12-26 18:55:25'),
(900, 3, 221, 0, '2025-12-26 18:55:25'),
(901, 3, 222, 0, '2025-12-26 18:55:25'),
(902, 3, 223, 0, '2025-12-26 18:55:25'),
(903, 3, 224, 0, '2025-12-26 18:55:25'),
(904, 3, 225, 0, '2025-12-26 18:55:25'),
(905, 3, 226, 0, '2025-12-26 18:55:25'),
(906, 3, 227, 0, '2025-12-26 18:55:25'),
(907, 3, 228, 0, '2025-12-26 18:55:25'),
(908, 3, 229, 0, '2025-12-26 18:55:25'),
(909, 3, 230, 0, '2025-12-26 18:55:25'),
(910, 3, 231, 0, '2025-12-26 18:55:25'),
(911, 3, 232, 0, '2025-12-26 18:55:25'),
(912, 3, 233, 1, '2025-12-26 18:55:25'),
(913, 3, 234, 0, '2025-12-26 18:55:25'),
(914, 3, 235, 0, '2025-12-26 18:55:25'),
(915, 3, 236, 0, '2025-12-26 18:55:25'),
(916, 3, 237, 0, '2025-12-26 18:55:25'),
(917, 3, 238, 0, '2025-12-26 18:55:25'),
(918, 3, 239, 0, '2025-12-26 18:55:25'),
(919, 3, 240, 0, '2025-12-26 18:55:25'),
(920, 3, 241, 0, '2025-12-26 18:55:25'),
(921, 3, 242, 0, '2025-12-26 18:55:25'),
(922, 3, 243, 0, '2025-12-26 18:55:25'),
(923, 3, 244, 0, '2025-12-26 18:55:25'),
(924, 3, 245, 0, '2025-12-26 18:55:25'),
(925, 3, 246, 0, '2025-12-26 18:55:25'),
(926, 3, 247, 0, '2025-12-26 18:55:25'),
(927, 3, 248, 0, '2025-12-26 18:55:25'),
(928, 3, 249, 0, '2025-12-26 18:55:25'),
(929, 3, 250, 0, '2025-12-26 18:55:25'),
(930, 3, 251, 0, '2025-12-26 18:55:25'),
(931, 3, 252, 0, '2025-12-26 18:55:25'),
(932, 3, 253, 0, '2025-12-26 18:55:25'),
(933, 3, 254, 0, '2025-12-26 18:55:25'),
(934, 3, 255, 0, '2025-12-26 18:55:25'),
(935, 3, 256, 0, '2025-12-26 18:55:25'),
(936, 3, 257, 0, '2025-12-26 18:55:25'),
(937, 3, 258, 0, '2025-12-26 18:55:25'),
(938, 3, 259, 0, '2025-12-26 18:55:25'),
(939, 3, 260, 0, '2025-12-26 18:55:25'),
(940, 3, 261, 0, '2025-12-26 18:55:25'),
(941, 3, 262, 0, '2025-12-26 18:55:25'),
(942, 3, 263, 0, '2025-12-26 18:55:25'),
(943, 3, 264, 0, '2025-12-26 18:55:25'),
(944, 3, 265, 0, '2025-12-26 18:55:25'),
(945, 3, 266, 0, '2025-12-26 18:55:25'),
(946, 3, 267, 0, '2025-12-26 18:55:25'),
(947, 3, 268, 0, '2025-12-26 18:55:25'),
(948, 3, 269, 0, '2025-12-26 18:55:25'),
(949, 3, 270, 0, '2025-12-26 18:55:25'),
(950, 3, 271, 0, '2025-12-26 18:55:25'),
(951, 3, 272, 0, '2025-12-26 18:55:25'),
(952, 3, 273, 0, '2025-12-26 18:55:25'),
(953, 3, 274, 0, '2025-12-26 18:55:25'),
(954, 3, 275, 0, '2025-12-26 18:55:25'),
(955, 3, 276, 0, '2025-12-26 18:55:25'),
(956, 3, 277, 0, '2025-12-26 18:55:25'),
(957, 3, 278, 0, '2025-12-26 18:55:25'),
(958, 3, 279, 0, '2025-12-26 18:55:25'),
(959, 3, 280, 0, '2025-12-26 18:55:25'),
(960, 3, 281, 0, '2025-12-26 18:55:25'),
(961, 3, 282, 0, '2025-12-26 18:55:25'),
(962, 3, 283, 0, '2025-12-26 18:55:25'),
(963, 3, 284, 0, '2025-12-26 18:55:25'),
(964, 3, 285, 1, '2025-12-26 18:55:25'),
(965, 3, 286, 0, '2025-12-26 18:55:25'),
(966, 3, 287, 0, '2025-12-26 18:55:25'),
(967, 3, 288, 0, '2025-12-26 18:55:25'),
(968, 3, 289, 0, '2025-12-26 18:55:25'),
(969, 3, 290, 0, '2025-12-26 18:55:25'),
(970, 3, 291, 0, '2025-12-26 18:55:25'),
(971, 3, 292, 0, '2025-12-26 18:55:25'),
(972, 3, 293, 0, '2025-12-26 18:55:25'),
(973, 3, 294, 0, '2025-12-26 18:55:25'),
(974, 3, 295, 0, '2025-12-26 18:55:25'),
(975, 3, 296, 0, '2025-12-26 18:55:25'),
(976, 3, 297, 0, '2025-12-26 18:55:25'),
(977, 3, 298, 0, '2025-12-26 18:55:25'),
(978, 3, 299, 0, '2025-12-26 18:55:25'),
(979, 3, 300, 0, '2025-12-26 18:55:25'),
(980, 3, 301, 0, '2025-12-26 18:55:25'),
(981, 3, 302, 0, '2025-12-26 18:55:25'),
(982, 3, 303, 1, '2025-12-26 18:55:25'),
(983, 3, 304, 0, '2025-12-26 18:55:25'),
(984, 3, 305, 0, '2025-12-26 18:55:25'),
(985, 3, 306, 0, '2025-12-26 18:55:25'),
(986, 3, 307, 0, '2025-12-26 18:55:25'),
(987, 3, 308, 0, '2025-12-26 18:55:25'),
(988, 3, 309, 0, '2025-12-26 18:55:25'),
(989, 3, 310, 0, '2025-12-26 18:55:25'),
(990, 3, 311, 0, '2025-12-26 18:55:25'),
(991, 3, 312, 0, '2025-12-26 18:55:25'),
(992, 3, 313, 0, '2025-12-26 18:55:25'),
(993, 3, 314, 0, '2025-12-26 18:55:25'),
(994, 3, 315, 0, '2025-12-26 18:55:25'),
(995, 3, 316, 0, '2025-12-26 18:55:25'),
(996, 3, 317, 0, '2025-12-26 18:55:25'),
(997, 3, 318, 0, '2025-12-26 18:55:25'),
(998, 3, 319, 0, '2025-12-26 18:55:25'),
(999, 3, 320, 0, '2025-12-26 18:55:25'),
(1000, 3, 321, 0, '2025-12-26 18:55:25'),
(1001, 3, 322, 0, '2025-12-26 18:55:25'),
(1002, 3, 323, 0, '2025-12-26 18:55:25'),
(1003, 3, 324, 0, '2025-12-26 18:55:25'),
(1004, 3, 325, 0, '2025-12-26 18:55:25'),
(1005, 3, 326, 0, '2025-12-26 18:55:25'),
(1006, 3, 327, 0, '2025-12-26 18:55:25'),
(1007, 3, 328, 0, '2025-12-26 18:55:25'),
(1008, 3, 329, 0, '2025-12-26 18:55:25'),
(1009, 3, 330, 0, '2025-12-26 18:55:25'),
(1010, 3, 331, 0, '2025-12-26 18:55:25'),
(1011, 3, 332, 0, '2025-12-26 18:55:25'),
(1012, 3, 333, 0, '2025-12-26 18:55:25'),
(1013, 3, 334, 0, '2025-12-26 18:55:25'),
(1014, 3, 335, 0, '2025-12-26 18:55:25'),
(1015, 3, 336, 0, '2025-12-26 18:55:25'),
(1016, 3, 337, 0, '2025-12-26 18:55:25'),
(1017, 3, 338, 0, '2025-12-26 18:55:25'),
(1018, 3, 339, 0, '2025-12-26 18:55:25'),
(1019, 3, 340, 0, '2025-12-26 18:55:25'),
(1020, 3, 341, 0, '2025-12-26 18:55:25'),
(1021, 3, 342, 0, '2025-12-26 18:55:25'),
(1022, 3, 343, 0, '2025-12-26 18:55:25'),
(1023, 3, 344, 0, '2025-12-26 18:55:25'),
(1024, 3, 345, 0, '2025-12-26 18:55:25'),
(1025, 3, 346, 0, '2025-12-26 18:55:25'),
(1026, 3, 347, 0, '2025-12-26 18:55:25'),
(1027, 3, 348, 0, '2025-12-26 18:55:25'),
(1028, 3, 349, 0, '2025-12-26 18:55:25'),
(1029, 3, 350, 0, '2025-12-26 18:55:25'),
(1030, 3, 351, 0, '2025-12-26 18:55:25'),
(1031, 3, 352, 0, '2025-12-26 18:55:25'),
(1032, 3, 353, 0, '2025-12-26 18:55:25'),
(1033, 3, 354, 0, '2025-12-26 18:55:25'),
(1034, 3, 355, 0, '2025-12-26 18:55:25'),
(1035, 3, 356, 0, '2025-12-26 18:55:25'),
(1036, 3, 357, 0, '2025-12-26 18:55:25'),
(1037, 3, 358, 0, '2025-12-26 18:55:25'),
(1038, 3, 359, 0, '2025-12-26 18:55:25'),
(1039, 3, 360, 0, '2025-12-26 18:55:25'),
(1040, 3, 361, 0, '2025-12-26 18:55:25'),
(1041, 3, 362, 0, '2025-12-26 18:55:25'),
(1042, 3, 363, 0, '2025-12-26 18:55:25'),
(1043, 3, 364, 0, '2025-12-26 18:55:25'),
(1044, 3, 365, 0, '2025-12-26 18:55:25'),
(1045, 3, 366, 0, '2025-12-26 18:55:25'),
(1046, 3, 367, 0, '2025-12-26 18:55:25'),
(1047, 3, 368, 0, '2025-12-26 18:55:25'),
(1048, 3, 369, 0, '2025-12-26 18:55:25'),
(1049, 3, 370, 0, '2025-12-26 18:55:25'),
(1050, 3, 371, 0, '2025-12-26 18:55:25'),
(1051, 3, 372, 0, '2025-12-26 18:55:25'),
(1052, 3, 373, 0, '2025-12-26 18:55:25'),
(1053, 3, 374, 0, '2025-12-26 18:55:25'),
(1054, 3, 375, 0, '2025-12-26 18:55:25'),
(1055, 3, 376, 0, '2025-12-26 18:55:25'),
(1056, 3, 377, 0, '2025-12-26 18:55:25'),
(1057, 3, 378, 0, '2025-12-26 18:55:25'),
(1058, 3, 379, 0, '2025-12-26 18:55:25'),
(1059, 3, 380, 0, '2025-12-26 18:55:25'),
(1060, 3, 381, 0, '2025-12-26 18:55:25'),
(1061, 3, 382, 0, '2025-12-26 18:55:25'),
(1062, 3, 383, 0, '2025-12-26 18:55:25'),
(1063, 3, 384, 0, '2025-12-26 18:55:25'),
(1064, 3, 385, 0, '2025-12-26 18:55:25'),
(1065, 3, 386, 0, '2025-12-26 18:55:25'),
(1066, 3, 387, 0, '2025-12-26 18:55:25'),
(1067, 3, 388, 0, '2025-12-26 18:55:25'),
(1068, 3, 389, 0, '2025-12-26 18:55:25'),
(1069, 3, 390, 0, '2025-12-26 18:55:25'),
(1070, 3, 391, 0, '2025-12-26 18:55:25'),
(1071, 3, 392, 0, '2025-12-26 18:55:25'),
(1072, 3, 393, 0, '2025-12-26 18:55:25'),
(1073, 3, 394, 0, '2025-12-26 18:55:25'),
(1074, 3, 395, 0, '2025-12-26 18:55:25'),
(1075, 3, 396, 0, '2025-12-26 18:55:25'),
(1076, 3, 397, 0, '2025-12-26 18:55:25'),
(1077, 3, 398, 0, '2025-12-26 18:55:25'),
(1078, 3, 399, 0, '2025-12-26 18:55:25'),
(1079, 3, 400, 0, '2025-12-26 18:55:25'),
(1080, 3, 401, 0, '2025-12-26 18:55:25'),
(1081, 3, 402, 0, '2025-12-26 18:55:25'),
(1082, 3, 403, 0, '2025-12-26 18:55:25'),
(1083, 3, 404, 0, '2025-12-26 18:55:25'),
(1084, 3, 405, 0, '2025-12-26 18:55:25'),
(1085, 3, 406, 0, '2025-12-26 18:55:25'),
(1086, 3, 407, 0, '2025-12-26 18:55:25'),
(1087, 3, 408, 0, '2025-12-26 18:55:25'),
(1088, 3, 409, 0, '2025-12-26 18:55:25'),
(1089, 3, 410, 0, '2025-12-26 18:55:25'),
(1090, 3, 411, 0, '2025-12-26 18:55:25'),
(1091, 3, 412, 0, '2025-12-26 18:55:25'),
(1092, 3, 413, 0, '2025-12-26 18:55:25'),
(1093, 3, 414, 0, '2025-12-26 18:55:25'),
(1094, 3, 415, 0, '2025-12-26 18:55:25'),
(1095, 3, 416, 0, '2025-12-26 18:55:25'),
(1096, 3, 417, 0, '2025-12-26 18:55:25'),
(1097, 3, 418, 0, '2025-12-26 18:55:25'),
(1098, 3, 419, 0, '2025-12-26 18:55:25'),
(1099, 3, 420, 0, '2025-12-26 18:55:25'),
(1100, 3, 421, 0, '2025-12-26 18:55:25'),
(1101, 3, 422, 0, '2025-12-26 18:55:25'),
(1102, 3, 423, 0, '2025-12-26 18:55:25'),
(1103, 3, 424, 0, '2025-12-26 18:55:25'),
(1104, 3, 425, 0, '2025-12-26 18:55:25'),
(1105, 3, 426, 0, '2025-12-26 18:55:25'),
(1106, 3, 427, 0, '2025-12-26 18:55:25'),
(1107, 3, 428, 0, '2025-12-26 18:55:25'),
(1108, 3, 429, 0, '2025-12-26 18:55:25'),
(1109, 3, 430, 0, '2025-12-26 18:55:25'),
(1110, 3, 431, 0, '2025-12-26 18:55:25'),
(1111, 3, 432, 0, '2025-12-26 18:55:25'),
(1112, 3, 433, 0, '2025-12-26 18:55:25'),
(1113, 3, 434, 0, '2025-12-26 18:55:25'),
(1114, 3, 435, 0, '2025-12-26 18:55:25'),
(1115, 3, 436, 0, '2025-12-26 18:55:25'),
(1116, 3, 437, 0, '2025-12-26 18:55:25'),
(1117, 3, 438, 0, '2025-12-26 18:55:25'),
(1118, 3, 439, 0, '2025-12-26 18:55:25'),
(1119, 3, 440, 0, '2025-12-26 18:55:25'),
(1120, 3, 441, 0, '2025-12-26 18:55:25'),
(1121, 3, 442, 0, '2025-12-26 18:55:25'),
(1122, 3, 443, 0, '2025-12-26 18:55:25'),
(1123, 3, 444, 0, '2025-12-26 18:55:25'),
(1124, 3, 445, 0, '2025-12-26 18:55:25'),
(1125, 3, 446, 0, '2025-12-26 18:55:25'),
(1126, 3, 447, 0, '2025-12-26 18:55:25'),
(1127, 3, 448, 0, '2025-12-26 18:55:25'),
(1128, 3, 449, 0, '2025-12-26 18:55:25'),
(1129, 3, 450, 0, '2025-12-26 18:55:25'),
(1130, 3, 451, 0, '2025-12-26 18:55:25'),
(1131, 3, 452, 0, '2025-12-26 18:55:25'),
(1132, 3, 453, 0, '2025-12-26 18:55:25'),
(1133, 3, 454, 0, '2025-12-26 18:55:25'),
(1134, 3, 455, 0, '2025-12-26 18:55:25'),
(1135, 3, 456, 0, '2025-12-26 18:55:25'),
(1136, 3, 457, 0, '2025-12-26 18:55:25'),
(1137, 3, 458, 0, '2025-12-26 18:55:25'),
(1138, 3, 459, 0, '2025-12-26 18:55:25'),
(1139, 3, 460, 0, '2025-12-26 18:55:25'),
(1140, 3, 461, 0, '2025-12-26 18:55:25'),
(1141, 3, 462, 0, '2025-12-26 18:55:25'),
(1142, 3, 463, 0, '2025-12-26 18:55:25'),
(1143, 3, 464, 0, '2025-12-26 18:55:25'),
(1144, 3, 465, 0, '2025-12-26 18:55:25'),
(1145, 3, 466, 0, '2025-12-26 18:55:25'),
(1146, 3, 467, 0, '2025-12-26 18:55:25'),
(1147, 3, 468, 0, '2025-12-26 18:55:25'),
(1148, 3, 469, 0, '2025-12-26 18:55:25'),
(1149, 3, 470, 0, '2025-12-26 18:55:25'),
(1150, 3, 471, 0, '2025-12-26 18:55:25'),
(1151, 3, 472, 0, '2025-12-26 18:55:25'),
(1152, 3, 473, 0, '2025-12-26 18:55:25'),
(1153, 3, 474, 0, '2025-12-26 18:55:25'),
(1154, 3, 475, 0, '2025-12-26 18:55:25'),
(1155, 3, 476, 0, '2025-12-26 18:55:25'),
(1156, 3, 477, 0, '2025-12-26 18:55:25'),
(1157, 3, 478, 0, '2025-12-26 18:55:25'),
(1158, 3, 479, 0, '2025-12-26 18:55:25'),
(1159, 3, 480, 0, '2025-12-26 18:55:25'),
(1160, 3, 481, 0, '2025-12-26 18:55:25'),
(1161, 3, 482, 0, '2025-12-26 18:55:25'),
(1162, 3, 483, 0, '2025-12-26 18:55:25'),
(1163, 3, 484, 0, '2025-12-26 18:55:25'),
(1164, 3, 485, 0, '2025-12-26 18:55:25'),
(1165, 3, 486, 0, '2025-12-26 18:55:25'),
(1166, 3, 487, 0, '2025-12-26 18:55:25'),
(1167, 3, 488, 0, '2025-12-26 18:55:25'),
(1168, 3, 489, 0, '2025-12-26 18:55:25'),
(1169, 3, 490, 0, '2025-12-26 18:55:25'),
(1170, 3, 491, 0, '2025-12-26 18:55:25'),
(1171, 3, 492, 0, '2025-12-26 18:55:25'),
(1172, 3, 493, 0, '2025-12-26 18:55:25'),
(1173, 3, 494, 0, '2025-12-26 18:55:25'),
(1174, 3, 495, 0, '2025-12-26 18:55:25'),
(1175, 3, 496, 0, '2025-12-26 18:55:25'),
(1176, 3, 497, 0, '2025-12-26 18:55:25'),
(1177, 3, 498, 0, '2025-12-26 18:55:25'),
(1178, 3, 499, 0, '2025-12-26 18:55:25'),
(1179, 3, 500, 0, '2025-12-26 18:55:25'),
(1180, 3, 501, 0, '2025-12-26 18:55:25'),
(1181, 3, 502, 0, '2025-12-26 18:55:25'),
(1182, 3, 503, 0, '2025-12-26 18:55:25'),
(1183, 3, 504, 0, '2025-12-26 18:55:25'),
(1184, 3, 505, 0, '2025-12-26 18:55:25'),
(1185, 3, 506, 0, '2025-12-26 18:55:25'),
(1186, 3, 507, 0, '2025-12-26 18:55:25'),
(1187, 3, 508, 0, '2025-12-26 18:55:25'),
(1188, 3, 509, 0, '2025-12-26 18:55:25'),
(1189, 3, 510, 0, '2025-12-26 18:55:25'),
(1190, 3, 511, 0, '2025-12-26 18:55:25'),
(1191, 3, 512, 0, '2025-12-26 18:55:25'),
(1192, 3, 513, 0, '2025-12-26 18:55:25'),
(1193, 3, 514, 0, '2025-12-26 18:55:25'),
(1194, 3, 515, 0, '2025-12-26 18:55:25'),
(1195, 3, 516, 0, '2025-12-26 18:55:25'),
(1196, 3, 517, 0, '2025-12-26 18:55:25'),
(1197, 3, 518, 0, '2025-12-26 18:55:25'),
(1198, 3, 519, 0, '2025-12-26 18:55:25'),
(1199, 3, 520, 1, '2025-12-26 18:55:25'),
(1200, 3, 521, 0, '2025-12-26 18:55:25'),
(1201, 3, 522, 0, '2025-12-26 18:55:25'),
(1202, 3, 523, 0, '2025-12-26 18:55:25'),
(1203, 3, 524, 1, '2025-12-26 18:55:25'),
(1204, 3, 525, 0, '2025-12-26 18:55:25'),
(1205, 3, 526, 0, '2025-12-26 18:55:25'),
(1206, 3, 527, 0, '2025-12-26 18:55:25'),
(1207, 3, 528, 0, '2025-12-26 18:55:25'),
(1208, 3, 529, 0, '2025-12-26 18:55:25'),
(1209, 3, 530, 0, '2025-12-26 18:55:25'),
(1210, 3, 531, 0, '2025-12-26 18:55:25'),
(1211, 3, 532, 0, '2025-12-26 18:55:25'),
(1212, 3, 533, 0, '2025-12-26 18:55:25'),
(1213, 3, 534, 0, '2025-12-26 18:55:25'),
(1214, 3, 535, 0, '2025-12-26 18:55:25'),
(1215, 3, 536, 0, '2025-12-26 18:55:25'),
(1216, 3, 537, 0, '2025-12-26 18:55:25'),
(1217, 3, 538, 0, '2025-12-26 18:55:25'),
(1218, 3, 539, 0, '2025-12-26 18:55:25'),
(1219, 3, 540, 0, '2025-12-26 18:55:25'),
(1220, 3, 541, 0, '2025-12-26 18:55:25'),
(1221, 3, 542, 0, '2025-12-26 18:55:25'),
(1222, 3, 543, 0, '2025-12-26 18:55:25'),
(1223, 3, 544, 0, '2025-12-26 18:55:25'),
(1224, 3, 545, 0, '2025-12-26 18:55:25'),
(1225, 3, 546, 0, '2025-12-26 18:55:25'),
(1226, 3, 547, 0, '2025-12-26 18:55:25'),
(1227, 3, 548, 1, '2025-12-26 18:55:25'),
(1228, 3, 549, 0, '2025-12-26 18:55:25'),
(1229, 3, 550, 0, '2025-12-26 18:55:25'),
(1230, 3, 551, 0, '2025-12-26 18:55:25'),
(1231, 3, 552, 0, '2025-12-26 18:55:25'),
(1232, 3, 553, 0, '2025-12-26 18:55:25'),
(1233, 3, 554, 0, '2025-12-26 18:55:25'),
(1234, 3, 555, 0, '2025-12-26 18:55:25'),
(1235, 3, 556, 0, '2025-12-26 18:55:25'),
(1236, 3, 557, 0, '2025-12-26 18:55:25'),
(1237, 3, 558, 0, '2025-12-26 18:55:25'),
(1238, 3, 559, 0, '2025-12-26 18:55:25'),
(1239, 3, 560, 0, '2025-12-26 18:55:25'),
(1240, 3, 561, 0, '2025-12-26 18:55:25'),
(1241, 3, 562, 0, '2025-12-26 18:55:25'),
(1242, 3, 563, 0, '2025-12-26 18:55:25'),
(1243, 3, 564, 0, '2025-12-26 18:55:25'),
(1244, 3, 565, 0, '2025-12-26 18:55:25'),
(1245, 3, 566, 1, '2025-12-26 18:55:25'),
(1246, 3, 567, 1, '2025-12-26 18:55:25'),
(1703, 2, 1, 1, '2025-12-26 20:49:56'),
(1704, 2, 2, 0, '2025-12-26 20:49:56'),
(1705, 2, 3, 0, '2025-12-26 20:49:56'),
(1706, 2, 4, 1, '2025-12-26 20:49:56'),
(1707, 2, 5, 0, '2025-12-26 20:49:56'),
(1708, 2, 6, 0, '2025-12-26 20:49:56'),
(1709, 2, 7, 1, '2025-12-26 20:49:56'),
(1710, 2, 8, 0, '2025-12-26 20:49:56'),
(1711, 2, 9, 1, '2025-12-26 20:49:56'),
(1712, 2, 10, 1, '2025-12-26 20:49:56'),
(1713, 2, 11, 1, '2025-12-26 20:49:56'),
(1714, 2, 12, 1, '2025-12-26 20:49:56'),
(1715, 2, 13, 1, '2025-12-26 20:49:56'),
(1716, 2, 14, 1, '2025-12-26 20:49:56'),
(1717, 2, 15, 1, '2025-12-26 20:49:56'),
(1718, 2, 16, 0, '2025-12-26 20:49:56'),
(1719, 2, 17, 0, '2025-12-26 20:49:56'),
(1720, 2, 18, 0, '2025-12-26 20:49:56'),
(1721, 2, 19, 0, '2025-12-26 20:49:56'),
(1722, 2, 20, 0, '2025-12-26 20:49:56'),
(1723, 2, 21, 0, '2025-12-26 20:49:56'),
(1724, 2, 22, 0, '2025-12-26 20:49:56'),
(1725, 2, 23, 1, '2025-12-26 20:49:56'),
(1726, 2, 24, 1, '2025-12-26 20:49:56'),
(1727, 2, 25, 1, '2025-12-26 20:49:56'),
(1728, 2, 26, 1, '2025-12-26 20:58:53'),
(1729, 2, 27, 1, '2025-12-26 20:58:53'),
(1730, 2, 28, 1, '2025-12-26 20:58:53'),
(1731, 2, 29, 0, '2025-12-26 20:58:53'),
(1732, 2, 30, 1, '2025-12-26 20:58:53'),
(1733, 2, 31, 1, '2025-12-26 20:58:53'),
(1734, 2, 32, 1, '2025-12-26 20:58:53'),
(1735, 2, 33, 0, '2025-12-26 20:58:53'),
(1736, 2, 34, 0, '2025-12-26 20:58:53'),
(1737, 2, 35, 1, '2025-12-26 20:58:53'),
(1738, 2, 36, 0, '2025-12-26 20:58:53'),
(1739, 2, 37, 1, '2025-12-26 20:58:53'),
(1740, 2, 38, 0, '2025-12-26 20:58:53'),
(1741, 2, 39, 0, '2025-12-26 20:58:53'),
(1742, 2, 40, 1, '2025-12-26 20:58:53'),
(1743, 2, 41, 1, '2025-12-26 20:58:53'),
(1744, 2, 42, 0, '2025-12-26 20:58:53'),
(1745, 2, 43, 0, '2025-12-26 20:58:53'),
(1746, 2, 44, 1, '2025-12-26 20:58:53'),
(1747, 2, 45, 1, '2025-12-26 20:58:53'),
(1748, 2, 46, 1, '2025-12-26 20:58:53'),
(1749, 2, 47, 1, '2025-12-26 20:58:53'),
(1750, 2, 48, 1, '2025-12-26 20:58:53'),
(1751, 2, 49, 1, '2025-12-26 20:58:53'),
(1752, 2, 50, 1, '2025-12-26 20:58:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) UNSIGNED NOT NULL,
  `mensaje` text NOT NULL,
  `tipo` varchar(20) DEFAULT 'info',
  `leido` tinyint(1) DEFAULT 0,
  `fecha_creacion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `paciente_id`, `mensaje`, `tipo`, `leido`, `fecha_creacion`) VALUES
(1, 2, 'Nueva tarea asignada: Esta es una tarea de prueba', 'tarea', 1, '2025-12-27 11:35:10'),
(2, 2, 'Nueva tarea asignada: tarea 2', 'tarea', 1, '2025-12-27 13:16:03'),
(3, 2, 'Nueva tarea asignada: 2da tara de prueba', 'tarea', 1, '2025-12-27 14:11:39'),
(4, 2, 'Nueva tarea asignada: 3ra tarea', 'tarea', 1, '2025-12-27 14:12:11'),
(5, 2, 'Nueva tarea asignada: 4ta', 'tarea', 1, '2025-12-27 14:13:10'),
(6, 2, 'Nueva tarea asignada: 5ta', 'tarea', 1, '2025-12-27 14:14:12'),
(7, 2, 'Nueva tarea asignada: 6ta tarea', 'tarea', 1, '2025-12-27 14:18:00'),
(8, 2, 'Nueva tarea asignada: 7ma', 'tarea', 1, '2025-12-27 14:20:59'),
(9, 2, 'Nueva tarea asignada: nueva', 'tarea', 1, '2025-12-27 15:29:24'),
(10, 2, 'Nueva tarea asignada: neva 2', 'tarea', 1, '2025-12-27 15:31:20'),
(11, 2, 'Nueva tarea asignada: Hola', 'tarea', 1, '2025-12-27 15:59:54'),
(12, 2, 'Nueva tarea asignada: holas', 'tarea', 1, '2025-12-27 16:00:24'),
(13, 2, 'Nueva tarea asignada: hola', 'tarea', 1, '2025-12-27 16:15:46'),
(14, 2, 'Nueva tarea asignada: Hola', 'tarea', 1, '2025-12-27 16:32:52'),
(15, 2, 'Nueva tarea asignada: Hola 2', 'tarea', 1, '2025-12-27 16:34:22'),
(16, 2, 'Nueva tarea asignada: hola', 'tarea', 1, '2025-12-27 16:37:42'),
(17, 2, 'Nueva tarea asignada: Hola', 'tarea', 1, '2025-12-27 16:39:38'),
(18, 2, 'Nueva tarea asignada: tarea', 'tarea', 1, '2025-12-27 16:40:40'),
(19, 2, 'Nueva tarea asignada: nueva 23', 'tarea', 1, '2025-12-27 16:51:45'),
(20, 2, 'Nueva tarea asignada: tarea nueva', 'tarea', 1, '2025-12-27 16:54:21'),
(21, 2, 'Nueva tarea asignada: esta es una prueba de tarea', 'tarea', 1, '2025-12-27 16:59:20'),
(22, 2, 'Nueva tarea asignada: prueba de test', 'tarea', 1, '2025-12-27 17:00:41'),
(23, 2, 'Nueva tarea: nueva tarea 34', 'tarea', 1, '2025-12-27 17:04:13'),
(24, 2, 'Nueva tarea: nueva tarea', 'tarea', 1, '2025-12-27 17:04:42'),
(25, 2, 'Nueva tarea: nuebva tarea', 'tarea', 1, '2025-12-27 17:05:38'),
(26, 2, 'Nueva tarea: nueva tarea 56', 'tarea', 1, '2025-12-27 17:06:21'),
(27, 2, 'Nueva tarea: tarea 57', 'tarea', 0, '2025-12-27 17:09:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pacientes`
--

CREATE TABLE `pacientes` (
  `id` int(11) UNSIGNED NOT NULL,
  `fecha_registro` datetime NOT NULL DEFAULT current_timestamp(),
  `nombre_completo` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `ultimo_grado_estudios` varchar(100) NOT NULL,
  `ocupacion` varchar(100) NOT NULL,
  `historial_relacional` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Historial Familiar y Relacional.' CHECK (json_valid(`historial_relacional`)),
  `historial_sustancias` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Historial de consumo de Sustancias.' CHECK (json_valid(`historial_sustancias`)),
  `datos_contacto` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Teléfonos y Contacto de Emergencia.' CHECK (json_valid(`datos_contacto`)),
  `motivo_consulta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Motivo de Consulta y Expectativas.' CHECK (json_valid(`motivo_consulta`)),
  `antecedentes_clinicos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Antecedentes Clínicos y Salud Mental.' CHECK (json_valid(`antecedentes_clinicos`)),
  `aceptacion_consentimiento` tinyint(1) NOT NULL DEFAULT 0,
  `token_acceso` varchar(64) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mmpi2_habilitado` tinyint(1) DEFAULT 0,
  `foto_perfil` varchar(255) DEFAULT 'default_avatar.png',
  `proxima_cita` datetime DEFAULT NULL,
  `genero` char(1) DEFAULT NULL,
  `bdi2_habilitado` tinyint(1) DEFAULT 0,
  `test_mmpi_activo` tinyint(1) DEFAULT 0,
  `test_bdi_activo` tinyint(1) DEFAULT 0,
  `test_bai_activo` tinyint(1) DEFAULT 0,
  `test_tdah_activo` tinyint(1) DEFAULT 0,
  `modalidad_cita` varchar(20) DEFAULT 'presencial',
  `link_cita` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pacientes`
--

INSERT INTO `pacientes` (`id`, `fecha_registro`, `nombre_completo`, `email`, `fecha_nacimiento`, `ultimo_grado_estudios`, `ocupacion`, `historial_relacional`, `historial_sustancias`, `datos_contacto`, `motivo_consulta`, `antecedentes_clinicos`, `aceptacion_consentimiento`, `token_acceso`, `password`, `mmpi2_habilitado`, `foto_perfil`, `proxima_cita`, `genero`, `bdi2_habilitado`, `test_mmpi_activo`, `test_bdi_activo`, `test_bai_activo`, `test_tdah_activo`, `modalidad_cita`, `link_cita`) VALUES
(1, '2025-12-10 16:45:52', 'Alberto', 'afelix@gruponalix.com', '1982-05-17', 'Licenciatura', '', '{\"estado_civil\":\"Soltero\",\"nombre_vinculo\":\"\",\"relacion_tiempo_duracion\":\"\",\"separacion_tiempo\":\"\",\"separacion_causas\":\"\",\"tiene_hijos\":\"No\",\"hijos_detalle\":\"\",\"relacion_origen\":\"Buena\"}', '{\"fuma\":\"Socialmente\",\"alcohol\":\"Socialmente\",\"drogas_uso\":\"No\",\"drogas_tipo\":\"coca\",\"drogas_ultimo_consumo\":\"1 mes\"}', '{\"telefono_contacto\":\"6441972462\",\"telefono_emergencia\":\"6441972462\",\"relacion_emergencia\":\"yo\"}', '{\"motivo_explicito\":\"Prueba\",\"tiempo_problema\":\"1 a\\u00f1o\",\"expectativas\":\"muchas cosas\"}', '{\"terapia_previa_bool\":\"No\",\"terapia_tiempo_duracion\":\"\",\"terapia_tiempo_transcurrido\":\"\",\"terapia_causas\":\"\",\"terapia_motivo_finalizacion\":\"\",\"ant_psiquiatricos\":\"no\",\"medicacion_psiquiatrica\":\"no\",\"enfermedades_cronicas\":\"no\",\"calidad_sueno\":\"Bueno\",\"soporte_social\":\"Alto\"}', 1, NULL, '$2y$10$Z3s99HX3LoR/sisiH3fQIuBX4KRd.9GLI.b0/50kbUeV46bJ8w8v2', 1, 'default_avatar.png', '2025-12-24 12:00:00', NULL, 0, 0, 0, 1, 1, 'presencial', NULL),
(2, '2025-12-23 20:19:20', 'Juan Prueba MMPI', 'test_paciente@portal.com', '1990-05-15', 'Licenciatura', '', '[]', '[]', '[]', '[]', '[]', 0, NULL, '$2y$10$8On9hh5/6XbEainAm8Xlre3cE8FtIH/1fBRnSzshYmRs5Epm0gQnS', 1, 'default_avatar.png', '2026-01-01 10:00:00', 'm', 0, 1, 1, 1, 1, 'online', 'meet.com/sesion'),
(3, '2025-12-26 11:24:25', 'Miguel N.', 'miguel.n@ejemplo.com', '1985-06-15', '', '', NULL, NULL, NULL, NULL, NULL, 1, NULL, '$2y$10$8On9hh5/6XbEainAm8Xlre3cE8FtIH/1fBRnSzshYmRs5Epm0gQnS', 1, 'default_avatar.png', '2025-12-29 14:00:00', 'm', 0, 1, 0, 0, 0, 'presencial', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente_actividades`
--

CREATE TABLE `paciente_actividades` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) UNSIGNED NOT NULL,
  `descripcion` text NOT NULL,
  `fecha_asignacion` datetime DEFAULT current_timestamp(),
  `completado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `paciente_actividades`
--

INSERT INTO `paciente_actividades` (`id`, `paciente_id`, `descripcion`, `fecha_asignacion`, `completado`) VALUES
(1, 2, 'Esta es una tarea de prueba', '2025-12-27 11:35:10', 1),
(2, 2, 'tarea 2', '2025-12-27 13:16:03', 1),
(4, 2, '2da tara de prueba', '2025-12-27 14:11:39', 1),
(5, 2, '3ra tarea', '2025-12-27 14:12:11', 1),
(6, 2, '4ta', '2025-12-27 14:13:10', 1),
(7, 2, '5ta', '2025-12-27 14:14:12', 1),
(8, 2, '6ta tarea', '2025-12-27 14:18:00', 1),
(9, 2, '7ma', '2025-12-27 14:20:59', 1),
(10, 2, 'nueva', '2025-12-27 15:29:24', 1),
(11, 2, 'neva 2', '2025-12-27 15:31:20', 1),
(12, 2, 'Hola', '2025-12-27 15:59:54', 1),
(13, 2, 'holas', '2025-12-27 16:00:24', 1),
(14, 2, 'hola', '2025-12-27 16:15:46', 1),
(15, 2, 'Hola', '2025-12-27 16:32:52', 1),
(16, 2, 'Hola 2', '2025-12-27 16:34:22', 1),
(17, 2, 'hola', '2025-12-27 16:37:42', 1),
(18, 2, 'Hola', '2025-12-27 16:39:38', 1),
(19, 2, 'tarea', '2025-12-27 16:40:40', 1),
(20, 2, 'nueva 23', '2025-12-27 16:51:45', 1),
(21, 2, 'tarea nueva', '2025-12-27 16:54:21', 1),
(22, 2, 'esta es una prueba de tarea', '2025-12-27 16:59:20', 1),
(23, 2, 'prueba de test', '2025-12-27 17:00:41', 1),
(24, 2, 'nueva tarea 34', '2025-12-27 17:04:13', 1),
(25, 2, 'nueva tarea', '2025-12-27 17:04:42', 1),
(26, 2, 'nuebva tarea', '2025-12-27 17:05:38', 1),
(27, 2, 'nueva tarea 56', '2025-12-27 17:06:21', 1),
(28, 2, 'tarea 57', '2025-12-27 17:09:07', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas_mmpi`
--

CREATE TABLE `respuestas_mmpi` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `pregunta_id` int(11) NOT NULL,
  `respuesta` tinyint(4) NOT NULL,
  `fecha_guardado` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones`
--

CREATE TABLE `sesiones` (
  `id` int(11) UNSIGNED NOT NULL,
  `paciente_id` int(11) UNSIGNED NOT NULL,
  `fecha_sesion` datetime NOT NULL,
  `num_sesion` int(11) UNSIGNED NOT NULL,
  `notas_sesion` text DEFAULT NULL COMMENT 'Observaciones y registro de la terapia.',
  `tareas` text DEFAULT NULL COMMENT 'Tareas asignadas al paciente.',
  `tests_aplicados` varchar(255) DEFAULT NULL COMMENT 'Ej: Raven, EDV-20, HTP.',
  `fecha_proxima_sesion` datetime DEFAULT NULL COMMENT 'Cita agendada.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sesiones`
--

INSERT INTO `sesiones` (`id`, `paciente_id`, `fecha_sesion`, `num_sesion`, `notas_sesion`, `tareas`, `tests_aplicados`, `fecha_proxima_sesion`) VALUES
(1, 1, '2025-12-18 00:55:00', 1, 'todo bien', 'nada', 'ninguno', '2025-12-27 18:06:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones_pagos`
--

CREATE TABLE `sesiones_pagos` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `fecha_sesion` date NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `estado_pago` enum('Pendiente','Pagado') DEFAULT 'Pendiente',
  `metodo_pago` varchar(50) DEFAULT NULL,
  `referencia` varchar(100) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sesiones_pagos`
--

INSERT INTO `sesiones_pagos` (`id`, `paciente_id`, `fecha_sesion`, `monto`, `estado_pago`, `metodo_pago`, `referencia`, `fecha_registro`) VALUES
(1, 1, '2025-12-21', 500.00, 'Pagado', NULL, NULL, '2025-12-21 03:11:12'),
(2, 2, '2025-12-27', 500.00, 'Pagado', NULL, NULL, '2025-12-27 13:52:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tdah_respuestas`
--

CREATE TABLE `tdah_respuestas` (
  `id` int(11) NOT NULL,
  `paciente_id` int(10) UNSIGNED DEFAULT NULL,
  `pregunta_id` int(11) DEFAULT NULL,
  `respuesta` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tdah_respuestas`
--

INSERT INTO `tdah_respuestas` (`id`, `paciente_id`, `pregunta_id`, `respuesta`) VALUES
(1, 1, 1, 3),
(2, 1, 2, 2),
(3, 1, 3, 3),
(4, 1, 4, 2),
(5, 1, 5, 3),
(6, 1, 6, 0),
(7, 1, 7, 1),
(8, 1, 8, 0),
(9, 1, 9, 1),
(10, 1, 10, 0),
(11, 1, 11, 0),
(12, 1, 12, 1),
(13, 1, 13, 0),
(14, 1, 14, 0),
(15, 1, 15, 1),
(16, 1, 16, 0),
(17, 1, 17, 0),
(18, 1, 18, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tokens_registro`
--

CREATE TABLE `tokens_registro` (
  `token` varchar(10) NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_uso` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tokens_registro`
--

INSERT INTO `tokens_registro` (`token`, `usado`, `fecha_creacion`, `fecha_uso`) VALUES
('121125OPU', 0, '2025-12-10 18:39:09', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indices de la tabla `bai_preguntas`
--
ALTER TABLE `bai_preguntas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `bai_respuestas`
--
ALTER TABLE `bai_respuestas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_paciente_bai` (`paciente_id`);

--
-- Indices de la tabla `bdi2_preguntas`
--
ALTER TABLE `bdi2_preguntas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `bdi2_respuestas`
--
ALTER TABLE `bdi2_respuestas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_paciente_bdi` (`paciente_id`);

--
-- Indices de la tabla `fcm_tokens`
--
ALTER TABLE `fcm_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_token_paciente` (`paciente_id`);

--
-- Indices de la tabla `mmpi2_claves`
--
ALTER TABLE `mmpi2_claves`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mmpi2_escalas_claves`
--
ALTER TABLE `mmpi2_escalas_claves`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mmpi2_preguntas`
--
ALTER TABLE `mmpi2_preguntas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mmpi2_respuestas`
--
ALTER TABLE `mmpi2_respuestas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_resp` (`paciente_id`,`pregunta_id`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_notif_paciente` (`paciente_id`);

--
-- Indices de la tabla `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- Indices de la tabla `paciente_actividades`
--
ALTER TABLE `paciente_actividades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_actividad_paciente` (`paciente_id`);

--
-- Indices de la tabla `respuestas_mmpi`
--
ALTER TABLE `respuestas_mmpi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `paciente_id` (`paciente_id`,`pregunta_id`);

--
-- Indices de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paciente_id` (`paciente_id`);

--
-- Indices de la tabla `sesiones_pagos`
--
ALTER TABLE `sesiones_pagos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tdah_respuestas`
--
ALTER TABLE `tdah_respuestas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paciente_id` (`paciente_id`);

--
-- Indices de la tabla `tokens_registro`
--
ALTER TABLE `tokens_registro`
  ADD PRIMARY KEY (`token`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `bai_respuestas`
--
ALTER TABLE `bai_respuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de la tabla `bdi2_respuestas`
--
ALTER TABLE `bdi2_respuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de la tabla `fcm_tokens`
--
ALTER TABLE `fcm_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `mmpi2_claves`
--
ALTER TABLE `mmpi2_claves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mmpi2_escalas_claves`
--
ALTER TABLE `mmpi2_escalas_claves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `mmpi2_respuestas`
--
ALTER TABLE `mmpi2_respuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1753;

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `paciente_actividades`
--
ALTER TABLE `paciente_actividades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `respuestas_mmpi`
--
ALTER TABLE `respuestas_mmpi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `sesiones_pagos`
--
ALTER TABLE `sesiones_pagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tdah_respuestas`
--
ALTER TABLE `tdah_respuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `bai_respuestas`
--
ALTER TABLE `bai_respuestas`
  ADD CONSTRAINT `fk_paciente_bai` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `bdi2_respuestas`
--
ALTER TABLE `bdi2_respuestas`
  ADD CONSTRAINT `fk_paciente_bdi` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `fcm_tokens`
--
ALTER TABLE `fcm_tokens`
  ADD CONSTRAINT `fk_token_paciente` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `fk_notif_paciente` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `paciente_actividades`
--
ALTER TABLE `paciente_actividades`
  ADD CONSTRAINT `fk_actividad_paciente` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `sesiones`
--
ALTER TABLE `sesiones`
  ADD CONSTRAINT `sesiones_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tdah_respuestas`
--
ALTER TABLE `tdah_respuestas`
  ADD CONSTRAINT `tdah_respuestas_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
