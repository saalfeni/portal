<?php
// helpers_push.php - VERSIÓN CON DIAGNÓSTICO (LOGS)

function logPush($msg) {
    // Crea un archivo log_push.txt en la misma carpeta para ver errores
    file_put_contents(__DIR__ . '/log_push.txt', date('H:i:s') . " - " . $msg . PHP_EOL, FILE_APPEND);
}

function getAccessToken($keyFile) {
    logPush("Intentando leer JSON en: " . $keyFile);
    
    if (!file_exists($keyFile)) { 
        logPush("ERROR CRÍTICO: No se encuentra el archivo .json");
        return false; 
    }
    
    $content = file_get_contents($keyFile);
    $data = json_decode($content, true);
    
    if (!$data) {
        logPush("ERROR: El JSON está corrupto o vacío.");
        return false;
    }

    $now = time();
    $header = json_encode(['alg' => 'RS256', 'typ' => 'JWT']);
    $payload = json_encode([
        'iss' => $data['client_email'],
        'sub' => $data['client_email'],
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600,
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging'
    ]);

    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
    
    // VERIFICACIÓN DE OPENSSL
    if (!function_exists('openssl_sign')) {
        logPush("ERROR CRÍTICO: La extensión OpenSSL de PHP no está activada en XAMPP.");
        return false;
    }

    $signature = '';
    $success = openssl_sign($base64UrlHeader . "." . $base64UrlPayload, $signature, $data['private_key'], 'sha256');
    
    if (!$success) {
        logPush("ERROR: Falló la firma OpenSSL. Revisa la private_key del JSON.");
        return false;
    }

    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    $jwt = $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;

    // Petición a Google Auth
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        logPush("Error cURL Auth: " . curl_error($ch));
    }
    
    curl_close($ch);

    $json = json_decode($response, true);
    
    if (isset($json['error'])) {
        logPush("Google Auth Error: " . json_encode($json));
        return false;
    }

    logPush("Token de acceso generado correctamente.");
    return $json['access_token'] ?? false;
}

function enviarPush($pdo, $paciente_id, $titulo, $cuerpo) {
    logPush("--- INICIANDO ENVÍO PUSH ---");
    
    // 1. Obtener tokens
    $stmt = $pdo->prepare("SELECT token FROM fcm_tokens WHERE paciente_id = ?");
    $stmt->execute([$paciente_id]);
    $tokens = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (empty($tokens)) {
        logPush("Alerta: El paciente ID $paciente_id no tiene tokens registrados en BD.");
        return;
    }

    // 2. Obtener Credenciales
    $keyFile = __DIR__ . '/service_account.json'; // Ruta absoluta segura
    $accessToken = getAccessToken($keyFile);
    
    if (!$accessToken) return;

    // 3. Project ID
    $keyData = json_decode(file_get_contents($keyFile), true);
    $projectId = $keyData['project_id'];

    // 4. Enviar
    $url = "https://fcm.googleapis.com/v1/projects/$projectId/messages:send";
    $headers = ['Authorization: Bearer ' . $accessToken, 'Content-Type: application/json'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    foreach ($tokens as $token) {
        $payload = [
            'message' => [
                'token' => $token,
                'notification' => [
                    'title' => $titulo,
                    'body' => $cuerpo
                ],
                'webpush' => [
                    'headers' => ['Urgency' => 'high'],
                    'notification' => [
                        'icon' => 'https://unresponsible-abigail-cataclysmically.ngrok-free.dev/af/portal/assets/img/icon-192.png',
                        'click_action' => 'https://unresponsible-abigail-cataclysmically.ngrok-free.dev/af/portal/' 
                    ]
                ]
            ]
        ];

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        $result = curl_exec($ch);
        
        if (curl_errno($ch)) {
            logPush("Error cURL FCM: " . curl_error($ch));
        } else {
            logPush("Respuesta Google FCM para token " . substr($token, 0, 10) . "... : " . $result);
        }
    }
    curl_close($ch);
    logPush("--- FIN PROCESO ---");
}
?>