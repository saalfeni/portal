<?php
// consentimiento_informado.php - Documento de Consentimiento Informado para Psicoterapia
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consentimiento Informado para Psicoterapia</title>
    <link rel="stylesheet" href="admin_styles.css?v=1.2">
    <style>
        /* Estilos específicos para la impresión */
        body { font-size: 14px; line-height: 1.6; padding: 20px; }
        .document-container { max-width: 800px; margin: auto; background: var(--card-bg); padding: 30px; border-radius: 10px; }
        h1, h2, h3 { color: var(--primary); text-align: center; }
        h3 { border-bottom: 1px solid #444; padding-bottom: 5px; margin-top: 25px; }
        .clause { margin-bottom: 20px; }
        .clause strong { color: var(--text-main); }
        .signature-box { margin-top: 40px; padding-top: 20px; border-top: 1px solid #444; }
        .signature-box p { text-align: center; }
        .print-button { 
            background: var(--primary); color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;
            display: block; width: 250px; margin: 20px auto; text-align: center; text-decoration: none; font-weight: bold;
        }
        @media print {
            .print-button, .back-button, .logo-container { display: none !important; }
            .document-container { box-shadow: none; border: none; background: white; color: black; }
            h1, h2, h3 { color: black !important; }
            body { background-color: white !important; color: black !important; }
        }
    </style>
</head>
<body>
    <div class="document-container">
        
        <h1 style="color: var(--primary);">Consentimiento Informado para Psicoterapia</h1>
        <h3 style="color: var(--text-main);">Práctica Profesional en Psicoterapia | Sabás Alberto Félix Nieblas</h3>
        
        <p>Yo, el paciente (o representante legal), declaro haber sido informado/a de la naturaleza y propósito de las sesiones de psicoterapia ofrecidas por el Lic. Sabás Alberto Félix Nieblas (Cédula Profesional [Incluir Cédula]). Entiendo y acepto las siguientes cláusulas:</p>

        <div class="clause">
            <h2>1. Objetivo y Metodología</h2>
            <p><strong>Propósito:</strong> La psicoterapia es un proceso de colaboración destinado a fomentar el bienestar emocional, cognitivo y conductual, buscando la autocomprensión y la implementación de soluciones a problemas específicos.</p>
            <p><strong>Limitaciones:</strong> Entiendo que la terapia no es una cura mágica y que los resultados dependen de mi compromiso activo con el proceso y las tareas asignadas. No se garantiza el éxito total o inmediato.</p>
        </div>

        <div class="clause">
            <h2>2. Confidencialidad y Excepciones (Art. 18 de la Ley General de Salud)</h2>
            <p><strong>Confidencialidad:</strong> Toda la información discutida en las sesiones es estrictamente confidencial y está protegida por el Código de Ética Profesional del Psicólogo en México.</p>
            <p><strong>Límites Legales:</strong> La confidencialidad podrá romperse únicamente si el terapeuta considera que existe un **riesgo inminente y grave** para:</p>
            <ul>
                <li>Mi vida o integridad física (riesgo de suicidio).</li>
                <li>La vida o integridad física de terceros (amenaza seria de violencia).</li>
                <li>Casos de abuso, maltrato o negligencia que involucren a menores de edad, adultos mayores o personas con discapacidad, según lo exige la ley.</li>
            </ul>
        </div>

        <div class="clause">
            <h2>3. Sesiones y Tarifas</h2>
            <p><strong>Duración y Frecuencia:</strong> Las sesiones tienen una duración de [Especificar tiempo, ej: 50 minutos] y se acuerda una frecuencia inicial de [Ej: semanal].</p>
            <p><strong>Cancelaciones:</strong> Las cancelaciones deben notificarse con un mínimo de **24 horas de anticipación**. Las sesiones canceladas o no asistidas sin este aviso deberán ser cubiertas en su totalidad para mantener la continuidad del espacio terapéutico.</p>
            <p><strong>Tarifas:</strong> Acepto el costo acordado de $<?php echo number_format(500, 2); ?> MXN por sesión individual (referencia) y entiendo las modalidades de pago.</p>
        </div>

        <div class="clause">
            <h2>4. Cierre y Derechos</h2>
            <p><strong>Terminación:</strong> Tanto yo como el terapeuta podemos terminar la relación terapéutica. Se recomienda una sesión de cierre formal para evaluar el progreso y prevenir el abandono abrupto del proceso.</p>
            <p><strong>Derechos:</strong> Tengo derecho a preguntar, obtener claridad sobre el proceso, rechazar o modificar cualquier procedimiento, y solicitar una derivación a otro profesional si así lo deseo.</p>
        </div>

        <div class="signature-box">
            <p>Al marcar la casilla en el formulario de registro, confirmo que he leído, entendido y acepto los términos aquí establecidos, y autorizo el inicio del proceso psicoterapéutico.</p>
        </div>
        
        <a href="javascript:history.back()" class="print-button back-button" style="background: var(--text-grey); color: var(--dark);">← Volver al Formulario</a>
        <button class="print-button" onclick="window.print()">🖨️ Imprimir para Archivo</button>
    </div>
</body>
</html>