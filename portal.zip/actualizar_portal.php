<?php
// actualizar_portal.php - Procesa cambios en la ficha técnica del paciente
//session_start();
require 'db_connect.php';

// 1. Seguridad
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 2. Recolección de datos
    $paciente_id = filter_input(INPUT_POST, 'paciente_id', FILTER_VALIDATE_INT);
    $proxima_cita = !empty($_POST['proxima_cita']) ? $_POST['proxima_cita'] : null;
    $mmpi2_habilitado = isset($_POST['mmpi2_habilitado']) ? 1 : 0;
    
    // Si tienes campos adicionales como notas o diagnóstico, agrégalos aquí
    $ocupacion = trim($_POST['ocupacion'] ?? '');

    if ($paciente_id) {
        try {
            // 3. Actualización de la tabla pacientes
            $sql = "UPDATE pacientes SET 
                    proxima_cita = ?, 
                    mmpi2_habilitado = ?,
                    ocupacion = ?
                    WHERE id = ?";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$proxima_cita, $mmpi2_habilitado, $ocupacion, $paciente_id]);

            // 4. Redirección con éxito a la ficha del paciente
            header("Location: admin_detalle.php?id=$paciente_id&status=updated");
            exit;

        } catch (PDOException $e) {
            die("Error al actualizar el portal: " . $e->getMessage());
        }
    } else {
        die("ID de paciente no válido.");
    }
} else {
    header('Location: admin_dashboard.php');
    exit;
}