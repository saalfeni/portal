<?php
// registrar_pago.php - Procesador de cobros de sesiones
session_start();
require 'db_connect.php';

// 1. Verificación de seguridad
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 2. Recolección y sanitización de datos
    $paciente_id = filter_input(INPUT_POST, 'paciente_id', FILTER_VALIDATE_INT);
    $fecha_sesion = $_POST['fecha_sesion'];
    $monto = filter_input(INPUT_POST, 'monto', FILTER_VALIDATE_FLOAT);
    $estado_pago = $_POST['estado_pago']; // 'Pendiente' o 'Pagado'

    if ($paciente_id && $monto) {
        try {
            // 3. Inserción en la base de datos
            $sql = "INSERT INTO sesiones_pagos (paciente_id, fecha_sesion, monto, estado_pago) 
                    VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$paciente_id, $fecha_sesion, $monto, $estado_pago]);

            // 4. Redirección con éxito
            header("Location: admin_detalle.php?id=$paciente_id&tab=registro&pago=success");
            exit;

        } catch (PDOException $e) {
            die("Error al registrar el pago: " . $e->getMessage());
        }
    } else {
        die("Error: Datos incompletos.");
    }
} else {
    header('Location: admin_dashboard.php');
    exit;
}