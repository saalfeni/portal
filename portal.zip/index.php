<?php
// login_paciente.php - Acceso al Portal (Tema Oscuro Coherente)
//session_start();

// 1. Lógica de Logout integrada
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

require 'db_connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($email) && !empty($password)) {
        // Consulta alineada a tu base de datos (nombre_completo)
        $stmt = $pdo->prepare("SELECT id, nombre_completo, password FROM pacientes WHERE email = ?");
        $stmt->execute([$email]);
        $paciente = $stmt->fetch();

        if ($paciente && password_verify($password, $paciente['password'])) {
            $_SESSION['paciente_id'] = $paciente['id'];
            $_SESSION['paciente_nombre'] = $paciente['nombre_completo'];
            
            header("Location: paciente_dashboard.php");
            exit;
        } else {
            $error = "El correo electrónico o la contraseña son incorrectos.";
        }
    } else {
        $error = "Por favor, complete todos los campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso Pacientes | Portal de Salud Emocional</title>
    <link rel="stylesheet" href="admin_styles.css?v=2.1"> 
    <style>
        :root { 
            --turquesa: #40E0D0; 
            --primary: #3498db; 
            --bg-dark: #1e2126; 
            --card-dark: #2c313a;
        }

        body { 
            background: var(--bg-dark); 
            display: flex; align-items: center; justify-content: center; 
            height: 100vh; margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #abb2bf;
        }

        .login-card { 
            background: var(--card-dark); 
            padding: 40px; border-radius: 15px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.4); 
            width: 100%; max-width: 380px; 
            text-align: center; 
            border-top: 5px solid var(--turquesa);
            border: 1px solid rgba(255,255,255,0.05);
        }

        .logo-login { width: 140px; margin-bottom: 25px; filter: drop-shadow(0 0 5px rgba(0,0,0,0.2)); }
        
        .form-group { text-align: left; margin-bottom: 20px; }
        
        label { display: block; margin-bottom: 8px; color: var(--turquesa); font-size: 0.9rem; font-weight: 500; }
        
        input { 
            width: 100%; padding: 12px; 
            background: rgba(0,0,0,0.2); 
            border: 1px solid rgba(255,255,255,0.1); 
            border-radius: 8px; box-sizing: border-box; 
            font-size: 1rem; color: white;
            transition: all 0.3s;
        }

        input:focus { 
            border-color: var(--turquesa); 
            outline: none; 
            background: rgba(0,0,0,0.3);
            box-shadow: 0 0 8px rgba(64,224,208,0.2); 
        }

        .btn-login { 
            background: var(--primary); color: white; border: none; 
            padding: 14px; width: 100%; border-radius: 8px; 
            font-size: 1.1rem; font-weight: bold; cursor: pointer; 
            transition: 0.3s; margin-top: 10px;
        }

        .btn-login:hover { 
            background: #2980b9; 
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }

        .error-msg { 
            background: rgba(224, 108, 117, 0.2); 
            color: #e06c75; padding: 12px; 
            border-radius: 8px; margin-bottom: 20px; 
            font-size: 0.85rem; border: 1px solid #e06c75;
        }

        .footer-links { margin-top: 30px; font-size: 0.85rem; color: #5c6370; }
    </style>
	<link rel="manifest" href="manifest.json">
    <meta name="mobile-web-app-capable" content="yes"> <meta name="apple-mobile-web-app-capable" content="yes"> <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="theme-color" content="#1e1e1e">
<link rel="manifest" href="manifest.json">
<link rel="apple-touch-icon" href="assets/img/icon-192.png">
	<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./service-worker.js')
        .then(registration => {
          console.log('SW registrado con éxito:', registration.scope);
        })
        .catch(err => {
          console.log('Fallo al registrar SW:', err);
        });
    });
  }
</script>
</head>
<body>

    <div class="login-card">
        <img src="assets/img/logo.png" alt="Logo" class="logo-login">
        <h2 style="margin-bottom: 10px; color: white; font-weight: 600;">Bienvenido</h2>
        <p style="color: #5c6370; margin-bottom: 30px; font-size: 0.95rem;">Portal de Salud Emocional</p>

        <?php if ($error): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>Correo Electrónico</label>
                <input type="email" name="email" required placeholder="tu@correo.com">
            </div>

            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="password" required placeholder="••••••••">
            </div>

            <button type="submit" class="btn-login">Entrar al Portal</button>
        </form>

        <div class="footer-links">
            ¿Olvidó su contraseña? <br>
            <span style="color: #444;">Contacte a su terapeuta para restablecerla.</span>
        </div>
    </div>

</body>
</html>