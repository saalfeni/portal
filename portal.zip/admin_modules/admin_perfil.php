<?php
// admin_modules/admin_perfil.php
if (!isset($pdo)) exit;
$admin_id = $_SESSION['admin_id'] ?? 1;
$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. SUBIR LOGO DEL SISTEMA
    if (!empty($_FILES['logo_site']['name'])) {
        $dir_logo = "assets/img/";
        if (!is_dir($dir_logo)) mkdir($dir_logo, 0777, true);
        move_uploaded_file($_FILES['logo_site']['tmp_name'], $dir_logo . "logo.png");
        $mensaje .= "✅ Logo actualizado. ";
    }

    // 2. ACTUALIZAR DATOS PERSONALES Y PROFESIONALES
    $nombre = $_POST['nombre'] ?? '';
    $titulo = $_POST['titulo'] ?? '';
    $email  = $_POST['email'] ?? '';
    $cedula = $_POST['cedula'] ?? '';
    
    $params = [$nombre, $titulo, $email, $cedula];
    $extra_sql = "";

    // Procesar Foto de Perfil
    if (!empty($_FILES['foto']['name'])) {
        $path_foto = "uploads/perfil/admin_" . time() . ".jpg";
        if (!is_dir("uploads/perfil/")) mkdir("uploads/perfil/", 0777, true);
        if(move_uploaded_file($_FILES['foto']['tmp_name'], $path_foto)){
            $extra_sql .= ", foto = ?";
            $params[] = $path_foto;
        }
    }

    // Procesar Firma PNG Automática
    if (!empty($_FILES['firma']['name'])) {
        $path_firma = "uploads/perfil/firma_admin.png";
        if(move_uploaded_file($_FILES['firma']['tmp_name'], $path_firma)){
            $extra_sql .= ", firma = ?";
            $params[] = $path_firma;
        }
    }

    $sql = "UPDATE admins SET nombre = ?, titulo = ?, email = ?, cedula = ? $extra_sql WHERE id = ?";
    $params[] = $admin_id;
    
    if ($pdo->prepare($sql)->execute($params)) {
        $mensaje .= "✅ Configuración guardada correctamente.";
    }
}

// Consultar datos actuales (con limpieza de nulos para PHP 8.1+)
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch();

// Si no existe el registro, inicializar como vacío para evitar errores de visualización
if (!$admin) { $admin = []; }
?>

<div style="max-width: 1000px; margin: 0 auto; animation: fadeIn 0.5s ease;">
    <?php if($mensaje) echo "<div style='background:rgba(64,224,208,0.1); color:var(--turquesa); padding:15px; border-radius:10px; margin-bottom:20px; border:1px solid var(--turquesa);'>$mensaje</div>"; ?>

    <form method="POST" enctype="multipart/form-data" style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">
        
        <div style="background:#1a1a1a; padding:25px; border-radius:15px; border:1px solid #333;">
            <h3 style="color:var(--turquesa); margin-top:0; border-bottom:1px solid #222; padding-bottom:10px;">
                <i class="fas fa-user-md"></i> Perfil Profesional
            </h3>
            
            <div style="margin-bottom:15px;">
                <label style="display:block; margin-bottom:5px; font-size:0.8rem; color:#888;">Nombre Completo</label>
                <input type="text" name="nombre" value="<?php echo htmlspecialchars($admin['nombre'] ?? ''); ?>" style="width:100%; padding:10px; background:#0c0c0c; border:1px solid #333; color:#fff; border-radius:8px;">
            </div>

            <div style="margin-bottom:15px;">
                <label style="display:block; margin-bottom:5px; font-size:0.8rem; color:#888;">Título (Ej: Psicólogo Clínico)</label>
                <input type="text" name="titulo" value="<?php echo htmlspecialchars($admin['titulo'] ?? ''); ?>" style="width:100%; padding:10px; background:#0c0c0c; border:1px solid #333; color:#fff; border-radius:8px;">
            </div>

            <div style="margin-bottom:15px;">
                <label style="display:block; margin-bottom:5px; font-size:0.8rem; color:#888;">Cédula Profesional</label>
                <input type="text" name="cedula" value="<?php echo htmlspecialchars($admin['cedula'] ?? ''); ?>" style="width:100%; padding:10px; background:#0c0c0c; border:1px solid #333; color:#fff; border-radius:8px;">
            </div>

            <div style="margin-bottom:15px;">
                <label style="display:block; margin-bottom:5px; font-size:0.8rem; color:#888;">Correo Electrónico (Gravatar)</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($admin['email'] ?? ''); ?>" style="width:100%; padding:10px; background:#0c0c0c; border:1px solid #333; color:#fff; border-radius:8px;">
            </div>
        </div>

        <div style="background:#1a1a1a; padding:25px; border-radius:15px; border:1px solid #333;">
            <h3 style="color:var(--turquesa); margin-top:0; border-bottom:1px solid #222; padding-bottom:10px;">
                <i class="fas fa-camera"></i> Identidad y Firma
            </h3>
            
            <div style="margin-bottom:20px;">
                <label style="display:block; margin-bottom:5px; font-size:0.8rem; color:#888;">Foto de Perfil</label>
                <input type="file" name="foto" style="font-size:0.8rem; color:#666;">
                <?php if(!empty($admin['foto'])): ?>
                    <small style="color:var(--turquesa); display:block; margin-top:5px;">Foto actual registrada</small>
                <?php endif; ?>
            </div>

            <div style="margin-bottom:20px;">
                <label style="display:block; margin-bottom:5px; font-size:0.8rem; color:#888;">Firma para Documentos (PNG transparente)</label>
                <input type="file" name="firma" style="font-size:0.8rem; color:#666;">
                <?php if(!empty($admin['firma'])): ?>
                    <img src="<?php echo $admin['firma']; ?>" style="max-height: 50px; background: #fff; border-radius: 5px; margin-top: 10px; padding: 5px;">
                <?php endif; ?>
            </div>

            <hr style="border:0; border-top:1px solid #222; margin:20px 0;">

            <div style="margin-bottom:25px;">
                <label style="display:block; margin-bottom:5px; font-size:0.8rem; color:#888;">Cambiar Logo del Sistema (.png)</label>
                <input type="file" name="logo_site" style="font-size:0.8rem; color:#666;">
                <img src="assets/img/logo.png?v=<?php echo time(); ?>" style="max-height: 40px; margin-top: 10px; opacity: 0.5;">
            </div>
            
            <button type="submit" style="width:100%; background:var(--turquesa); color:#000; border:none; padding:15px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:1rem; transition:0.3s;">
                <i class="fas fa-save"></i> Guardar Configuración
            </button>
        </div>
    </form>
</div>

<style>
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    input:focus { border-color: var(--turquesa) !important; outline: none; box-shadow: 0 0 5px rgba(64, 224, 208, 0.2); }
</style>