<?php
// admin_modules/admin_contabilidad.php
if (!isset($pdo)) exit;

$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');

// Consulta usando la columna real 'fecha_sesion' de la tabla sesiones_pagos
$stmt_reporte = $pdo->prepare("SELECT sp.*, p.nombre_completo 
                              FROM sesiones_pagos sp 
                              JOIN pacientes p ON sp.paciente_id = p.id 
                              WHERE sp.fecha_sesion BETWEEN ? AND ? 
                              ORDER BY sp.fecha_sesion DESC");
$stmt_reporte->execute([$desde, $hasta]);
$reporte = $stmt_reporte->fetchAll();

$total_periodo = array_sum(array_column($reporte, 'monto'));
?>

<div class="contabilidad-container">
    <div class="filter-bar" style="background: var(--card); padding: 20px; border-radius: 15px; margin-bottom: 25px; border: 1px solid #333;">
        <form method="GET" style="display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end;">
            <input type="hidden" name="view" value="contabilidad">
            <div class="form-group">
                <label style="display:block; font-size:0.7rem; color:#888; margin-bottom:5px;">Desde:</label>
                <input type="date" name="desde" value="<?php echo $desde; ?>" style="background:#111; border:1px solid #333; color:#fff; padding:8px; border-radius:5px;">
            </div>
            <div class="form-group">
                <label style="display:block; font-size:0.7rem; color:#888; margin-bottom:5px;">Hasta:</label>
                <input type="date" name="hasta" value="<?php echo $hasta; ?>" style="background:#111; border:1px solid #333; color:#fff; padding:8px; border-radius:5px;">
            </div>
            <button type="submit" style="background:var(--turquesa); color:#000; border:none; padding:10px 20px; border-radius:5px; font-weight:bold; cursor:pointer;">
                <i class="fas fa-sync-alt"></i> Actualizar
            </button>
            
            <button type="button" onclick="imprimirReporte()" style="background:#fff; color:#000; border:none; padding:10px 20px; border-radius:5px; font-weight:bold; cursor:pointer;">
                <i class="fas fa-print"></i> Imprimir Reporte
            </button>
        </form>
    </div>

    <div class="results-card" style="background:var(--card); padding:25px; border-radius:20px; border:1px solid #222;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; border-bottom:1px solid #222; padding-bottom:15px;">
            <div>
                <h3 style="margin:0; color:#fff;">Reporte de Ingresos</h3>
                <small style="color:#666;">Periodo: <?php echo date('d/m/Y', strtotime($desde)); ?> al <?php echo date('d/m/Y', strtotime($hasta)); ?></small>
            </div>
            <div style="text-align:right;">
                <span style="display:block; font-size:0.8rem; color:#888;">Total Recaudado</span>
                <h2 style="margin:0; color:var(--turquesa); font-size:2rem;">$<?php echo number_format($total_periodo, 2); ?></h2>
            </div>
        </div>

        <div class="table-responsive">
            <table style="width:100%; border-collapse:collapse;">
                <thead>
                    <tr style="text-align:left; color:var(--turquesa); font-size:0.8rem; border-bottom:1px solid #333;">
                        <th style="padding:15px;">Fecha Sesión</th>
                        <th style="padding:15px;">Paciente</th>
                        <th style="padding:15px;">Método</th>
                        <th style="padding:15px; text-align:right;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($reporte as $reg): ?>
                    <tr style="border-bottom:1px solid #222;">
                        <td style="padding:15px;"><?php echo date('d/m/Y', strtotime($reg['fecha_sesion'])); ?></td>
                        <td style="padding:15px;"><?php echo htmlspecialchars($reg['nombre_completo']); ?></td>
                        <td style="padding:15px;"><span style="font-size:0.7rem; color:#888;"><?php echo $reg['metodo_pago'] ?? 'Efectivo'; ?></span></td>
                        <td style="padding:15px; text-align:right; color:var(--turquesa); font-weight:bold;">$<?php echo number_format($reg['monto'], 2); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function imprimirReporte() {
    const desde = "<?php echo $desde; ?>";
    const hasta = "<?php echo $hasta; ?>";
    const url = `admin_modules/imprimir_reporte.php?desde=${desde}&hasta=${hasta}`;
    
    // Abrir en una ventana nueva preparada para impresión
    window.open(url, '_blank');
}
</script>