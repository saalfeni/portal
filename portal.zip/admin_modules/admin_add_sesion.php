<?php
// admin_modules/admin_add_sesion.php
// CORRECCIÓN: Subimos un nivel para encontrar los archivos de la raíz
require '../db_connect.php'; 
require '../config_admin.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['admin_logged_in'])) { 
    header('Location: ../admin_login.php'); 
    exit; 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pacienteId = $_POST['paciente_id'];
    $fecha_bitacora = $_POST['fecha_sesion']; 
    $notas = trim($_POST['notas_subjetivas'] ?? '');
    
    // Datos de la PRÓXIMA CITA
    $proxima_cita = !empty($_POST['proxima_cita']) ? $_POST['proxima_cita'] : null;
    $modalidad = $_POST['modalidad'] ?? 'presencial';
    $link = ($modalidad == 'online') ? $_POST['link_cita'] : null;

    try {
        $pdo->beginTransaction();

        // 1. Guardar en Bitácora SOLO si hay notas
        if (!empty($notas)) {
            $stmt = $pdo->prepare("INSERT INTO sesiones (paciente_id, fecha, notas_subjetivas) VALUES (?, ?, ?)");
            $stmt->execute([$pacienteId, $fecha_bitacora, $notas]);
        }

        // 2. Actualizar Agenda en la ficha del paciente
        if ($proxima_cita) {
            $stmtDate = $pdo->prepare("UPDATE pacientes SET proxima_cita = ?, modalidad_cita = ?, link_cita = ? WHERE id = ?");
            $stmtDate->execute([$proxima_cita, $modalidad, $link, $pacienteId]);
        }

        $pdo->commit();
        
        // CORRECCIÓN DE REDIRECCIÓN: Subimos un nivel para ir a admin_dashboard.php
        header("Location: ../admin_dashboard.php?view=detalle&id=" . $pacienteId . "&tab=resumen");
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        die("Error al procesar: " . $e->getMessage());
    }
}