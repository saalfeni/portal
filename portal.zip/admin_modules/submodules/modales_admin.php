<div id="modal-sesion" class="modal-overlay" style="display:none;" onclick="closeModalOutside(event, 'modal-sesion')">
    <div class="modal-card" style="max-width: 550px;">
        <div class="modal-header">
            <h3>Nueva Entrada y Cita</h3>
            <button onclick="closeModal('modal-sesion')">&times;</button>
        </div>
        <form action="admin_modules/admin_add_sesion.php" method="POST" class="modal-form">
            <input type="hidden" name="paciente_id" value="<?php echo $paciente['id']; ?>">
            
            <div style="margin-bottom: 15px; border-bottom: 1px solid #333; padding-bottom: 15px;">
                <label style="color: var(--turquesa);">1. Nota de Evolución (Opcional)</label>
                <input type="date" name="fecha_sesion" value="<?php echo date('Y-m-d'); ?>" style="margin-bottom:10px;">
                <textarea name="notas_subjetivas" rows="4" placeholder="Escriba aquí los avances de hoy (deje vacío si solo desea agendar)..."></textarea>
            </div>

            <label style="color: var(--turquesa);">2. Agendar Próxima Cita</label>
            <input type="datetime-local" name="proxima_cita">
            
            <label>Modalidad</label>
            <select name="modalidad" onchange="toggleLinkField(this.value)">
                <option value="presencial">Presencial</option>
                <option value="online">En Línea (Video)</option>
            </select>

            <div id="wrapper-link-cita" style="display:none; animation: fadeIn 0.3s;">
                <label>Enlace de la sesión (Zoom/Meet)</label>
                <input type="text" name="link_cita" placeholder="https://zoom.us/j/...">
            </div>

            <button type="submit" class="btn-submit" style="margin-top: 10px;">Guardar Registro Completo</button>
        </form>
    </div>
</div>

<style>
    .modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.85); backdrop-filter: blur(8px);
        display: none; align-items: center; justify-content: center;
        z-index: 9999; padding: 20px;
    }
    .modal-card {
        background: #1e1e1e; border: 1px solid #333; border-radius: 20px;
        width: 100%; max-width: 500px; box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        animation: modalFadeIn 0.3s ease-out;
    }
    @keyframes modalFadeIn { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
    .modal-header { padding: 20px; border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center; }
    .modal-header h3 { margin: 0; font-size: 1.1rem; color: var(--turquesa); }
    .modal-header button { background: none; border: none; color: #666; font-size: 1.5rem; cursor: pointer; }
    .modal-form { padding: 20px; }
    .modal-form label { display: block; margin-bottom: 8px; font-size: 0.8rem; color: #888; text-transform: uppercase; font-weight: bold; }
    .modal-form input, .modal-form textarea, .modal-form select {
        width: 100%; background: #252525; border: 1px solid #444; border-radius: 10px; 
        padding: 12px; color: #fff; margin-bottom: 15px; font-family: inherit;
    }
    .btn-submit { background: var(--turquesa); color: #000; border: none; padding: 15px; border-radius: 10px; font-weight: bold; width: 100%; cursor: pointer; }
</style>

<script>
    function openModal(id) { document.getElementById(id).style.display = 'flex'; }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    function closeModalOutside(e, id) { if(e.target.id === id) closeModal(id); }
    function toggleLinkField(val) {
        document.getElementById('wrapper-link-cita').style.display = (val === 'online') ? 'block' : 'none';
    }
</script>