<?php
// detalle_finanzas.php - CORREGIDO (Nombres de columna y Estilo coherente)
if (!isset($paciente)) exit;

$saldo = $paciente['saldo_pendiente'] ?? 0;
$status_color = ($saldo > 0) ? '#ff4d4d' : 'var(--turquesa)';
?>
<div class="finanzas-container">
    <div class="balance-card" style="border-left: 5px solid <?php echo $status_color; ?>; background: #252525; padding: 25px; border-radius: 15px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div class="balance-info">
            <span style="font-size: 0.8rem; color: #888; text-transform: uppercase; letter-spacing: 1px;">Saldo Pendiente Actual</span>
            <h2 style="color: <?php echo $status_color; ?>; margin: 5px 0 0; font-size: 2.2rem; font-weight: 800;">$<?php echo number_format($saldo, 2); ?></h2>
        </div>
        <button onclick="openModal('modal-pago')" class="tab-btn active" style="padding:12px 25px; width:auto; flex-direction:row; cursor:pointer; gap:10px; border:none; border-radius:10px; background:var(--turquesa); color:#000; font-weight:bold;">
            <i class="fas fa-hand-holding-usd"></i> Registrar Pago
        </button>
    </div>

    <div class="section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h3 style="margin:0;"><i class="fas fa-history" style="color:var(--turquesa);"></i> Historial de Pagos</h3>
    </div>

    <div class="table-responsive">
        <table class="admin-table" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr style="text-align: left; border-bottom: 1px solid #333;">
                    <th style="padding:15px; color:var(--turquesa); font-size:0.8rem; text-transform:uppercase;">Fecha</th>
                    <th style="padding:15px; color:var(--turquesa); font-size:0.8rem; text-transform:uppercase;">Concepto</th>
                    <th style="padding:15px; color:var(--turquesa); font-size:0.8rem; text-transform:uppercase; text-align:right;">Monto</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // CONSULTA CORREGIDA: Usamos 'fecha' que es el nombre real en sesiones_pagos
                try {
                    $stmt_p = $pdo->prepare("SELECT fecha, monto FROM sesiones_pagos WHERE paciente_id = ? ORDER BY fecha DESC");
                    $stmt_p->execute([$paciente['id']]);
                    $pagos = $stmt_p->fetchAll();
                } catch (Exception $e) {
                    // Fallback en caso de que la tabla sea distinta (usando id como orden)
                    $stmt_p = $pdo->prepare("SELECT * FROM sesiones_pagos WHERE paciente_id = ? ORDER BY id DESC");
                    $stmt_p->execute([$paciente['id']]);
                    $pagos = $stmt_p->fetchAll();
                }

                if (empty($pagos)): ?>
                    <tr><td colspan="3" style="text-align:center; padding:50px; color:#555; background:rgba(255,255,255,0.01); border-radius:15px;">
                        <i class="fas fa-receipt" style="font-size:2rem; margin-bottom:10px; display:block;"></i>
                        No se han registrado abonos para este paciente.
                    </td></tr>
                <?php else: 
                    foreach ($pagos as $p): 
                        // Verificamos si la columna es 'fecha' o 'fecha_pago' para evitar errores al mostrar
                        $fecha_mostrar = $p['fecha'] ?? $p['fecha_pago'] ?? date('Y-m-d');
                    ?>
                    <tr style="border-bottom: 1px solid #222;">
                        <td style="padding:15px;"><strong><?php echo date('d/m/Y', strtotime($fecha_mostrar)); ?></strong></td>
                        <td style="padding:15px; color:#888;">Abono a cuenta / Pago realizado</td>
                        <td style="padding:15px; text-align:right; color: var(--turquesa); font-weight:bold;">$<?php echo number_format($p['monto'], 2); ?></td>
                    </tr>
                <?php endforeach; 
                endif; ?>
            </tbody>
        </table>
    </div>
</div>