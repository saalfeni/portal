<?php
if (!isset($paciente)) exit;

// 1. Consulta corregida: Usamos la estructura real de tu DB
$stmt = $pdo->prepare("SELECT * FROM paciente_actividades WHERE paciente_id = ? ORDER BY fecha_asignacion DESC");
$stmt->execute([$paciente['id']]);
$tareas = $stmt->fetchAll();

$totales = count($tareas);
$cumplidas = count(array_filter($tareas, function($t) { return isset($t['completado']) && $t['completado'] == 1; }));
?>

<div class="tareas-header-row" style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:25px; border-bottom: 1px solid #333; padding-bottom: 15px;">
    <div>
        <h3 style="margin:0; font-size: 1.2rem;"><i class="fas fa-tasks" style="color:var(--turquesa);"></i> Plan de Actividades</h3>
        <span style="font-size: 0.85rem; color:#666;"><?php echo "$cumplidas de $totales tareas finalizadas"; ?></span>
    </div>
    <button onclick="openModal('modal-tarea')" class="tab-btn active" style="padding:10px 20px; width:auto; flex-direction:row; cursor:pointer; gap:8px; border:none; border-radius:8px; background:var(--turquesa); color:#000; font-weight:bold;">
        <i class="fas fa-plus-circle"></i> Asignar Tarea
    </button>
</div>

<?php if (empty($tareas)): ?>
    <div style="text-align:center; padding:60px; background:rgba(255,255,255,0.01); border-radius:20px; border:1px dashed #2a2a2a;">
        <i class="fas fa-clipboard-check" style="font-size:3rem; color:#222; margin-bottom:15px;"></i>
        <p style="color:#555;">No hay tareas en el historial de este expediente.</p>
    </div>
<?php else: ?>
    <div class="tareas-grid">
        <?php foreach ($tareas as $t): 
            // Validamos los campos para evitar Warnings
            $titulo_tarea = $t['actividad'] ?? 'Tarea sin título';
            $desc_tarea = $t['descripcion'] ?? '';
            $fecha_t = $t['fecha_asignacion'] ?? date('Y-m-d');
            $esta_completada = ($t['completado'] == 1);
        ?>
        <div class="tarea-card" style="background:#252525; padding:18px; border-radius:15px; margin-bottom:12px; border-left:4px solid <?php echo $esta_completada ? 'var(--turquesa)' : '#f1c40f'; ?>; display:flex; justify-content:space-between; align-items:center;">
            <div style="flex:1;">
                <strong style="display:block; color:<?php echo $esta_completada ? 'var(--turquesa)' : '#fff'; ?>; font-size:1.05rem; margin-bottom:4px;">
                    <?php echo htmlspecialchars($titulo_tarea); ?>
                </strong>
                <?php if(!empty($desc_tarea)): ?>
                    <p style="color:#777; margin:0; font-size:0.85rem; line-height:1.4;"><?php echo htmlspecialchars($desc_tarea); ?></p>
                <?php endif; ?>
            </div>
            <div style="text-align:right; min-width:100px; margin-left:15px;">
                <span style="font-size:0.7rem; color:#444; display:block; margin-bottom:5px;"><?php echo date('d/m/Y', strtotime($fecha_t)); ?></span>
                <?php if($esta_completada): ?>
                    <span style="background:rgba(64, 224, 208, 0.1); color:var(--turquesa); padding:4px 8px; border-radius:6px; font-size:0.7rem; font-weight:bold;">LOGRADA</span>
                <?php else: ?>
                    <span style="background:rgba(241, 196, 15, 0.1); color:#f1c40f; padding:4px 8px; border-radius:6px; font-size:0.7rem; font-weight:bold;">PENDIENTE</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>