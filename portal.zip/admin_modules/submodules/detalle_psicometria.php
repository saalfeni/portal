<?php
// admin_modules/submodules/detalle_psicometria.php
if (!isset($paciente)) exit;

$tests = [
    [
        'id' => 'mmpi', 
        'nom' => 'MMPI-2', 
        'total' => 567, 
        'col' => 'test_mmpi_activo', // Coincide con tu SQL
        'resp' => 'mmpi2_respuestas',
        'ruta' => 'tests/mmpi-2/interpretar.php'
    ],
    [
        'id' => 'bdi', 
        'nom' => 'BDI-II (Depresión)', 
        'total' => 21, 
        'col' => 'test_bdi_activo', // Coincide con tu SQL
        'resp' => 'bdi2_respuestas',
        'ruta' => 'tests/bdi-2/interpretar_bdi.php'
    ],
    [
        'id' => 'bai', 
        'nom' => 'BAI (Ansiedad)', 
        'total' => 21, 
        'col' => 'test_bai_activo', // Coincide con tu SQL
        'resp' => 'bai_respuestas',
        'ruta' => 'tests/bai/interpretar_bai.php'
    ],
	[
    'id' => 'tdah', 
    'nom' => 'TDAH (Schulz)', 
    'total' => 18, 
    'col' => 'test_tdah_activo', 
    'resp' => 'tdah_respuestas',
    'ruta' => 'tests/tdah/interpretar_tdah.php'
	],
];
?>
<div class="psicometria-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px;">
    <?php foreach($tests as $t): 
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$t['resp']} WHERE paciente_id = ?");
        $stmt->execute([$paciente['id']]);
        $respondidas = $stmt->fetchColumn() ?: 0;
        $pct = round(($respondidas / $t['total']) * 100);
        $pct = ($pct > 100) ? 100 : $pct;
    ?>
    <div class="test-card" style="background:#1a1a1a; padding:20px; border-radius:15px; border:1px solid #333;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:15px;">
            <h4 style="margin:0; color:#fff;"><?php echo $t['nom']; ?></h4>
            <label class="switch-container">
                <input type="checkbox" <?php echo ($paciente[$t['col']] == 1) ? 'checked' : ''; ?> 
                       onchange="toggleTest(<?php echo $paciente['id']; ?>, '<?php echo $t['id']; ?>', this.checked)">
                <span class="slider"></span>
            </label>
        </div>
        
        <div style="font-size:0.8rem; color:#888; margin-bottom:5px;">Progreso: <?php echo $respondidas; ?> de <?php echo $t['total']; ?></div>
        <div class="progress-bar" style="height:8px; background:#111; border-radius:4px; overflow:hidden; margin-bottom:15px;">
            <div style="width:<?php echo $pct; ?>%; height:100%; background:var(--turquesa);"></div>
        </div>

        <?php if($pct >= 100): ?>
            <a href="<?php echo $t['ruta']; ?>?id=<?php echo $paciente['id']; ?>" target="_blank" style="display:block; text-align:center; background:var(--turquesa); color:#000; text-decoration:none; padding:10px; border-radius:8px; font-weight:bold; font-size:0.85rem;">VER RESULTADOS</a>
        <?php else: ?>
            <div style="text-align:center; font-size:0.75rem; color:#555; padding:10px; border:1px dashed #333; border-radius:8px;">
                <?php echo ($paciente[$t['col']] == 1) ? 'Habilitado para el paciente' : 'Acceso deshabilitado'; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>