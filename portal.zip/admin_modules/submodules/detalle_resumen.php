<?php
// detalle_resumen.php - Ficha Clínica con Agenda Integrada
if (!isset($paciente)) exit;
?>
<div class="resumen-clinico">
    <div class="card-info-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px;">
        
        <div class="info-block" style="background: #1a1a1a; padding: 15px; border-radius: 12px; border: 1px solid var(--turquesa);">
            <label style="color: var(--turquesa); font-size: 0.75rem; text-transform: uppercase; font-weight: bold; display: block; margin-bottom: 10px;">
                <i class="fas fa-calendar-check"></i> Próxima Cita Programada
            </label>
            
            <?php if(!empty($paciente['proxima_cita'])): ?>
                <p style="margin: 5px 0; font-size: 1.1rem; color: #fff; font-weight: bold;">
                    <?php echo date('d/m/Y - H:i', strtotime($paciente['proxima_cita'])); ?> hs
                </p>
                <p style="margin: 5px 0; font-size: 0.85rem; color: #bbb;">
                    <strong>Modalidad:</strong> <?php echo (isset($paciente['modalidad_cita']) && $paciente['modalidad_cita'] == 'online') ? 'En Línea' : 'Presencial'; ?>
                </p>
                <?php if(!empty($paciente['link_cita'])): ?>
                    <a href="<?php echo htmlspecialchars($paciente['link_cita']); ?>" target="_blank" style="color:var(--turquesa); font-size:0.8rem; text-decoration:none; display:inline-block; margin-top:5px;">
                        <i class="fas fa-video"></i> Abrir enlace de sesión
                    </a>
                <?php endif; ?>
            <?php else: ?>
                <p style="color:#666; font-size:0.9rem; margin: 10px 0;">Sin cita agendada.</p>
            <?php endif; ?>

            <button onclick="openModal('modal-sesion')" style="margin-top:10px; width:100%; background:var(--turquesa); color:#000; border:none; padding:10px; border-radius:8px; cursor:pointer; font-size:0.8rem; font-weight:bold; transition: 0.3s; text-transform: uppercase;">
                <i class="fas fa-plus-circle"></i> Agendar / Nueva Nota
            </button>
        </div>

        <div class="info-block" style="background: #252525; padding: 15px; border-radius: 12px; border: 1px solid #333;">
            <label style="color: var(--turquesa); font-size: 0.75rem; text-transform: uppercase; font-weight: bold; display: block; margin-bottom: 10px;">
                <i class="fas fa-user"></i> Datos Generales
            </label>
            <p style="margin: 5px 0; font-size: 0.9rem;"><strong>Edad:</strong> <?php echo $paciente['edad'] ?? '--'; ?> años</p>
            <p style="margin: 5px 0; font-size: 0.9rem;"><strong>Ocupación:</strong> <?php echo htmlspecialchars($paciente['ocupacion'] ?? 'No especificada'); ?></p>
            <p style="margin: 5px 0; font-size: 0.9rem;"><strong>Teléfono:</strong> <?php echo htmlspecialchars($paciente['telefono'] ?? 'N/A'); ?></p>
        </div>
        
        <div class="info-block" style="background: #252525; padding: 15px; border-radius: 12px; border: 1px solid #333;">
            <label style="color: var(--turquesa); font-size: 0.75rem; text-transform: uppercase; font-weight: bold; display: block; margin-bottom: 10px;">
                <i class="fas fa-envelope"></i> Contacto y Registro
            </label>
            <p style="margin: 5px 0; font-size: 0.9rem;"><strong>Email:</strong> <?php echo htmlspecialchars($paciente['email']); ?></p>
            <p style="margin: 5px 0; font-size: 0.9rem;"><strong>Registro:</strong> <?php echo date('d/m/Y', strtotime($paciente['fecha_registro'])); ?></p>
        </div>
    </div>
    
    <div class="motivo-consulta-box" style="background: #252525; padding: 20px; border-radius: 12px; border: 1px solid #333;">
        <label style="color: var(--turquesa); font-size: 0.75rem; font-weight: bold; text-transform: uppercase; display: block; margin-bottom: 10px;">Motivo de Consulta</label>
        <p style="margin: 0; font-size: 0.95rem; line-height: 1.6; color: #eee;"><?php echo nl2br(htmlspecialchars($paciente['motivo_consulta'] ?? 'No registrado.')); ?></p>
    </div>
</div>