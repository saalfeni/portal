<?php
if (!isset($paciente)) exit;

$stmt_s = $pdo->prepare("SELECT * FROM sesiones WHERE paciente_id = ? ORDER BY fecha_sesion DESC");
$stmt_s->execute([$paciente['id']]);
$sesiones = $stmt_s->fetchAll();
?>
<div class="section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h3 style="margin:0;"><i class="fas fa-file-medical"></i> Notas de Evolución</h3>
    <button onclick="openModal('modal-sesion')" class="tab-btn active" style="padding:10px 20px; width:auto; flex-direction:row; cursor:pointer;">
        <i class="fas fa-pen-nib" style="margin-right:8px;"></i> Registrar Sesión
    </button>
</div>

<?php if (empty($sesiones)): ?>
    <div style="text-align:center; padding:60px; background:rgba(255,255,255,0.01); border-radius:20px; border:1px dashed #2a2a2a;">
        <i class="fas fa-book-open" style="font-size:3.5rem; color:#222; margin-bottom:20px;"></i>
        <h4 style="color:#444; margin:0;">Sin historial clínico</h4>
        <p style="color:#666; font-size:0.9rem;">Este expediente aún no cuenta con notas de evolución registradas.</p>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Resumen de Sesión</th>
                    <th style="text-align:center;">Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sesiones as $s): ?>
                <tr>
                    <td style="width:120px;"><strong><?php echo date('d/m/Y', strtotime($s['fecha_sesion'])); ?></strong></td>
                    <td style="color:#999; font-size:0.85rem; line-height:1.4;">
                        <?php echo !empty($s['notas_subjetivas']) ? substr(strip_tags($s['notas_subjetivas']), 0, 150) . '...' : '<i>Sin descripción detallada</i>'; ?>
                    </td>
                    <td style="text-align:center; width:80px;">
                        <a href="admin_ver_sesion.php?id=<?php echo $s['id']; ?>" class="btn-icon" style="color:var(--turquesa); font-size:1.2rem;"><i class="fas fa-external-link-square-alt"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>