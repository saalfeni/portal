<?php
// admin_modules/admin_lista_sesiones.php - Versión Corregida y Optimizada
if (!isset($pdo)) exit;

// Corregimos p.foto por p.foto_perfil para evitar el Fatal Error
$stmt = $pdo->query("SELECT s.*, p.nombre_completo, p.foto_perfil, p.email 
                    FROM sesiones s 
                    JOIN pacientes p ON s.paciente_id = p.id 
                    ORDER BY s.fecha_sesion DESC");
$sesiones = $stmt->fetchAll();
?>

<style>
    .module-container { 
        background: var(--card); 
        padding: 25px; 
        border-radius: 20px; 
        border: 1px solid #222; 
        animation: fadeIn 0.5s ease;
    }

    /* VISTA ESCRITORIO */
    .desktop-table-sesiones { width: 100%; border-collapse: collapse; margin-top: 20px; display: table; }
    .desktop-table-sesiones th { padding: 12px; text-align: left; color: var(--turquesa); font-size: 0.8rem; text-transform: uppercase; border-bottom: 1px solid #333; }
    .desktop-table-sesiones td { padding: 12px; border-bottom: 1px solid #222; }

    /* VISTA MÓVIL (Cards) */
    .mobile-sesiones-cards { display: none; flex-direction: column; gap: 15px; margin-top: 20px; }
    .sesion-card { 
        background: #151515; 
        border-radius: 15px; 
        padding: 15px; 
        border: 1px solid #333; 
    }
    .sesion-card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
    .sesion-date-badge { background: var(--turquesa); color: #000; padding: 2px 8px; border-radius: 5px; font-size: 0.75rem; font-weight: bold; }
    .sesion-paciente-nom { display: block; color: #fff; font-weight: 600; margin-top: 5px; }
    .sesion-nota-preview { font-size: 0.85rem; color: #888; line-height: 1.4; background: #0c0c0c; padding: 10px; border-radius: 8px; margin: 10px 0; border-left: 3px solid #333; }

    @media (max-width: 768px) {
        .desktop-table-sesiones { display: none; }
        .mobile-sesiones-cards { display: flex; }
        .module-container { padding: 15px; }
    }
</style>

<div class="module-container">
    <h3 style="margin-top:0;">
        <i class="fas fa-calendar-check" style="color:var(--turquesa); margin-right:10px;"></i> 
        Historial Global de Sesiones
    </h3>

    <div class="table-responsive">
        <table class="desktop-table-sesiones">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Paciente</th>
                    <th>Resumen</th>
                    <th style="text-align:center;">Ver</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($sesiones as $s): 
                    $nota_texto = $s['notas'] ?? ''; 
                ?>
                <tr>
                    <td style="white-space:nowrap;"><strong><?php echo date('d/m/Y', strtotime($s['fecha_sesion'])); ?></strong></td>
                    <td><?php echo htmlspecialchars($s['nombre_completo']); ?></td>
                    <td style="color:#777; font-size:0.85rem;">
                        <?php echo !empty($nota_texto) ? substr(strip_tags($nota_texto), 0, 80) . '...' : '<i>Sin notas</i>'; ?>
                    </td>
                    <td style="text-align:center;">
                        <a href="?view=detalle&id=<?php echo $s['paciente_id']; ?>" style="color:var(--turquesa);"><i class="fas fa-folder-open"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="mobile-sesiones-cards">
        <?php foreach($sesiones as $s): 
            $nota_texto = $s['notas'] ?? '';
        ?>
        <div class="sesion-card">
            <div class="sesion-card-header">
                <div>
                    <span class="sesion-date-badge"><?php echo date('d/m/Y', strtotime($s['fecha_sesion'])); ?></span>
                    <span class="sesion-paciente-nom"><?php echo htmlspecialchars($s['nombre_completo']); ?></span>
                </div>
                <a href="?view=detalle&id=<?php echo $s['paciente_id']; ?>" 
                   style="background:rgba(64, 224, 208, 0.1); color:var(--turquesa); width:35px; height:35px; display:flex; align-items:center; justify-content:center; border-radius:8px; text-decoration:none;">
                    <i class="fas fa-folder-open"></i>
                </a>
            </div>
            
            <div class="sesion-nota-preview">
                <?php echo !empty($nota_texto) ? substr(strip_tags($nota_texto), 0, 120) . '...' : '<i>Sin notas</i>'; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>