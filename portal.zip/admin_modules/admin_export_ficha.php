<?php
// admin_export_ficha.php - Vista de Ficha Completa optimizada para impresión/PDF

session_start();
require 'db_connect.php'; 
require 'config_admin.php';

// 1. AUTENTICACIÓN
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    die("Acceso denegado.");
}

$pacienteId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$pacienteId) {
    die("Error: ID de paciente no especificado.");
}

// 2. RECUPERACIÓN DE DATOS (REUTILIZANDO LÓGICA DE admin_detalle.php)
try {
    // Obtener datos del paciente
    $stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = :id");
    $stmt->bindValue(':id', $pacienteId, PDO::PARAM_INT);
    $stmt->execute();
    $paciente = $stmt->fetch();

    if (!$paciente) {
        die("Error: Paciente no encontrado.");
    }
    
    // Decodificar los campos JSON
    $datos_contacto = json_decode($paciente['datos_contacto'], true);
    $motivo_consulta = json_decode($paciente['motivo_consulta'], true);
    $historial_relacional = json_decode($paciente['historial_relacional'], true);
    $historial_sustancias = json_decode($paciente['historial_sustancias'], true);
    $antecedentes_clinicos = json_decode($paciente['antecedentes_clinicos'], true);

    // Obtener historial de sesiones
    $stmtSesiones = $pdo->prepare("SELECT * FROM sesiones WHERE paciente_id = :id ORDER BY fecha_sesion ASC"); // Orden ASC para verlo cronológicamente
    $stmtSesiones->bindValue(':id', $pacienteId, PDO::PARAM_INT);
    $stmtSesiones->execute();
    $sesiones = $stmtSesiones->fetchAll();
    
} catch (\PDOException $e) {
    die("Error de Base de Datos: " . $e->getMessage());
}

// 3. FUNCIONES DE FORMATO (reutilizadas de admin_detalle.php)
function formatEstadoCivil($data) {
    $ec = $data['estado_civil'] ?? 'N/A';
    $output = "<strong>{$ec}</strong>";
    if ($ec === 'Casado' || $ec === 'Union Libre') {
        $output .= ": con " . htmlspecialchars($data['nombre_vinculo'] ?? 'N/A') . " por " . htmlspecialchars($data['relacion_tiempo_duracion'] ?? 'N/A');
    } elseif ($ec === 'Divorciado' || $ec === 'Viudo') {
         $output .= ". Separación/Pérdida hace " . htmlspecialchars($data['separacion_tiempo'] ?? 'N/A') . ". Causa: " . htmlspecialchars($data['separacion_causas'] ?? 'N/A');
    }
    return $output;
}
$fechaNac = new DateTime($paciente['fecha_nacimiento']);
$hoy = new DateTime();
$edad = $hoy->diff($fechaNac)->y;
$fecha_hoy = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FICHA CLÍNICA - <?php echo htmlspecialchars($paciente['nombre_completo']); ?></title>
    <style>
        body { font-family: 'Times New Roman', serif; font-size: 11pt; margin: 0; padding: 0; color: #000; background: #fff; }
        .document-container { padding: 40px; max-width: 800px; margin: 0 auto; }
        header { border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
        h1 { font-size: 16pt; color: #19aca9; text-align: center; margin: 0; }
        h2 { font-size: 14pt; color: #19aca9; margin-top: 25px; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
        h3 { font-size: 12pt; color: #333; margin-top: 15px; }
        
        .patient-info, .section-content { margin-bottom: 20px; }
        .patient-info p { margin: 5px 0; }
        .patient-info strong { color: #000; display: inline-block; width: 150px; }
        
        .data-list { list-style: none; padding: 0; margin: 10px 0; }
        .data-list li { margin-bottom: 5px; }
        .data-list strong { color: #000; }

        /* Estilos de Sesiones (Timeline) */
        .timeline-item { border-left: 3px solid #19aca9; padding-left: 15px; margin-top: 15px; }
        .timeline-item p { margin: 5px 0; }
        .timeline-item strong { display: block; margin-top: 10px; }
        .session-footer { font-size: 0.9em; margin-top: 10px; color: #555; }
        
        /* Estilos específicos para el reporte */
        .report-header { text-align: right; font-size: 10pt; color: #555; margin-bottom: 10px; }
        
        /* Ocultar botones e interfaz en la vista de impresión */
        @media print {
            .no-print { display: none !important; }
            .document-container { padding: 0; max-width: 100%; }
        }
    </style>
</head>
<body>

<div class="document-container">
    <div class="report-header no-print">
        <button onclick="window.print()" class="no-print" style="background: #19aca9; color: white; padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer;">🖨️ Imprimir / Guardar como PDF</button>
        <a href="admin_detalle.php?id=<?php echo $pacienteId; ?>" class="no-print" style="margin-left: 10px; color: #333;">← Volver</a>
    </div>

    <header>
        <h1 style="color: #19aca9;">FICHA CLÍNICA DEL PACIENTE</h1>
        <p style="text-align: center; font-size: 10pt;">Generado el: <?php echo $fecha_hoy; ?></p>
    </header>

    <h2>I. Datos Generales</h2>
    <div class="patient-info">
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($paciente['nombre_completo']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($paciente['email']); ?></p>
        <p><strong>F. Nacimiento:</strong> <?php echo date("d/m/Y", strtotime($paciente['fecha_nacimiento'])); ?></p>
        <p><strong>Edad:</strong> <?php echo $edad; ?> años</p>
        <p><strong>Ocupación:</strong> <?php echo htmlspecialchars($paciente['ocupacion']); ?></p>
        <p><strong>Grado Estudios:</strong> <?php echo htmlspecialchars($paciente['ultimo_grado_estudios']); ?></p>
        <p><strong>Contacto Emergencia:</strong> <?php echo htmlspecialchars($datos_contacto['telefono_emergencia'] ?? 'N/A') . ' (' . htmlspecialchars($datos_contacto['relacion_emergencia'] ?? 'N/A') . ')'; ?></p>
    </div>

    <h2>II. Motivo de Consulta</h2>
    <div class="section-content">
        <p><strong>Motivo Explícito:</strong></p>
        <p style="background: #f0f0f0; padding: 10px; border-radius: 5px; white-space: pre-wrap;"><?php echo nl2br(htmlspecialchars($motivo_consulta['motivo_explicito'] ?? 'N/A')); ?></p>
        <p><strong>Tiempo del Problema:</strong> <?php echo htmlspecialchars($motivo_consulta['tiempo_problema'] ?? 'N/A'); ?></p>
        <p><strong>Expectativas:</strong> <?php echo nl2br(htmlspecialchars($motivo_consulta['expectativas'] ?? 'N/A')); ?></p>
    </div>

    <h2>III. Historial Familiar y Relacional</h2>
    <div class="section-content">
        <p><strong>Estado Civil:</strong> <?php echo formatEstadoCivil($historial_relacional); ?></p>
        <p><strong>Hijos:</strong> <?php echo htmlspecialchars($historial_relacional['tiene_hijos'] ?? 'No'); ?></p>
        <?php if (($historial_relacional['tiene_hijos'] ?? 'No') === 'Sí'): ?>
            <p><strong>Detalle Hijos:</strong> <?php echo nl2br(htmlspecialchars($historial_relacional['hijos_detalle'] ?? 'N/A')); ?></p>
        <?php endif; ?>
        <p><strong>Relación Origen:</strong> <?php echo htmlspecialchars($historial_relacional['relacion_origen'] ?? 'N/A'); ?></p>
    </div>

    <h2>IV. Antecedentes Clínicos y Sustancias</h2>
    <div class="section-content">
        <h3>Antecedentes Médicos y Psicológicos</h3>
        <ul class="data-list">
            <li><strong>Terapia Previa:</strong> <?php echo htmlspecialchars($antecedentes_clinicos['terapia_previa_bool'] ?? 'No'); ?> (Detalle: <?php echo htmlspecialchars($antecedentes_clinicos['terapia_causas'] ?? 'N/A'); ?>)</li>
            <li><strong>Ant. Psiquiátricos:</strong> <?php echo htmlspecialchars($antecedentes_clinicos['ant_psiquiatricos'] ?? 'N/A'); ?></li>
            <li><strong>Medicación:</strong> <?php echo htmlspecialchars($antecedentes_clinicos['medicacion_psiquiatrica'] ?? 'N/A'); ?></li>
            <li><strong>Enf. Crónicas:</strong> <?php echo htmlspecialchars($antecedentes_clinicos['enfermedades_cronicas'] ?? 'N/A'); ?></li>
            <li><strong>Sueño/Soporte:</strong> <?php echo htmlspecialchars($antecedentes_clinicos['calidad_sueno'] ?? 'N/A'); ?> / <?php echo htmlspecialchars($antecedentes_clinicos['soporte_social'] ?? 'N/A'); ?></li>
        </ul>
        <h3>Uso de Sustancias</h3>
        <ul class="data-list">
            <li><strong>Fuma:</strong> <?php echo htmlspecialchars($historial_sustancias['fuma'] ?? 'No'); ?> | <strong>Alcohol:</strong> <?php echo htmlspecialchars($historial_sustancias['alcohol'] ?? 'No'); ?></li>
            <li><strong>Drogas:</strong> <?php echo htmlspecialchars($historial_sustancias['drogas_uso'] ?? 'No'); ?> (Tipo: <?php echo htmlspecialchars($historial_sustancias['drogas_tipo'] ?? 'N/A'); ?>)</li>
        </ul>
    </div>

    <?php if (!empty($sesiones)): ?>
        <h2>V. Historial de Sesiones</h2>
        <div class="section-content">
            <?php foreach ($sesiones as $s): ?>
                <div class="timeline-item">
                    <h3 style="margin-top: 0;">Sesión #<?php echo $s['num_sesion']; ?> (<?php echo date("d/M/Y H:i", strtotime($s['fecha_sesion'])); ?>)</h3>
                    <strong>Notas de Sesión:</strong> <p style="white-space: pre-wrap;"><?php echo nl2br(htmlspecialchars($s['notas_sesion'])); ?></p>
                    <p><strong>Tareas:</strong> <?php echo nl2br(htmlspecialchars($s['tareas'] ?? 'N/A')); ?></p>
                    <p><strong>Tests:</strong> <?php echo htmlspecialchars($s['tests_aplicados'] ?? 'N/A'); ?></p>
                    <div class="session-footer">Próxima Cita: <?php echo $s['fecha_proxima_sesion'] ? date("d/M/Y H:i", strtotime($s['fecha_proxima_sesion'])) : 'Sin agendar'; ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <div style="margin-top: 50px; text-align: center; font-size: 10pt; color: #555;">
        <p>_________________________</p>
        <p>Firma del Terapeuta</p>
    </div>

</div>

</body>
</html>