<?php
// admin_modules/admin_lista_pacientes.php - Versión Optimizada para Móviles (Cards) y Escritorio (Tabla)
if (!isset($pdo)) exit;

// Consulta para obtener pacientes y un conteo rápido de sus sesiones
$stmt = $pdo->query("SELECT p.*, 
                    (SELECT COUNT(*) FROM sesiones WHERE paciente_id = p.id) as total_sesiones 
                    FROM pacientes p ORDER BY p.nombre_completo ASC");
$pacientes = $stmt->fetchAll();
?>

<style>
    /* Contenedor de la lista */
    .pacientes-container { animation: fadeIn 0.5s ease; }

    /* Estilos de Tabla (Escritorio) */
    .desktop-table { width: 100%; border-collapse: collapse; display: table; }
    .table-wrapper { background: var(--card); border-radius: 15px; border: 1px solid #222; overflow: hidden; }
    
    /* Estilos de Cards (Móvil) */
    .mobile-cards { display: none; flex-direction: column; gap: 15px; }
    .paciente-card { 
        background: var(--card); 
        border-radius: 15px; 
        padding: 15px; 
        border: 1px solid #222; 
        display: flex; 
        flex-direction: column; 
        gap: 12px;
    }

    /* Utilidades visuales */
    .status-badge { background: #000; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; border: 1px solid #333; color: #aaa; }
    .action-btn { 
        width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; border-radius: 8px; text-decoration: none; font-size: 1rem;
    }

    /* RESPONSIVE LOGIC */
    @media (max-width: 768px) {
        .desktop-table { display: none; } /* Ocultar tabla en móvil */
        .mobile-cards { display: flex; } /* Mostrar tarjetas en móvil */
        .pacientes-header { flex-direction: column; align-items: flex-start !important; gap: 15px; }
        .pacientes-header button { width: 100%; }
    }
</style>

<div class="pacientes-container">
    <div class="pacientes-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
        <h3 style="margin: 0; color: var(--turquesa);"><i class="fas fa-users"></i> Directorio de Pacientes</h3>
        <button onclick="window.location.href='?view=nuevo_paciente'" style="background: var(--turquesa); color: #000; border: none; padding: 12px 20px; border-radius: 8px; font-weight: bold; cursor: pointer;">
            <i class="fas fa-plus"></i> Nuevo Registro
        </button>
    </div>

    <div class="table-wrapper desktop-table">
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background: #151515; text-align: left; font-size: 0.75rem; color: var(--turquesa); text-transform: uppercase;">
                    <th style="padding: 15px;">Paciente</th>
                    <th style="padding: 15px;">Contacto</th>
                    <th style="padding: 15px; text-align: center;">Sesiones</th>
                    <th style="padding: 15px; text-align: right;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pacientes as $p): 
                    $p_email = trim($p['email'] ?? 'paciente@ejemplo.com');
                    $p_hash = md5(strtolower($p_email));
                    $p_foto = (!empty($p['foto']) && file_exists($p['foto'])) ? $p['foto'] : "https://www.gravatar.com/avatar/$p_hash?s=100&d=mp";
                ?>
                <tr style="border-bottom: 1px solid #222;">
                    <td style="padding: 15px;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <img src="<?php echo $p_foto; ?>" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 1px solid #444;">
                            <div>
                                <strong style="display: block; color: #fff;"><?php echo htmlspecialchars($p['nombre_completo']); ?></strong>
                                <small style="color: #666;">ID: #<?php echo str_pad($p['id'], 4, "0", STR_PAD_LEFT); ?></small>
                            </div>
                        </div>
                    </td>
                    <td style="padding: 15px;">
                        <div style="font-size: 0.85rem; color: #aaa;">
                            <i class="fas fa-phone" style="width: 15px; font-size: 0.7rem;"></i> <?php echo $p['telefono'] ?? '---'; ?><br>
                            <i class="fas fa-envelope" style="width: 15px; font-size: 0.7rem;"></i> <?php echo $p['email'] ?? '---'; ?>
                        </div>
                    </td>
                    <td style="padding: 15px; text-align: center;">
                        <span class="status-badge"><?php echo $p['total_sesiones']; ?> atendidas</span>
                    </td>
                    <td style="padding: 15px; text-align: right;">
                        <div style="display: flex; justify-content: flex-end; gap: 8px;">
                            <a href="?view=detalle&id=<?php echo $p['id']; ?>" class="action-btn" style="color: var(--turquesa); background: rgba(64, 224, 208, 0.1);" title="Expediente"><i class="fas fa-folder-open"></i></a>
                            <a href="?view=contabilidad&paciente_id=<?php echo $p['id']; ?>" class="action-btn" style="color: #f1c40f; background: rgba(241, 196, 15, 0.1);" title="Pagos"><i class="fas fa-dollar-sign"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="mobile-cards">
        <?php foreach ($pacientes as $p): 
            $p_email = trim($p['email'] ?? 'paciente@ejemplo.com');
            $p_hash = md5(strtolower($p_email));
            $p_foto = (!empty($p['foto']) && file_exists($p['foto'])) ? $p['foto'] : "https://www.gravatar.com/avatar/$p_hash?s=100&d=mp";
        ?>
        <div class="paciente-card">
            <div style="display: flex; align-items: center; gap: 15px;">
                <img src="<?php echo $p_foto; ?>" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; border: 2px solid var(--turquesa);">
                <div style="flex:1;">
                    <strong style="display: block; color: #fff; font-size: 1rem;"><?php echo htmlspecialchars($p['nombre_completo']); ?></strong>
                    <span style="color: var(--turquesa); font-size: 0.7rem; font-weight: bold; text-transform: uppercase;">ID #<?php echo str_pad($p['id'], 4, "0", STR_PAD_LEFT); ?></span>
                </div>
                <span class="status-badge"><?php echo $p['total_sesiones']; ?> ses.</span>
            </div>
            
            <div style="background: rgba(0,0,0,0.2); padding: 10px; border-radius: 8px; font-size: 0.85rem; color: #aaa;">
                <div style="margin-bottom: 5px;"><i class="fas fa-phone" style="color: var(--turquesa); margin-right: 8px;"></i> <?php echo $p['telefono'] ?? '---'; ?></div>
                <div><i class="fas fa-envelope" style="color: var(--turquesa); margin-right: 8px;"></i> <?php echo $p['email'] ?? '---'; ?></div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <a href="?view=detalle&id=<?php echo $p['id']; ?>" style="background: rgba(64, 224, 208, 0.1); color: var(--turquesa); text-decoration: none; padding: 12px; border-radius: 8px; text-align: center; font-weight: bold; border: 1px solid rgba(64, 224, 208, 0.3);">
                    <i class="fas fa-folder-open"></i> Expediente
                </a>
                <a href="?view=contabilidad&paciente_id=<?php echo $p['id']; ?>" style="background: rgba(241, 196, 15, 0.1); color: #f1c40f; text-decoration: none; padding: 12px; border-radius: 8px; text-align: center; font-weight: bold; border: 1px solid rgba(241, 196, 15, 0.3);">
                    <i class="fas fa-dollar-sign"></i> Pagos
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($pacientes)): ?>
        <div style="text-align: center; padding: 50px; color: #555;">
            <i class="fas fa-users-slash" style="font-size: 3rem; margin-bottom: 15px; display: block;"></i>
            No hay pacientes registrados.
        </div>
    <?php endif; ?>
</div>