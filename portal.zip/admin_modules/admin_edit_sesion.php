<?php
// admin_edit_sesion.php - Formulario para editar una sesión existente

//session_start();
require 'db_connect.php'; 

// 1. AUTENTICACIÓN
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

$sesionId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$mensaje_estado = "";

if (!$sesionId) {
    die("Error: ID de sesión no especificado.");
}

// 2. RECUPERAR DATOS INICIALES DE LA SESIÓN Y PACIENTE
try {
    // Obtener datos de la sesión y el paciente_id
    $stmtSesion = $pdo->prepare("SELECT * FROM sesiones WHERE id = ?");
    $stmtSesion->execute([$sesionId]);
    $sesion = $stmtSesion->fetch();
    
    if (!$sesion) {
        die("Sesión no encontrada.");
    }
    
    $pacienteId = $sesion['paciente_id'];
    
    // Obtener nombre del paciente
    $stmtPaciente = $pdo->prepare("SELECT nombre_completo FROM pacientes WHERE id = ?");
    $stmtPaciente->execute([$pacienteId]);
    $paciente = $stmtPaciente->fetch();

} catch (PDOException $e) {
    die("Error de BD al cargar datos: " . $e->getMessage());
}

// 3. PROCESAMIENTO DEL FORMULARIO DE ACTUALIZACIÓN (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $fecha_sesion = $_POST['fecha_sesion'] ?? $sesion['fecha_sesion'];
    $notas_sesion = $_POST['notas_sesion'] ?? '';
    $tareas = $_POST['tareas'] ?? '';
    $tests_aplicados = $_POST['tests_aplicados'] ?? '';
    $fecha_proxima_sesion = $_POST['fecha_proxima_sesion'] ?? null;
    $num_sesion = $_POST['num_sesion'] ?? $sesion['num_sesion'];

    try {
        $sql = "UPDATE sesiones SET 
                fecha_sesion = ?, 
                num_sesion = ?, 
                notas_sesion = ?, 
                tareas = ?, 
                tests_aplicados = ?, 
                fecha_proxima_sesion = ?
                WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        
        $stmt->execute([
            $fecha_sesion,
            $num_sesion,
            $notas_sesion,
            $tareas,
            $tests_aplicados,
            empty($fecha_proxima_sesion) ? null : $fecha_proxima_sesion,
            $sesionId
        ]);

        $mensaje_estado = "<div class='alerta exito'>✅ Sesión #{$num_sesion} actualizada correctamente.</div>";
        
        // Redirigir al detalle del paciente para ver el historial actualizado
        header("Refresh: 1; url=admin_detalle.php?id={$pacienteId}&tab=sesiones");
        
    } catch (PDOException $e) {
        $mensaje_estado = "<div class='alerta error'>❌ Error al actualizar la sesión: " . $e->getMessage() . "</div>";
    }
}

// 4. PREPARACIÓN DE VALORES PARA EL FORMULARIO
// Formatear la fecha para el campo input type="datetime-local"
$current_fecha_sesion = date('Y-m-d\TH:i', strtotime($sesion['fecha_sesion']));
$current_fecha_proxima = $sesion['fecha_proxima_sesion'] ? date('Y-m-d\TH:i', strtotime($sesion['fecha_proxima_sesion'])) : '';

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Sesión #<?php echo $sesion['num_sesion']; ?> | <?php echo htmlspecialchars($paciente['nombre_completo']); ?></title>
    <link rel="stylesheet" href="admin_styles.css?v=1.2">
</head>
<body>
    <div class="container">
        <a href="admin_dashboard.php" class="logo-container">
            <img src="assets/img/logo.png" alt="CMS-GP Logo" class="logo">
        </a>
        
        <header>
            <a href="admin_detalle.php?id=<?php echo $pacienteId; ?>&tab=sesiones" class="back-link">← Volver al Historial</a>
            <a href="admin_dashboard.php?logout=1" class="logout-btn">Cerrar Sesión</a>
        </header>

        <div class="patient-header" style="text-align: left;">
            <h1>🖍️ Editando Sesión #<?php echo $sesion['num_sesion']; ?></h1>
            <p>Paciente: <strong><?php echo htmlspecialchars($paciente['nombre_completo']); ?></strong> | ID Sesión: #<?php echo $sesionId; ?></p>
        </div>
        
        <?php echo $mensaje_estado; ?>

        <form method="POST">
            
            <div class="campo">
                <label for="num_sesion">Número de Sesión (Editable):</label>
                <input type="number" id="num_sesion" name="num_sesion" value="<?php echo htmlspecialchars($sesion['num_sesion']); ?>" required min="1">
            </div>

            <div class="campo">
                <label for="fecha_sesion">Fecha y Hora de la Sesión:</label>
                <input type="datetime-local" id="fecha_sesion" name="fecha_sesion" value="<?php echo $current_fecha_sesion; ?>" required>
            </div>
            
            <div class="campo">
                <label for="notas_sesion">Notas de la Sesión (Observaciones, Proceso, Hipótesis):</label>
                <textarea id="notas_sesion" name="notas_sesion" rows="10" required><?php echo htmlspecialchars($sesion['notas_sesion'] ?? ''); ?></textarea>
            </div>

            <div class="campo">
                <label for="tests_aplicados">Tests Aplicados (Separados por coma):</label>
                <input type="text" id="tests_aplicados" name="tests_aplicados" value="<?php echo htmlspecialchars($sesion['tests_aplicados'] ?? ''); ?>" placeholder="Ej: Raven, EDV-20, HTP">
            </div>

            <div class="campo">
                <label for="tareas">Tareas Asignadas al Paciente:</label>
                <textarea id="tareas" name="tareas" rows="4"><?php echo htmlspecialchars($sesion['tareas'] ?? ''); ?></textarea>
            </div>
            
            <div class="campo">
                <label for="fecha_proxima_sesion">Fecha y Hora de la Próxima Cita (Opcional):</label>
                <input type="datetime-local" id="fecha_proxima_sesion" name="fecha_proxima_sesion" value="<?php echo $current_fecha_proxima; ?>">
            </div>

            <button type="submit" class="submit-btn" style="background: #f39c12;">Guardar Cambios de Sesión</button>
        </form>

        <footer class="main-footer">
            <p>&copy; <?php echo date('Y'); ?> CMS-GP | Desarrollado por Alberto Félix. <a href="mailto:hello@albertofelix.click">hello@albertofelix.click</a></p>
            <img src="assets/img/logo.png" alt="CMS-GP Logo" class="footer-logo">
        </footer>
    </div>
    
    <style>
        /* Estilos complementarios para input/textarea (igual que admin_edit_paciente.php) */
        h1 { color: #f39c12; } /* Resaltar el título de edición */
        .submit-btn {
            /* Botón de guardar cambios usa el color de edición */
            background: #f39c12 !important; 
        }
        .submit-btn:hover { background: #d38f19 !important; }

        input[type="number"], input[type="text"], input[type="email"], input[type="date"], textarea, select, input[type="datetime-local"] {
            width: 100%; padding: 12px; border: 1px solid #444; border-radius: 6px;
            background: var(--section-bg, #3c4556); color: var(--text-main, #ffffff); box-sizing: border-box;
            transition: border-color 0.2s;
        }
        textarea { height: 150px; resize: vertical; } /* Más espacio para notas */
        
        .alerta.error { background: #f8d7da; color: #721c24; border-color: #f5c6cb; padding: 10px; border-radius: 4px; margin-top: 15px; }
        .alerta.exito { background: #d4edda; color: #155724; border-color: #c3e6cb; padding: 10px; border-radius: 4px; margin-top: 15px; }

    </style>
</body>
</html>