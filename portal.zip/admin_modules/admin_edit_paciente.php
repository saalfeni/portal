<?php
// admin_edit_paciente.php - Formulario para Editar Datos Iniciales del Paciente

//session_start();
require 'db_connect.php'; 
require 'config_admin.php';

// 1. AUTENTICACIÓN
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

$pacienteId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$mensaje_estado = "";

if (!$pacienteId) {
    die("Error: ID de paciente no especificado.");
}

// Función de sanitización básica (copiada de registro_paciente.php)
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// 2. RECUPERAR DATOS ACTUALES (GET) O ACTUALIZAR (POST)
try {
    // a. Obtener datos iniciales del paciente
    $stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = :id");
    $stmt->bindValue(':id', $pacienteId, PDO::PARAM_INT);
    $stmt->execute();
    $paciente = $stmt->fetch();

    if (!$paciente) {
        die("Error: Paciente no encontrado.");
    }

    // b. Decodificar los campos JSON para rellenar el formulario
    $datos_contacto = json_decode($paciente['datos_contacto'], true);
    $motivo_consulta = json_decode($paciente['motivo_consulta'], true);
    $historial_relacional = json_decode($paciente['historial_relacional'], true);
    $historial_sustancias = json_decode($paciente['historial_sustancias'], true);
    $antecedentes_clinicos = json_decode($paciente['antecedentes_clinicos'], true);

} catch (\PDOException $e) {
    die("Error de Base de Datos: " . $e->getMessage());
}


// 3. LÓGICA DE ACTUALIZACIÓN (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // --- Re-estructuración y Sanitización de Datos JSON ---
    
    $motivo_consulta_data = [
        'motivo_explicito' => sanitize($_POST['motivo_consulta'] ?? ''),
        'tiempo_problema' => sanitize($_POST['tiempo_problema'] ?? ''),
        'expectativas' => sanitize($_POST['expectativas'] ?? ''),
    ];

    $relacional_data = [
        'estado_civil' => sanitize($_POST['estado_civil'] ?? ''),
        'nombre_vinculo' => sanitize($_POST['nombre_vinculo'] ?? ''),
        'relacion_tiempo_duracion' => sanitize($_POST['tiempo_duracion'] ?? ''),
        'separacion_tiempo' => sanitize($_POST['tiempo_separacion'] ?? ''),
        'separacion_causas' => sanitize($_POST['causas_separacion'] ?? ''),
        'tiene_hijos' => sanitize($_POST['tiene_hijos'] ?? 'No'),
        'hijos_detalle' => sanitize($_POST['hijos_detalle'] ?? ''),
        'relacion_origen' => sanitize($_POST['relacion_origen'] ?? ''),
    ];

    $sustancias_data = [
        'fuma' => sanitize($_POST['fuma'] ?? 'No'),
        'alcohol' => sanitize($_POST['alcohol'] ?? 'No'),
        'drogas_uso' => sanitize($_POST['drogas_alguna_vez'] ?? 'No'), 
        'drogas_tipo' => sanitize($_POST['drogas_tipo'] ?? ''),
        'drogas_ultimo_consumo' => sanitize($_POST['drogas_ultimo_consumo'] ?? ''),
    ];
    
    $antecedentes_clinicos_data = [
        'terapia_previa_bool' => sanitize($_POST['terapia_previa_bool'] ?? 'No'),
        'terapia_tiempo_duracion' => sanitize($_POST['terapia_duracion'] ?? ''),
        'terapia_tiempo_transcurrido' => sanitize($_POST['terapia_transcurrido'] ?? ''),
        'terapia_causas' => sanitize($_POST['terapia_causas'] ?? ''),
        'terapia_motivo_finalizacion' => sanitize($_POST['terapia_motivo_finalizacion'] ?? ''),
        'ant_psiquiatricos' => sanitize($_POST['ant_psiquiatricos'] ?? 'No'),
        'medicacion_psiquiatrica' => sanitize($_POST['medicacion'] ?? ''),
        'enfermedades_cronicas' => sanitize($_POST['enfermedades_cronicas'] ?? 'No'),
        'calidad_sueno' => sanitize($_POST['calidad_sueno'] ?? ''),
        'soporte_social' => sanitize($_POST['soporte_social'] ?? ''),
    ];

    $contacto_data = [
        'telefono_contacto' => sanitize($_POST['tel_contacto'] ?? ''),
        'telefono_emergencia' => sanitize($_POST['tel_emergencia'] ?? ''),
        'relacion_emergencia' => sanitize($_POST['rel_emergencia'] ?? ''),
    ];

    // --- Sentencia SQL de ACTUALIZACIÓN ---
    $sql_update = "UPDATE pacientes SET
        nombre_completo = :nombre_completo,
        email = :email,
        fecha_nacimiento = :fecha_nacimiento,
        ultimo_grado_estudios = :grado_estudios,
        ocupacion = :ocupacion,
        datos_contacto = :datos_contacto,
        motivo_consulta = :motivo_consulta,
        historial_relacional = :historial_relacional,
        historial_sustancias = :historial_sustancias,
        antecedentes_clinicos = :antecedentes_clinicos
        WHERE id = :id";
        
    try {
        $stmt_update = $pdo->prepare($sql_update);
        
        $params_update = [
            ':id' => $pacienteId,
            ':nombre_completo' => sanitize($_POST['nombre_completo'] ?? ''),
            ':email' => sanitize($_POST['email'] ?? ''),
            ':fecha_nacimiento' => sanitize($_POST['fecha_nacimiento'] ?? ''),
            ':grado_estudios' => sanitize($_POST['grado_estudios'] ?? ''),
            ':ocupacion' => sanitize($_POST['ocupacion'] ?? ''),
            
            // JSON fields
            ':datos_contacto' => json_encode($contacto_data),
            ':motivo_consulta' => json_encode($motivo_consulta_data),
            ':historial_relacional' => json_encode($relacional_data),
            ':historial_sustancias' => json_encode($sustancias_data),
            ':antecedentes_clinicos' => json_encode($antecedentes_clinicos_data),
        ];
        
        $stmt_update->execute($params_update);
        
        $mensaje_estado = "<div class='alerta exito'>✅ Datos del paciente actualizados correctamente.</div>";
        
        // Refrescar el paciente para mostrar los nuevos valores en el formulario
        $paciente = $stmt->fetch(); 
        
        // Recargar la página para ver los cambios y evitar el reenvío
        header("Refresh: 1; url=admin_detalle.php?id={$pacienteId}&tab=registro");
        
    } catch (\PDOException $e) {
        $error_message = ($e->getCode() == 23000) ? "El correo electrónico ya existe en la base de datos." : $e->getMessage();
        $mensaje_estado = "<div class='alerta error'>❌ Error al actualizar: {$error_message}</div>";
    }
}

// 4. CÁLCULO DE EDAD (Para rellenar el campo readonly)
$fechaNacimiento = $paciente['fecha_nacimiento'] ?? date('Y-m-d');
$fechaNac = new DateTime($fechaNacimiento);
$hoy = new DateTime();
$edad = $hoy->diff($fechaNac)->y;

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Historial de <?php echo htmlspecialchars($paciente['nombre_completo'] ?? 'Paciente'); ?></title>
    <link rel="stylesheet" href="admin_styles.css?v=1.2">
</head>
<body>
    <div class="container">
        <a href="admin_dashboard.php" class="logo-container">
            <img src="assets/img/logo.png" alt="CMS-GP Logo" class="logo">
        </a>
        
        <header>
            <a href="admin_detalle.php?id=<?php echo $pacienteId; ?>&tab=registro" class="back-link">← Volver al Historial</a>
            <a href="admin_dashboard.php?logout=1" class="logout-btn">Cerrar Sesión</a>
        </header>

        <div class="patient-header" style="text-align: left;">
            <h1>✏️ Editando Datos Iniciales</h1>
            <p>Paciente: <strong><?php echo htmlspecialchars($paciente['nombre_completo'] ?? ''); ?></strong> (ID #<?php echo $pacienteId; ?>)</p>
        </div>
        
        <?php echo $mensaje_estado; ?>

        <form method="POST">
            
            <h2>I. Datos Generales</h2>
            <div class="campo"><label for="nombre_completo">Nombre Completo:</label><input type="text" id="nombre_completo" name="nombre_completo" value="<?php echo htmlspecialchars($paciente['nombre_completo'] ?? ''); ?>" required></div>
            <div class="campo"><label for="email">Correo Electrónico:</label><input type="email" id="email" name="email" value="<?php echo htmlspecialchars($paciente['email'] ?? ''); ?>" required></div>
            <div class="campo"><label for="fecha_nacimiento">Fecha de Nacimiento:</label><input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo htmlspecialchars($paciente['fecha_nacimiento'] ?? ''); ?>" onchange="calcularEdad()" required></div>
            <div class="campo"><label for="edad">Edad:</label><input type="text" id="edad" name="edad" readonly placeholder="Calculada automáticamente" value="<?php echo $edad . ' años'; ?>"></div>
            <div class="campo"><label for="grado_estudios">Último Grado de Estudios:</label><input type="text" id="grado_estudios" name="grado_estudios" value="<?php echo htmlspecialchars($paciente['ultimo_grado_estudios'] ?? ''); ?>" required></div>
            <div class="campo"><label for="ocupacion">Ocupación/Profesión:</label><input type="text" id="ocupacion" name="ocupacion" value="<?php echo htmlspecialchars($paciente['ocupacion'] ?? ''); ?>" required></div>
            
            <div class="campo"><label for="tel_contacto">Teléfono (Contacto):</label><input type="text" id="tel_contacto" name="tel_contacto" value="<?php echo htmlspecialchars($datos_contacto['telefono_contacto'] ?? ''); ?>" required></div>
            <div class="campo"><label for="tel_emergencia">Teléfono (Emergencia):</label><input type="text" id="tel_emergencia" name="tel_emergencia" value="<?php echo htmlspecialchars($datos_contacto['telefono_emergencia'] ?? ''); ?>"></div>
            <div class="campo"><label for="rel_emergencia">Relación con Contacto de Emergencia:</label><input type="text" id="rel_emergencia" name="rel_emergencia" value="<?php echo htmlspecialchars($datos_contacto['relacion_emergencia'] ?? ''); ?>"></div>

            <h2>II. Motivo de Consulta</h2>
            <div class="campo"><label for="motivo_consulta">Motivo de Consulta Explícito:</label><textarea id="motivo_consulta" name="motivo_consulta" required><?php echo htmlspecialchars($motivo_consulta['motivo_explicito'] ?? ''); ?></textarea></div>
            <div class="campo"><label for="tiempo_problema">Tiempo del Problema:</label><input type="text" id="tiempo_problema" name="tiempo_problema" value="<?php echo htmlspecialchars($motivo_consulta['tiempo_problema'] ?? ''); ?>"></div>
            <div class="campo"><label for="expectativas">¿Qué espera lograr con la terapia?</label><textarea id="expectativas" name="expectativas"><?php echo htmlspecialchars($motivo_consulta['expectativas'] ?? ''); ?></textarea></div>

            <h2>III. Historia Familiar y Relacional</h2>
            <div class="campo">
                <label for="estado_civil">Estado Civil Actual:</label>
                <select id="estado_civil" name="estado_civil" onchange="mostrarCamposRelacionales()" required>
                    <?php $ec = $historial_relacional['estado_civil'] ?? ''; ?>
                    <option value="">Seleccione...</option>
                    <option value="Soltero" <?php echo ($ec == 'Soltero') ? 'selected' : ''; ?>>Soltero</option>
                    <option value="Casado" <?php echo ($ec == 'Casado') ? 'selected' : ''; ?>>Casado</option>
                    <option value="Union Libre" <?php echo ($ec == 'Union Libre') ? 'selected' : ''; ?>>Unión Libre</option>
                    <option value="Divorciado" <?php echo ($ec == 'Divorciado') ? 'selected' : ''; ?>>Divorciado</option>
                    <option value="Viudo" <?php echo ($ec == 'Viudo') ? 'selected' : ''; ?>>Viudo</option>
                </select>
            </div>

            <div id="campos_relacionales" class="opcion-condicional">
                <?php if ($ec == 'Casado' || $ec == 'Union Libre'): ?>
                    <h3>Detalles de la Relación Actual</h3>
                    <div class="campo"><label for="nombre_vinculo">Nombre de su Pareja:</label><input type="text" name="nombre_vinculo" value="<?php echo htmlspecialchars($historial_relacional['nombre_vinculo'] ?? ''); ?>" required></div>
                    <div class="campo"><label for="tiempo_duracion">Tiempo de Duración de la Relación:</label><input type="text" name="tiempo_duracion" value="<?php echo htmlspecialchars($historial_relacional['relacion_tiempo_duracion'] ?? ''); ?>" required></div>
                <?php elseif ($ec == 'Divorciado' || $ec == 'Viudo'): ?>
                    <h3>Detalles de la Separación/Pérdida</h3>
                    <div class="campo"><label for="nombre_vinculo">Nombre de su Ex-Pareja (o Pareja Fallecida):</label><input type="text" name="nombre_vinculo" value="<?php echo htmlspecialchars($historial_relacional['nombre_vinculo'] ?? ''); ?>" required></div>
                    <div class="campo"><label for="tiempo_separacion">Tiempo de Separación (o Pérdida):</label><input type="text" name="tiempo_separacion" value="<?php echo htmlspecialchars($historial_relacional['separacion_tiempo'] ?? ''); ?>" required></div>
                    <div class="campo"><label for="causas_separacion">Causas Simples de la Separación/Pérdida:</label><textarea name="causas_separacion" required><?php echo htmlspecialchars($historial_relacional['separacion_causas'] ?? ''); ?></textarea></div>
                <?php endif; ?>
            </div>
            
            <div class="campo"><label for="relacion_origen">Relación con la Familia de Origen:</label>
                <select id="relacion_origen" name="relacion_origen" required>
                    <?php $ro = $historial_relacional['relacion_origen'] ?? ''; ?>
                    <option value="Buena" <?php echo ($ro == 'Buena') ? 'selected' : ''; ?>>Buena</option>
                    <option value="Conflictiva" <?php echo ($ro == 'Conflictiva') ? 'selected' : ''; ?>>Conflictiva</option>
                    <option value="Distante" <?php echo ($ro == 'Distante') ? 'selected' : ''; ?>>Distante</option>
                    <option value="Otra" <?php echo ($ro == 'Otra') ? 'selected' : ''; ?>>Otra (especifique en notas)</option>
                </select>
            </div>
            
            <div class="campo">
                <label>¿Tiene hijos?</label>
                <div class="grupo-radio">
                    <?php $th = $historial_relacional['tiene_hijos'] ?? 'No'; ?>
                    <label><input type="radio" name="tiene_hijos" value="Sí" onclick="mostrarHijos()" <?php echo ($th == 'Sí') ? 'checked' : ''; ?>> Sí</label>
                    <label><input type="radio" name="tiene_hijos" value="No" onclick="mostrarHijos()" <?php echo ($th == 'No') ? 'checked' : ''; ?>> No</label>
                </div>
            </div>
            <div id="detalle_hijos" class="opcion-condicional" style="<?php echo ($th == 'Sí') ? 'display:block;' : 'display:none;'; ?>">
                <label for="hijos_detalle">Número y Edades de los Hijos:</label>
                <textarea id="hijos_detalle" name="hijos_detalle"><?php echo htmlspecialchars($historial_relacional['hijos_detalle'] ?? ''); ?></textarea>
            </div>


            <h2>IV. Antecedentes Clínicos y Salud Mental</h2>
            
            <div class="campo">
                <label>Ud o algún miembro de su familia cercana han tenido alguna aproximación con la Terapia?</label>
                <div class="grupo-radio">
                    <?php $tp = $antecedentes_clinicos['terapia_previa_bool'] ?? 'No'; ?>
                    <label><input type="radio" name="terapia_previa_bool" value="Sí" onclick="mostrarTerapiaPrevia()" <?php echo ($tp == 'Sí') ? 'checked' : ''; ?>> Sí</label>
                    <label><input type="radio" name="terapia_previa_bool" value="No" onclick="mostrarTerapiaPrevia()" <?php echo ($tp == 'No') ? 'checked' : ''; ?>> No</label>
                </div>
            </div>
            <div id="detalle_terapia_previa" class="opcion-condicional" style="<?php echo ($tp == 'Sí') ? 'display:block;' : 'display:none;'; ?>">
                <label for="terapia_duracion">Tiempo de duración:</label><input type="text" id="terapia_duracion" name="terapia_duracion" value="<?php echo htmlspecialchars($antecedentes_clinicos['terapia_tiempo_duracion'] ?? ''); ?>">
                <label for="terapia_transcurrido">Tiempo transcurrido de la última sesión:</label><input type="text" id="terapia_transcurrido" name="terapia_transcurrido" value="<?php echo htmlspecialchars($antecedentes_clinicos['terapia_tiempo_transcurrido'] ?? ''); ?>">
                <label for="terapia_causas">Causas (Motivo de consulta en ese momento):</label><textarea id="terapia_causas" name="terapia_causas"><?php echo htmlspecialchars($antecedentes_clinicos['terapia_causas'] ?? ''); ?></textarea>
                <label for="terapia_motivo_finalizacion">Motivo de finalización de la terapia:</label><textarea id="terapia_motivo_finalizacion" name="terapia_motivo_finalizacion"><?php echo htmlspecialchars($antecedentes_clinicos['terapia_motivo_finalizacion'] ?? ''); ?></textarea>
            </div>


            <h3>Uso de Sustancias</h3>
            <?php 
                $sustancias = ['Fuma', 'Alcohol', 'Drogas alguna vez'];
                $opciones_uso = ['Frecuentemente', 'Socialmente', 'Ocasionalmente', 'A veces', 'Casi Nunca', 'No'];
            ?>
            <?php foreach ($sustancias as $s): ?>
            <div class="campo">
                <label><?php echo $s; ?></label>
                <div class="grupo-radio">
                    <?php 
                    $name = strtolower(str_replace(' ', '_', $s));
                    $uso_actual = $historial_sustancias[$name] ?? 'No'; // Obtiene el uso actual
                    foreach ($opciones_uso as $op): ?>
                    <label><input type="radio" name="<?php echo $name; ?>" value="<?php echo $op; ?>" <?php echo ($op === $uso_actual) ? 'checked' : ''; ?> <?php echo ($s === 'Drogas alguna vez') ? 'onclick="mostrarDrogas()"' : ''; ?>> <?php echo $op; ?></label>
                    <?php endforeach; ?>
                </div>
                
                <?php if ($s === 'Drogas alguna vez'): ?>
                    <div id="detalle_drogas" class="opcion-condicional" style="<?php echo ($uso_actual !== 'No') ? 'display:block;' : 'display:none;'; ?>">
                        <label for="drogas_tipo">Tipo de Sustancia:</label><input type="text" id="drogas_tipo" name="drogas_tipo" value="<?php echo htmlspecialchars($historial_sustancias['drogas_tipo'] ?? ''); ?>">
                        <label for="drogas_ultimo_consumo">Tiempo del último consumo:</label><input type="text" id="drogas_ultimo_consumo" name="drogas_ultimo_consumo" value="<?php echo htmlspecialchars($historial_sustancias['drogas_ultimo_consumo'] ?? ''); ?>">
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            
            <div class="campo"><label for="ant_psiquiatricos">Antecedentes Psiquiátricos (Diagnóstico y Fecha):</label><input type="text" id="ant_psiquiatricos" name="ant_psiquiatricos" value="<?php echo htmlspecialchars($antecedentes_clinicos['ant_psiquiatricos'] ?? ''); ?>" placeholder="Ej: Depresión mayor, 2018"></div>
            <div class="campo"><label for="medicacion">Uso de Medicación Psiquiátrica (Nombre y Dosis):</label><input type="text" id="medicacion" name="medicacion" value="<?php echo htmlspecialchars($antecedentes_clinicos['medicacion_psiquiatrica'] ?? ''); ?>" placeholder="Ej: Sertralina 50mg"></div>
            <div class="campo"><label for="enfermedades_cronicas">Enfermedades Médicas Crónicas:</label><input type="text" id="enfermedades_cronicas" name="enfermedades_cronicas" value="<?php echo htmlspecialchars($antecedentes_clinicos['enfermedades_cronicas'] ?? ''); ?>" placeholder="Ej: Diabetes, Hipertensión"></div>
            <div class="campo"><label for="calidad_sueno">Calidad del Sueño:</label>
                <select id="calidad_sueno" name="calidad_sueno" required>
                    <?php $cs = $antecedentes_clinicos['calidad_sueno'] ?? ''; ?>
                    <option value="Bueno" <?php echo ($cs == 'Bueno') ? 'selected' : ''; ?>>Bueno (7-9 horas, reparador)</option>
                    <option value="Regular" <?php echo ($cs == 'Regular') ? 'selected' : ''; ?>>Regular (Despertares, cansancio)</option>
                    <option value="Malo" <?php echo ($cs == 'Malo') ? 'selected' : ''; ?>>Malo (Insomnio o hipersomnia)</option>
                </select>
            </div>
            <div class="campo"><label for="soporte_social">Soporte Social/Amigos (Evaluación simple):</label>
                <select id="soporte_social" name="soporte_social" required>
                    <?php $ss = $antecedentes_clinicos['soporte_social'] ?? ''; ?>
                    <option value="Alto" <?php echo ($ss == 'Alto') ? 'selected' : ''; ?>>Alto (Red de apoyo sólida)</option>
                    <option value="Medio" <?php echo ($ss == 'Medio') ? 'selected' : ''; ?>>Medio (Algunas amistades, familia)</option>
                    <option value="Bajo" <?php echo ($ss == 'Bajo') ? 'selected' : ''; ?>>Bajo (Aislamiento o conflictos)</option>
                </select>
            </div>

            <button type="submit" class="submit-btn" style="background: #f39c12;">Guardar Cambios y Actualizar Historial</button>
        </form>

        <footer class="main-footer">
            <p>&copy; <?php echo date('Y'); ?> CMS-GP | Desarrollado por Alberto Félix. <a href="mailto:hello@albertofelix.click">hello@albertofelix.click</a></p>
            <img src="assets/img/logo.png" alt="CMS-GP Logo" class="footer-logo">
        </footer>
    </div>
    
    <script src="assets/js/registro.js"></script> 
    
    <!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Historial de <?php echo htmlspecialchars($paciente['nombre_completo'] ?? 'Paciente'); ?></title>
    <link rel="stylesheet" href="admin_styles.css?v=1.2">
    <style>
        /* Variables necesarias para este formulario si no se cargan del CSS principal */
        :root { 
            --primary: #19aca9; 
            --dark: #1e272e; 
            --card-bg: #2f3542; 
            --section-bg: #3c4556; 
            --text-main: #ffffff; 
            --text-grey: #96969a; 
            --edit-button: #f39c12; /* Naranja/Amarillo para acción de edición */
            --accent-light: #38b8b5;
        }

        /* Replicar el estilo de campos del registro y dashboard */
        h2 { 
            color: var(--text-main); 
            font-size: 1.2em; 
            margin-top: 35px; 
            margin-bottom: 15px;
            background: var(--section-bg);
            padding: 10px 15px;
            border-left: 5px solid var(--primary); 
            border-radius: 4px;
        }
        h3 { /* Estilo para los subtítulos dentro de las secciones (Ej: Uso de Sustancias) */
            color: var(--text-main);
            font-size: 1.1em;
            margin-top: 25px;
            margin-bottom: 10px;
            border-bottom: 1px solid #444;
            padding-bottom: 5px;
        }

        .campo { margin-bottom: 20px; }
        label { display: block; margin-bottom: 6px; color: var(--text-main); font-weight: 500; font-size: 0.9em; }
        
        input[type="text"], input[type="email"], input[type="date"], textarea, select, input[type="datetime-local"] {
            width: 100%; padding: 12px; border: 1px solid #444; border-radius: 6px;
            background: var(--section-bg); color: var(--text-main); box-sizing: border-box;
            transition: border-color 0.2s;
        }
        input[type="text"]:focus, input[type="email"]:focus, textarea:focus, select:focus, input[type="date"]:focus, input[type="datetime-local"]:focus {
            border-color: var(--primary);
            outline: none;
        }
        textarea { height: 80px; resize: vertical; }

        /* Radios y Checkboxes */
        .grupo-radio { display: flex; gap: 15px; margin-top: 5px; flex-wrap: wrap; }
        .grupo-radio label { 
            display: flex; align-items: center; 
            margin-bottom: 5px; color: var(--text-grey); 
            font-weight: normal; 
        }
        /* Color de acento para radios/checkboxes */
        input[type="radio"], input[type="checkbox"] {
            accent-color: var(--primary); 
            width: auto; margin-right: 5px;
        }
        
        /* Botón de Guardar */
        .submit-btn {
            background: var(--edit-button); /* Naranja de Edición */
            color: var(--text-main); padding: 15px 25px; border: none;
            border-radius: 8px; font-size: 1.1em; cursor: pointer; display: block; width: 100%;
            margin-top: 30px; font-weight: bold; transition: background 0.2s;
        }
        .submit-btn:hover { background: #d38f19; }
        
        /* Alertas */
        .alerta.error { background: #f8d7da; color: #721c24; border-color: #f5c6cb; padding: 10px; border-radius: 4px; margin-top: 15px; }
        .alerta.exito { background: #d4edda; color: #155724; border-color: #c3e6cb; padding: 10px; border-radius: 4px; margin-top: 15px; }

    </style>
</head>
<body>
</body>
</html>