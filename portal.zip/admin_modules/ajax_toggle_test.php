<?php
// admin_modules/ajax_toggle_test.php
require '../db_connect.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['success' => false, 'message' => 'No auth']); exit;
}

// Recibimos paciente_id y test_id (desde el JS)
$id     = $_POST['paciente_id'] ?? null;
$test   = $_POST['test_id'] ?? null;
$status = ($_POST['status'] == '1' || $_POST['status'] == 'true') ? 1 : 0;

$allowed_tests = ['mmpi', 'bdi', 'bai', 'tdah'];
if (in_array($test, $allowed_tests) && $id) {
    $column = "test_{$test}_activo"; // Ej: test_bai_activo
    $stmt = $pdo->prepare("UPDATE pacientes SET $column = ? WHERE id = ?");
    $success = $stmt->execute([$status, $id]);
    echo json_encode(['success' => $success]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
}