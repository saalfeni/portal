<?php
// admin_modules/admin_detalle.php - Versión con Switch Elegante y Rutas Corregidas
if (!isset($pdo)) exit;

$paciente_id = $_GET['id'] ?? null;
if (!$paciente_id) { echo "Error: ID no especificado."; exit; }

$stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt->execute([$paciente_id]);
$paciente = $stmt->fetch();

if (!$paciente) { echo "Error: Paciente no encontrado."; exit; }

// --- LÓGICA DE IDENTIDAD (GRAVATAR) ---
if (!function_exists('get_gravatar')) {
    function get_gravatar($email, $s = 150) {
        $hash = md5(strtolower(trim($email ?? '')));
        return "https://www.gravatar.com/avatar/$hash?s=$s&d=identicon";
    }
}

$avatar_url = (!empty($paciente['foto_perfil']) && file_exists($paciente['foto_perfil'])) 
    ? $paciente['foto_perfil'] 
    : get_gravatar($paciente['email']);

$tab = $_GET['tab'] ?? 'resumen';
?>

<div class="expediente-wrapper">
    <div class="expediente-header-pro">
        <img src="<?php echo $avatar_url; ?>" class="avatar-exp-pro">
        <div class="info">
            <h2><?php echo htmlspecialchars($paciente['nombre_completo']); ?></h2>
            <span class="badge-id">PACIENTE #<?php echo str_pad($paciente_id, 4, "0", STR_PAD_LEFT); ?></span>
        </div>
    </div>

    <div class="tabs-container-scroll">
        <nav class="expediente-tabs-grid">
            <a href="?view=detalle&id=<?php echo $paciente_id; ?>&tab=resumen" class="tab-btn <?php echo $tab=='resumen'?'active':''; ?>">
                <i class="fas fa-id-card"></i><span>Ficha</span>
            </a>
            <a href="?view=detalle&id=<?php echo $paciente_id; ?>&tab=bitacora" class="tab-btn <?php echo $tab=='bitacora'?'active':''; ?>">
                <i class="fas fa-notes-medical"></i><span>Bitácora</span>
            </a>
            <a href="?view=detalle&id=<?php echo $paciente_id; ?>&tab=psicometria" class="tab-btn <?php echo $tab=='psicometria'?'active':''; ?>">
                <i class="fas fa-brain"></i><span>Tests</span>
            </a>
            <a href="?view=detalle&id=<?php echo $paciente_id; ?>&tab=tareas" class="tab-btn <?php echo $tab=='tareas'?'active':''; ?>">
                <i class="fas fa-tasks"></i><span>Tareas</span>
            </a>
            <a href="?view=detalle&id=<?php echo $paciente_id; ?>&tab=finanzas" class="tab-btn <?php echo $tab=='finanzas'?'active':''; ?>">
                <i class="fas fa-wallet"></i><span>Finanzas</span>
            </a>
        </nav>
    </div>

    <div class="expediente-content-box">
        <?php 
            if ($tab == 'bitacora' || $tab == 'sesiones') {
                $sub_path = "admin_modules/submodules/detalle_sesiones.php";
            } else {
                $sub_path = "admin_modules/submodules/detalle_" . $tab . ".php";
            }

            if(file_exists($sub_path)) {
                include $sub_path;
            } else {
                echo "<div style='text-align:center; padding:30px; color:#666;'>Módulo $tab en desarrollo...</div>";
            }
        ?>
    </div>
</div>

<style>
    /* VARIABLES Y ESTILOS BASE */
    :root { --turquesa: #40E0D0; }

    .expediente-header-pro { display: flex; align-items: center; gap: 20px; margin-bottom: 20px; padding: 10px; }
    .avatar-exp-pro { width: 75px; height: 75px; border-radius: 50%; border: 3px solid var(--turquesa); object-fit: cover; background: #252525; }
    .expediente-header-pro h2 { margin: 0; font-size: 1.4rem; color: #fff; }
    .badge-id { font-size: 0.75rem; color: var(--turquesa); font-weight: bold; text-transform: uppercase; }

    /* NAVEGACIÓN */
    .tabs-container-scroll { overflow-x: auto; -webkit-overflow-scrolling: touch; margin-bottom: 20px; }
    .expediente-tabs-grid { display: flex; gap: 10px; min-width: max-content; }
    
    .tab-btn { 
        background: #1a1a1a; border: 1px solid #333; border-radius: 12px; padding: 12px 18px; 
        text-decoration: none; color: #777; transition: 0.3s;
        display: flex; flex-direction: column; align-items: center; gap: 6px;
    }
    .tab-btn i { font-size: 1.1rem; }
    .tab-btn span { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; }
    .tab-btn.active { 
        background: rgba(64, 224, 208, 0.1); border-color: var(--turquesa); color: var(--turquesa); 
    }

    .expediente-content-box { background: var(--card); border-radius: 20px; padding: 20px; border: 1px solid #2a2a2a; min-height: 400px; }

    /* --- EL SWITCH TOGGLE ELEGANTE --- */
    .switch-container {
        position: relative;
        display: inline-block;
        width: 44px;
        height: 22px;
    }

    .switch-container input { opacity: 0; width: 0; height: 0; }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0; left: 0; right: 0; bottom: 0;
        background-color: #333;
        transition: .4s;
        border-radius: 34px;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
    }

    input:checked + .slider { background-color: var(--turquesa); }
    input:checked + .slider:before { transform: translateX(22px); }

    /* RESPONSIVE ESCRITORIO */
    @media (min-width: 769px) {
        .expediente-tabs-grid { display: grid; grid-template-columns: repeat(5, 1fr); min-width: 100%; }
        .avatar-exp-pro { width: 90px; height: 90px; }
    }
</style>

<script>
/**
 * Función AJAX para habilitar/deshabilitar tests en tiempo real con el Switch
 */
function toggleTest(pacienteId, testId, status) {
    const val = status ? 1 : 0;
    
    const formData = new URLSearchParams();
    formData.append('paciente_id', pacienteId);
    formData.append('test_id', testId);
    formData.append('status', val);

    // Efecto visual opcional: podrías agregar un pequeño loader aquí
    fetch('admin_modules/ajax_toggle_test.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(!data.success) {
            alert('Error al actualizar el estado. Por favor intente de nuevo.');
            location.reload(); // Revertir visualmente si falla
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
</script>

<?php include 'admin_modules/submodules/modales_admin.php'; ?>