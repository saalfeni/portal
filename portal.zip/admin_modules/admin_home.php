<?php
// admin_modules/admin_home.php
if (!isset($pdo)) exit;

$inicio_semana = date('Y-m-d', strtotime('monday this week'));
$fin_semana = date('Y-m-d', strtotime('sunday this week'));

// 1. Ingresos Semanales (Tabla: sesiones_pagos | Columna real: fecha_sesion)
$stmt_fin = $pdo->prepare("SELECT SUM(monto) FROM sesiones_pagos WHERE fecha_sesion BETWEEN ? AND ?");
$stmt_fin->execute([$inicio_semana, $fin_semana]);
$ingresos_semana = $stmt_fin->fetchColumn() ?? 0;

// 2. Citas Semanales (Tabla: sesiones | Columna real: fecha_sesion)
$stmt_citas_count = $pdo->prepare("SELECT COUNT(*) FROM sesiones WHERE fecha_sesion BETWEEN ? AND ?");
$stmt_citas_count->execute([$inicio_semana, $fin_semana]);
$total_citas_semana = $stmt_citas_count->fetchColumn();

// 3. Próximas Citas (Agenda)
$stmt_agenda = $pdo->prepare("SELECT s.*, p.nombre_completo 
                             FROM sesiones s 
                             JOIN pacientes p ON s.paciente_id = p.id 
                             WHERE s.fecha_sesion >= CURDATE() 
                             ORDER BY s.fecha_sesion ASC LIMIT 5");
$stmt_agenda->execute();
$proximas_citas = $stmt_agenda->fetchAll();
?>

<div class="dashboard-home">
    <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="background: var(--card); padding: 25px; border-radius: 15px; border-left: 4px solid var(--turquesa); box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <span style="color: #666; font-size: 0.75rem; text-transform: uppercase; font-weight:bold;">Ingresos Semanales</span>
            <h2 style="margin: 10px 0 0; color: var(--turquesa); font-size: 2rem;">$<?php echo number_format($ingresos_semana, 2); ?></h2>
        </div>
        <div class="stat-card" style="background: var(--card); padding: 25px; border-radius: 15px; border-left: 4px solid #f1c40f; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <span style="color: #666; font-size: 0.75rem; text-transform: uppercase; font-weight:bold;">Sesiones en Agenda</span>
            <h2 style="margin: 10px 0 0; color: #f1c40f; font-size: 2rem;"><?php echo $total_citas_semana; ?></h2>
        </div>
    </div>

    <div class="home-main-grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 25px;">
        <div class="agenda-section" style="background: var(--card); padding: 25px; border-radius: 20px; border: 1px solid #222;">
            <h4 style="margin: 0 0 20px 0;"><i class="fas fa-calendar-alt" style="color: var(--turquesa); margin-right: 10px;"></i> Próximas Citas</h4>
            <div class="table-responsive">
                <table style="width:100%; border-collapse:collapse;">
                    <?php foreach($proximas_citas as $cita): ?>
                    <tr style="border-bottom: 1px solid #222;">
                        <td style="padding:15px;"><strong><?php echo date('d/m/Y', strtotime($cita['fecha_sesion'])); ?></strong></td>
                        <td style="padding:15px; color:#aaa;"><?php echo htmlspecialchars($cita['nombre_completo']); ?></td>
                        <td style="padding:15px; text-align:right;">
                            <a href="admin_dashboard.php?view=detalle&id=<?php echo $cita['paciente_id']; ?>" style="color:var(--turquesa);"><i class="fas fa-chevron-right"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
        <div class="quick-nav" style="display: flex; flex-direction: column; gap: 15px;">
            <label style="color:#444; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">Accesos rápidos</label>
            <a href="admin_dashboard.php?view=pacientes" style="background: #1a1a1a; padding: 15px; border-radius: 10px; text-decoration:none; color:#eee; display:flex; align-items:center; gap:10px; border: 1px solid #333;">
                <i class="fas fa-users" style="color:var(--turquesa);"></i> Lista de Pacientes
            </a>
            <a href="admin_dashboard.php?view=contabilidad" style="background: #1a1a1a; padding: 15px; border-radius: 10px; text-decoration:none; color:#eee; display:flex; align-items:center; gap:10px; border: 1px solid #333;">
                <i class="fas fa-calculator" style="color:#f1c40f;"></i> Contabilidad
            </a>
        </div>
    </div>
</div>