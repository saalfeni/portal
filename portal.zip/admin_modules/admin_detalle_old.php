<?php
// admin_detalle.php - Versión Final (Dark Pro + Modals + Responsivo)
header('Content-Type: text/html; charset=utf-8');
//session_start();
require 'db_connect.php'; 
require 'config_admin.php';

// 1. AUTENTICACIÓN
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

$pacienteId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$pacienteId) die("Error: ID de paciente no especificado.");

// --- LÓGICA TESTS ---
$stmt_check = $pdo->prepare("SELECT COUNT(*) FROM mmpi2_respuestas WHERE paciente_id = ?");
$stmt_check->execute([$pacienteId]); 
$total_mmpi = $stmt_check->fetchColumn();
$mmpi_completado = ($total_mmpi >= 567);

$stmt_bdi = $pdo->prepare("SELECT COUNT(*) FROM bdi2_respuestas WHERE paciente_id = ?");
$stmt_bdi->execute([$pacienteId]);
$total_bdi = $stmt_bdi->fetchColumn();
$bdi_completado = ($total_bdi >= 21);

// 2. RECUPERACIÓN DE DATOS
try {
    $stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = :id");
    $stmt->bindValue(':id', $pacienteId, PDO::PARAM_INT);
    $stmt->execute();
    $paciente = $stmt->fetch();

    if (!$paciente) die("Error: Paciente no encontrado.");

    // Decodificación JSON
    $datos_contacto = json_decode($paciente['datos_contacto'] ?? '{}', true) ?? [];
    $motivo_consulta = json_decode($paciente['motivo_consulta'] ?? '{}', true) ?? [];
    $historial_relacional = json_decode($paciente['historial_relacional'] ?? '{}', true) ?? [];
    $historial_sustancias = json_decode($paciente['historial_sustancias'] ?? '{}', true) ?? [];
    $antecedentes_clinicos = json_decode($paciente['antecedentes_clinicos'] ?? '{}', true) ?? [];

    // Cargar Sesiones (Notas)
    $stmtSesiones = $pdo->prepare("SELECT * FROM sesiones WHERE paciente_id = ? ORDER BY fecha_sesion DESC");
    $stmtSesiones->execute([$pacienteId]);
    $sesiones = $stmtSesiones->fetchAll();

    // Cargar Pagos
    $stmtPagos = $pdo->prepare("SELECT * FROM sesiones_pagos WHERE paciente_id = ? ORDER BY fecha_sesion DESC");
    $stmtPagos->execute([$pacienteId]);
    $pagos = $stmtPagos->fetchAll();
    
} catch (\PDOException $e) {
    die("Error de Base de Datos: " . $e->getMessage());
}

$current_tab = $_GET['tab'] ?? 'registro';

// --- LÓGICA DE CALENDARIO ---
$cita_timestamp = $paciente['proxima_cita'] ? strtotime($paciente['proxima_cita']) : time();
$mes_actual = date('n', $cita_timestamp);
$anio_actual = date('Y', $cita_timestamp);
$dia_cita = $paciente['proxima_cita'] ? date('j', $cita_timestamp) : null;
$num_dias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $anio_actual);
$primer_dia_semana = date('w', strtotime("$anio_actual-$mes_actual-01"));
$meses_es = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

// Función auxiliar
function formatEstadoCivil($data) {
    $ec = $data['estado_civil'] ?? 'N/A';
    $output = "<strong>{$ec}</strong>";
    if ($ec === 'Casado' || $ec === 'Union Libre') {
        $output .= ": con " . htmlspecialchars($data['nombre_vinculo'] ?? 'N/A');
    }
    return $output;
}

$fechaNac = new DateTime($paciente['fecha_nacimiento']);
$hoy = new DateTime();
$edad = $hoy->diff($fechaNac)->y;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expediente: <?php echo htmlspecialchars($paciente['nombre_completo']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --bg-dark: #121212; --card-bg: #1e1e1e; --text-main: #e0e0e0;
            --text-muted: #a0a0a0; --accent: #40E0D0; --accent-hover: #2ac7b8;
            --danger: #e74c3c; --success: #27ae60; --warning: #f39c12; --border: #333;
        }
        
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background-color: var(--bg-dark); color: var(--text-main); margin: 0; padding: 20px; }
        
        /* HEADER & LAYOUT */
        header { background: var(--card-bg); padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid var(--accent); border-radius: 12px; margin-bottom: 30px; flex-wrap: wrap; gap: 10px; }
        .brand-logo a { color: var(--text-main); text-decoration: none; font-weight: bold; font-size: 1.2rem; display: flex; align-items: center; gap: 10px; }
        
        /* PACIENTE HEADER */
        .patient-header { background: linear-gradient(to right, var(--card-bg), #252525); padding: 25px; border-radius: 12px; margin-bottom: 25px; border-left: 5px solid var(--accent); display: flex; justify-content: space-between; flex-wrap: wrap; gap: 15px; }
        .patient-header h1 { margin: 0; color: var(--accent); font-weight: 300; font-size: 1.5rem; }
        .patient-meta { color: var(--text-muted); font-size: 0.9rem; margin-top: 5px; }

        /* TABS */
        .admin-tabs { display: flex; gap: 5px; margin-bottom: 25px; border-bottom: 1px solid var(--border); padding-bottom: 0; overflow-x: auto; }
        .admin-tabs a { padding: 12px 20px; color: var(--text-muted); text-decoration: none; font-weight: 500; border-bottom: 3px solid transparent; white-space: nowrap; }
        .admin-tabs a.active { color: var(--accent); border-bottom-color: var(--accent); background: rgba(255,255,255,0.03); }

        /* GRID SYSTEM (RESPONSIVE) */
        .management-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .full-width { grid-column: 1 / -1; }
        
        @media (max-width: 900px) { .management-grid { grid-template-columns: 1fr; } }

        .card, .data-group { background: var(--card-bg); padding: 25px; border-radius: 12px; border: 1px solid var(--border); box-shadow: 0 4px 10px rgba(0,0,0,0.2); margin-bottom: 20px; }
        .card-header-flex { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 20px; }
        h3 { color: var(--accent); margin: 0; font-size: 1.1rem; }

        /* BOTONES */
        .btn-save { background: var(--accent); color: #121212; border: none; padding: 12px; border-radius: 6px; cursor: pointer; font-weight: bold; width: 100%; transition: 0.3s; margin-top: 15px; }
        .btn-save:hover { background: var(--accent-hover); }
        .btn-sm { padding: 8px 15px; font-size: 0.85rem; width: auto; display: inline-block; margin-top: 0; text-decoration: none; color: #121212; background: var(--accent); border-radius: 4px; font-weight: bold; }
        .btn-icon { color: var(--accent); text-decoration: none; font-size: 1.1rem; padding: 5px; }
        .btn-icon:hover { color: #fff; }

        /* INPUTS & CHECKS */
        .input-admin { width: 100%; padding: 12px; background: #2a2a2a; border: 1px solid var(--border); color: var(--text-main); border-radius: 6px; margin-top: 5px; box-sizing: border-box; }
        .check-group { display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; margin-bottom: 10px; cursor: pointer; transition: 0.3s; }
        .check-group:hover { border-color: var(--accent); }
        .check-group input { transform: scale(1.3); accent-color: var(--accent); }

        /* ESTADOS TESTS */
        .test-status-card { background: rgba(0,0,0,0.2); padding: 15px; border-radius: 8px; margin-top: 15px; border-left: 3px solid #666; display: flex; justify-content: space-between; align-items: center; }
        .test-status-card.completed { border-left-color: var(--success); }
        .btn-test { padding: 5px 10px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 0.8rem; background: #333; color: #999; }
        .btn-test.active { background: var(--accent); color: #000; }

        /* TABLAS */
        .table-responsive { overflow-x: auto; }
        .table-pagos { width: 100%; border-collapse: collapse; min-width: 500px; }
        .table-pagos th { text-align: left; padding: 10px; color: var(--text-muted); border-bottom: 1px solid #444; }
        .table-pagos td { padding: 12px 10px; border-bottom: 1px solid var(--border); }
        .status-pill { padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: bold; }
        .status-pagado { background: rgba(39, 174, 96, 0.2); color: #2ecc71; }
        .status-pendiente { background: rgba(231, 76, 60, 0.2); color: #e74c3c; }

        /* MODAL */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.8); backdrop-filter: blur(4px); }
        .modal-content { background-color: var(--card-bg); margin: 10% auto; padding: 30px; border: 1px solid var(--accent); width: 90%; max-width: 500px; border-radius: 12px; position: relative; box-shadow: 0 0 30px rgba(0,0,0,0.5); }
        .close { color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer; }
        .close:hover { color: var(--accent); }

        /* CALENDARIO */
        .mini-calendar { width: 100%; text-align: center; margin-top: 15px; }
        .calendar-header { background: var(--accent); color: #000; padding: 5px; font-weight: bold; border-radius: 4px 4px 0 0; }
        .calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 2px; background: #333; padding: 2px; }
        .cal-day { background: var(--card-bg); padding: 8px 2px; font-size: 0.9rem; color: var(--text-muted); }
        .cal-head { background: #2a2a2a; color: var(--accent); font-weight: bold; padding: 5px 0; font-size: 0.8rem; }
        .cal-day.active { background: var(--accent); color: #000; font-weight: bold; }
        
        /* DATA LIST */
        .data-list { display: grid; grid-template-columns: 140px 1fr; gap: 8px; font-size: 0.95rem; }
        .data-list dt { color: var(--text-muted); text-align: right; }
        @media (max-width: 600px) { .data-list { grid-template-columns: 1fr; } .data-list dt { text-align: left; margin-top: 10px; font-weight: bold; } }
    </style>
</head>
<body>

<div id="cobroModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('cobroModal')">&times;</span>
        <h2 style="color:var(--accent); margin-top:0;">Registrar Nuevo Cobro</h2>
        <form action="registrar_pago.php" method="POST">
            <input type="hidden" name="paciente_id" value="<?php echo $pacienteId; ?>">
            
            <label style="color:var(--text-muted);">Fecha de la sesión</label>
            <input type="date" name="fecha_sesion" class="input-admin" required value="<?php echo date('Y-m-d'); ?>">
            
            <label style="color:var(--text-muted); margin-top:10px; display:block;">Monto ($)</label>
            <input type="number" name="monto" class="input-admin" step="0.01" required placeholder="0.00">
            
            <label style="color:var(--text-muted); margin-top:10px; display:block;">Estado del Pago</label>
            <select name="estado_pago" class="input-admin">
                <option value="Pendiente">Pendiente</option>
                <option value="Pagado">Pagado</option>
            </select>
            
            <label style="color:var(--text-muted); margin-top:10px; display:block;">Notas (Opcional)</label>
            <textarea name="notas" class="input-admin" rows="2"></textarea>
            
            <button type="submit" class="btn-save" style="background:var(--success);">Guardar Cobro</button>
        </form>
    </div>
</div>

<form id="configForm" action="actualizar_portal.php" method="POST">
    <input type="hidden" name="paciente_id" value="<?php echo $pacienteId; ?>">
</form>

<?php if (isset($_GET['status']) && $_GET['status'] == 'updated'): ?>
    <script>alert("✅ Datos actualizados correctamente."); window.history.replaceState({}, document.title, window.location.pathname + "?id=<?php echo $_GET['id']; ?>");</script>
<?php endif; ?>

<header>
    <div class="brand-logo">
        <a href="admin_dashboard.php">
            <img src="assets/img/logo.png" style="height:40px;"> 
            <span>ADMINISTRACIÓN</span>
        </a>
    </div>
    <div style="display:flex; gap:10px;">
        <a href="admin_export_ficha.php?id=<?php echo $pacienteId; ?>" target="_blank" class="btn-sm" style="background: #333; color: white;"><i class="fas fa-file-pdf"></i> Ficha PDF</a>
        <a href="admin_dashboard.php?logout=1" class="btn-sm" style="background:transparent; border:1px solid var(--danger); color:var(--danger);">Salir</a>
    </div>
</header>

<div class="patient-header">
    <div>
        <h1><?php echo htmlspecialchars($paciente['nombre_completo']); ?></h1>
        <div class="patient-meta">ID: #<?php echo $paciente['id']; ?> &bull; <?php echo $edad; ?> años &bull; <?php echo htmlspecialchars($paciente['email']); ?></div>
    </div>
    <div style="align-self: center;">
        <span class="status-pill status-pagado" style="font-size:1rem; padding:8px 15px;">Activo</span>
    </div>
</div>

<nav class="admin-tabs">
    <a href="?id=<?php echo $pacienteId; ?>&tab=registro" class="<?php echo ($current_tab == 'registro') ? 'active' : ''; ?>">Portal y Pagos</a>
    <a href="?id=<?php echo $pacienteId; ?>&tab=sesiones" class="<?php echo ($current_tab == 'sesiones') ? 'active' : ''; ?>">Notas Clínicas (<?php echo count($sesiones); ?>)</a>
</nav>

<div class="tab-content">
    <?php if ($current_tab == 'registro'): ?>
        
        <div class="management-grid">
            
            <div class="data-group">
                <h3><i class="fas fa-toggle-on"></i> Accesos del Paciente</h3>
                <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:15px;">Controla qué pruebas ve el paciente:</p>
                
                <label class="check-group">
                    <input type="checkbox" name="mmpi2_habilitado" value="1" form="configForm" <?php echo ($paciente['mmpi2_habilitado'] == 1) ? 'checked' : ''; ?>>
                    <span>MMPI-2 (Personalidad)</span>
                </label>
                
                <label class="check-group">
                    <input type="checkbox" name="bdi2_habilitado" value="1" form="configForm" <?php echo ($paciente['bdi2_habilitado'] ?? 0) == 1 ? 'checked' : ''; ?>>
                    <span>BDI-II (Depresión)</span>
                </label>
                
                <button type="submit" form="configForm" class="btn-save">Actualizar Permisos</button>

                <div class="test-status-card <?php echo $mmpi_completado ? 'completed' : ''; ?>">
                    <div><strong>MMPI-2</strong> <small style="color:#aaa;">(<?php echo $total_mmpi; ?>/567)</small></div>
                    <?php if ($mmpi_completado): ?><a href="tests/mmpi-2/interpretar.php?id=<?php echo $pacienteId; ?>" target="_blank" class="btn-test active"><i class="fas fa-eye"></i></a>
                    <?php else: ?><span class="btn-test">...</span><?php endif; ?>
                </div>

                <div class="test-status-card <?php echo $bdi_completado ? 'completed' : ''; ?>">
                    <div><strong>BDI-II</strong> <small style="color:#aaa;">(<?php echo $total_bdi; ?>/21)</small></div>
                    <?php if ($bdi_completado): ?><a href="tests/bdi-2/interpretar_bdi.php?id=<?php echo $pacienteId; ?>" target="_blank" class="btn-test active"><i class="fas fa-eye"></i></a>
                    <?php else: ?><span class="btn-test">...</span><?php endif; ?>
                </div>
            </div>

            <div>
                <div class="data-group" style="margin-bottom: 20px;">
                    <h3><i class="far fa-calendar-alt"></i> Próxima Cita</h3>
                    <div style="display:flex; gap:10px;">
                        <input type="datetime-local" name="proxima_cita" class="input-admin" form="configForm" value="<?php echo $paciente['proxima_cita'] ? date('Y-m-d\TH:i', strtotime($paciente['proxima_cita'])) : ''; ?>">
                        <button type="submit" form="configForm" class="btn-save" style="margin-top:5px; width:auto; padding:0 15px;"><i class="fas fa-save"></i></button>
                    </div>
                    
                    <div class="mini-calendar">
                        <div class="calendar-header"><?php echo $meses_es[$mes_actual] . " " . $anio_actual; ?></div>
                        <div class="calendar-grid">
                            <div class="cal-head">Do</div><div class="cal-head">Lu</div><div class="cal-head">Ma</div><div class="cal-head">Mi</div><div class="cal-head">Ju</div><div class="cal-head">Vi</div><div class="cal-head">Sa</div>
                            <?php
                            for ($i = 0; $i < $primer_dia_semana; $i++) echo '<div class="cal-day"></div>';
                            for ($day = 1; $day <= $num_dias; $day++) {
                                $isActive = ($day == $dia_cita) ? 'active' : '';
                                echo "<div class='cal-day $isActive'>$day</div>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div class="data-group">
                    <h3><i class="fas fa-tasks"></i> Asignar Tarea</h3>
                    <form action="guardar_actividad.php" method="POST">
                        <input type="hidden" name="paciente_id" value="<?php echo $pacienteId; ?>">
                        <textarea name="actividad" class="input-admin" style="height: 80px; resize:none;" placeholder="Instrucción..."></textarea>
                        <button type="submit" class="btn-save" style="background:#444; color:white; margin-top:10px;">Enviar</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="card full-width">
            <div class="card-header-flex">
                <h3><i class="fas fa-wallet"></i> Historial de Cobros</h3>
                <button onclick="openModal('cobroModal')" class="btn-sm"><i class="fas fa-plus"></i> Registrar Cobro</button>
            </div>
            
            <div class="table-responsive">
                <table class="table-pagos">
                    <thead><tr><th>Fecha</th><th>Monto</th><th>Estado</th><th style="text-align:center;">Acciones</th></tr></thead>
                    <tbody>
                        <?php foreach ($pagos as $p): ?>
                        <tr>
                            <td><?php echo date('d/m/Y', strtotime($p['fecha_sesion'])); ?></td>
                            <td><strong>$<?php echo number_format($p['monto'], 2); ?></strong></td>
                            <td><span class="status-pill <?php echo $p['estado_pago'] == 'Pagado' ? 'status-pagado' : 'status-pendiente'; ?>"><?php echo $p['estado_pago']; ?></span></td>
                            <td style="text-align:center;">
                                <?php if($p['estado_pago'] == 'Pagado'): ?>
                                    <a href="generar_recibo.php?id=<?php echo $p['id']; ?>" target="_blank" class="btn-icon" title="Imprimir Recibo"><i class="fas fa-print"></i></a>
                                <?php else: ?>
                                    <span style="color:#555;">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($pagos)): ?>
                            <tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding:20px;">No hay cobros registrados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card full-width">
            <h3><i class="fas fa-info-circle"></i> Resumen de Ficha</h3>
            <div style="margin-top:15px;">
                <div class="data-list">
                    <dt>Teléfono:</dt><dd><?php echo htmlspecialchars($datos_contacto['telefono_contacto'] ?? '--'); ?></dd>
                    <dt>Motivo:</dt><dd><?php echo htmlspecialchars($motivo_consulta['motivo_explicito'] ?? '--'); ?></dd>
                </div>
                <div style="margin-top:15px; text-align:right;">
                    <a href="admin_edit_paciente.php?id=<?php echo $pacienteId; ?>" style="color:var(--accent); text-decoration:none;">Ver ficha completa &rarr;</a>
                </div>
            </div>
        </div>

    <?php elseif ($current_tab == 'sesiones'): ?>
        
        <div class="card full-width">
            <div class="card-header-flex">
                <h3><i class="fas fa-notes-medical"></i> Notas de Evolución</h3>
                <a href="admin_add_sesion.php?paciente_id=<?php echo $pacienteId; ?>" class="btn-sm"><i class="fas fa-plus"></i> Nueva Nota Clínica</a>
            </div>

            <div class="table-responsive">
                <table class="table-pagos">
                    <thead><tr><th>Fecha</th><th>Tipo</th><th>Resumen</th><th style="text-align:center;">Ver</th></tr></thead>
                    <tbody>
                        <?php foreach ($sesiones as $s): ?>
                        <tr>
                            <td><?php echo date('d/m/Y', strtotime($s['fecha_sesion'])); ?></td>
                            <td>Nota de Evolución</td>
                            <td style="color:var(--text-muted); font-style:italic;">
                                <?php echo substr(strip_tags($s['notas_subjetivas'] ?? 'Sin detalles'), 0, 60) . '...'; ?>
                            </td>
                            <td style="text-align:center;">
                                <a href="admin_ver_sesion.php?id=<?php echo $s['id']; ?>" class="btn-icon"><i class="fas fa-eye"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($sesiones)): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 30px; color: var(--text-muted);">No hay notas registradas para este paciente.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
    function openModal(id) { document.getElementById(id).style.display = 'block'; }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) { event.target.style.display = 'none'; }
    }
</script>

</body>
</html>