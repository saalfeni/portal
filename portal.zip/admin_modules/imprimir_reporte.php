<?php
require '../db_connect.php';
session_start();

if (!isset($_SESSION['admin_logged_in'])) exit;

$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');

$stmt = $pdo->prepare("SELECT sp.*, p.nombre_completo 
                      FROM sesiones_pagos sp 
                      JOIN pacientes p ON sp.paciente_id = p.id 
                      WHERE sp.fecha_sesion BETWEEN ? AND ? 
                      ORDER BY sp.fecha_sesion ASC");
$stmt->execute([$desde, $hasta]);
$rows = $stmt->fetchAll();
$total = array_sum(array_column($rows, 'monto'));

// Obtener datos del administrador para el encabezado (Logo/Firma)
$stmt_admin = $pdo->query("SELECT * FROM admins LIMIT 1");
$admin = $stmt_admin->fetch();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte_Contable_<?php echo $desde; ?></title>
    <style>
        body { font-family: sans-serif; color: #333; padding: 40px; }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 20px; margin-bottom: 30px; }
        .logo { max-height: 60px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background: #f4f4f4; padding: 10px; text-align: left; border: 1px solid #ddd; }
        td { padding: 10px; border: 1px solid #ddd; }
        .total-box { text-align: right; margin-top: 30px; font-size: 1.2rem; font-weight: bold; }
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
        }
    </style>
</head>
<body onload="window.print();">
    <div class="header">
        <div>
            <img src="../assets/img/logo.png" class="logo" onerror="this.style.display='none'">
            <h2>Reporte Contable</h2>
            <p><strong>Especialista:</strong> <?php echo $admin['nombre'] ?? 'Administrador'; ?></p>
        </div>
        <div style="text-align: right;">
            <p><strong>Fecha de Emisión:</strong> <?php echo date('d/m/Y'); ?></p>
            <p><strong>Periodo:</strong> <?php echo date('d/m/Y', strtotime($desde)); ?> - <?php echo date('d/m/Y', strtotime($hasta)); ?></p>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Paciente</th>
                <th>Concepto</th>
                <th>Monto</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($rows as $r): ?>
            <tr>
                <td><?php echo date('d/m/Y', strtotime($r['fecha_sesion'])); ?></td>
                <td><?php echo htmlspecialchars($r['nombre_completo']); ?></td>
                <td>Pago de Sesión Psicológica</td>
                <td>$<?php echo number_format($r['monto'], 2); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="total-box">
        TOTAL RECAUDADO EN EL PERIODO: $<?php echo number_format($total, 2); ?>
    </div>

    <div style="margin-top: 80px; text-align: center;">
        <div style="width: 200px; border-top: 1px solid #000; margin: 0 auto;"></div>
        <p>Firma Autorizada</p>
    </div>
</body>
</html>