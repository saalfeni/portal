<?php
// /portal/generar_prueba_completa.php
require 'db_connect.php';

// Configuración del Paciente de Ejemplo (Basado en tu estructura real)
$nombre_ejemplo = "Juan Prueba MMPI";
$email_ejemplo = "test_paciente@portal.com";
$password_plana = "123456";
$password_hash = password_hash($password_plana, PASSWORD_DEFAULT);
$genero = "m"; 
$fecha_nacimiento = "1990-05-15";
$estudios = "Licenciatura";
$ocupacion = "Analista";

// Estructura de JSON vacíos para que la base de datos no dé error
$json_vacio = json_encode([]);

try {
    $pdo->beginTransaction();

    // 1. Verificar duplicados
    $check = $pdo->prepare("SELECT id FROM pacientes WHERE email = ?");
    $check->execute([$email_ejemplo]);
    if ($check->fetch()) {
        die("<h3 style='color:orange;'>El usuario de prueba ya existe. Prueba loguearte con $email_ejemplo</h3>");
    }

    // 2. Insertar con los nombres de columna correctos de tu DB
    $sql_paciente = "INSERT INTO pacientes (
        nombre_completo, email, password, genero, fecha_nacimiento, 
        ultimo_grado_estudios, ocupacion, fecha_registro, mmpi2_habilitado,
        historial_relacional, historial_sustancias, datos_contacto, motivo_consulta, antecedentes_clinicos
    ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), 1, ?, ?, ?, ?, ?)";
    
    $stmt = $pdo->prepare($sql_paciente);
    $stmt->execute([
        $nombre_ejemplo, $email_ejemplo, $password_hash, $genero, $fecha_nacimiento, 
        $estudios, $ocupacion, $json_vacio, $json_vacio, $json_vacio, $json_vacio, $json_vacio
    ]);
    
    $paciente_id = $pdo->lastInsertId();

    // 3. Generar las 567 respuestas aleatorias
    $stmt_res = $pdo->prepare("INSERT INTO mmpi2_respuestas (paciente_id, pregunta_id, respuesta, fecha_guardado) VALUES (?, ?, ?, NOW())");
    
    for ($i = 1; $i <= 567; $i++) {
        $res = rand(0, 1);
        $stmt_res->execute([$paciente_id, $i, $res]);
    }

    $pdo->commit();

    echo "
    <div style='font-family: sans-serif; max-width: 600px; margin: 40px auto; border: 2px solid #40E0D0; border-radius: 12px; padding: 25px;'>
        <h2 style='color:#40E0D0;'>¡Entorno de Prueba Robusto Creado!</h2>
        <p>Se ha generado un perfil completo con historial y 567 respuestas.</p>
        <div style='background: #f4f4f4; padding: 15px; border-radius: 8px;'>
            <strong>Credenciales:</strong><br>
            📧 Email: <code>$email_ejemplo</code><br>
            🔑 Password: <code>$password_plana</code><br>
            🆔 Paciente ID: <code>$paciente_id</code>
        </div>
        <p style='margin-top:20px;'><strong>Acciones disponibles:</strong></p>
        <a href='login_paciente.php' style='color:blue;'>1. Ir al Login del Paciente</a><br>
        <a href='tests/mmpi-2/interpretar.php?id=$paciente_id' style='color:blue;'>2. Ver reporte de interpretación</a>
    </div>";

} catch (Exception $e) {
    $pdo->rollBack();
    echo "Error detectado: " . $e->getMessage();
}